package com.androidsdk.app.engine;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Lê um resources.arsc e devolve um resumo legível (tipos de recurso e seus nomes/valores simples). */
public final class ArscReader {

    private static List<String> readPool(ByteBuffer b, int base) {
        int n = b.getInt(base + 8);
        int flags = b.getInt(base + 16);
        int stringsStart = b.getInt(base + 20);
        boolean utf8 = (flags & 0x100) != 0;
        List<String> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            int off = b.getInt(base + 28 + 4 * i);
            int p = base + stringsStart + off;
            if (utf8) {
                int u16len = b.get(p) & 0xFF;
                p += 1;
                if ((u16len & 0x80) != 0) p += 1;
                int blen = b.get(p) & 0xFF;
                p += 1;
                if ((blen & 0x80) != 0) {
                    blen = ((blen & 0x7F) << 8) | (b.get(p) & 0xFF);
                    p += 1;
                }
                byte[] x = new byte[Math.max(0, blen)];
                for (int k = 0; k < x.length; k++) x[k] = b.get(p + k);
                out.add(new String(x, StandardCharsets.UTF_8));
            } else {
                int len = b.getShort(p) & 0xFFFF;
                p += 2;
                if ((len & 0x8000) != 0) {
                    len = ((len & 0x7FFF) << 16) | (b.getShort(p) & 0xFFFF);
                    p += 2;
                }
                byte[] x = new byte[Math.max(0, len) * 2];
                for (int k = 0; k < x.length; k++) x[k] = b.get(p + k);
                out.add(new String(x, StandardCharsets.UTF_16LE));
            }
        }
        return out;
    }

    private static final float[] RADIX = {0.00390625f, 3.051758E-5f, 1.192093E-7f, 4.656613E-10f};
    private static final String[] DIMU = {"px", "dip", "sp", "pt", "in", "mm"};
    private static final String[] FRACU = {"%", "%p"};

    private static String simpleValue(List<String> global, int type, int data) {
        switch (type) {
            case 0x04:
                return String.valueOf(Float.intBitsToFloat(data));
            case 0x05: {
                float v = (data & 0xFFFFFF00) * RADIX[(data >> 4) & 3];
                int u = data & 0xF;
                return v + (u < DIMU.length ? DIMU[u] : "");
            }
            case 0x06: {
                float v = (data & 0xFFFFFF00) * RADIX[(data >> 4) & 3] * 100f;
                return v + FRACU[data & 0xF & 1];
            }
            case 0x03:
                return data >= 0 && data < global.size() ? global.get(data) : "";
            case 0x10:
                return String.valueOf(data);
            case 0x12:
                return data != 0 ? "true" : "false";
            case 0x1c:
            case 0x1d:
            case 0x1e:
            case 0x1f:
                return String.format("#%08x", data);
            case 0x01:
                return String.format("@0x%08x", data);
            default:
                return String.format("0x%x", data);
        }
    }

    public static String summarize(byte[] data, int limitPerType) {
        try {
            ByteBuffer b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
            if ((b.getShort(0) & 0xFFFF) != 0x0002) return "";
            StringBuilder out = new StringBuilder();
            int pos = 12;
            List<String> global = new ArrayList<>();
            while (pos + 8 <= data.length) {
                int type = b.getShort(pos) & 0xFFFF;
                int size = b.getInt(pos + 4);
                if (size < 8 || pos + size > data.length) break;
                if (type == 0x0001) {
                    global = readPool(b, pos);
                } else if (type == 0x0200) {
                    out.append(summarizePackage(b, pos, size, global, limitPerType));
                }
                pos += size;
            }
            return out.toString();
        } catch (Exception e) {
            return t("(não consegui ler o resources.arsc: ", "(could not read resources.arsc: ") + e + ")";
        }
    }

    private static String t(String pt, String en) {
        return pt; // o app chama este leitor só a partir do Kotlin, que já escolhe o idioma na saída
    }

    private static String summarizePackage(ByteBuffer b, int pkgPos, int pkgSize, List<String> global, int limitPerType) {
        int headerSize = b.getShort(pkgPos + 2) & 0xFFFF;
        String pkgName = decodeName(b, pkgPos + 12);
        int typeStringsOff = pkgPos + b.getInt(pkgPos + 268);
        int keyStringsOff = pkgPos + b.getInt(pkgPos + 276);
        List<String> typeNames = readPool(b, typeStringsOff);
        List<String> keyNames = readPool(b, keyStringsOff);
        StringBuilder out = new StringBuilder();
        out.append("package ").append(pkgName).append("\n");

        int pos = pkgPos + headerSize;
        int end = pkgPos + pkgSize;
        int curType = -1;
        List<String> curNames = null;
        int shown = 0;
        while (pos + 8 <= end) {
            int type = b.getShort(pos) & 0xFFFF;
            int size = b.getInt(pos + 4);
            if (size < 8 || pos + size > end) break;
            if (type == 0x0202) {
                int id = b.get(pos + 8) & 0xFF;
                curType = id;
                out.append("\n[").append(typeNames.get(id - 1)).append("]\n");
                shown = 0;
            } else if (type == 0x0201) {
                int id = b.get(pos + 8) & 0xFF;
                int hdrSize = b.getShort(pos + 2) & 0xFFFF;
                int entryCount = b.getInt(pos + 12);
                int entriesStart = b.getInt(pos + 16);
                int cfgOff = pos + 20; // início de ResTable_config, logo após os campos fixos
                boolean isDefault = isDefaultConfig(b, cfgOff);
                for (int i = 0; i < entryCount && isDefault; i++) {
                    int off = b.getInt(pos + hdrSize + 4 * i);
                    if (off == -1) continue;
                    int e = pos + entriesStart + off;
                    int keyIdx = b.getInt(e + 4);
                    int flags = b.getShort(e + 2) & 0xFFFF;
                    String name = keyIdx >= 0 && keyIdx < keyNames.size() ? keyNames.get(keyIdx) : "?";
                    if (shown >= limitPerType) continue;
                    if ((flags & 1) != 0) {
                        out.append("  ").append(name).append(" = (estilo/bag)\n");
                    } else {
                        int vtype = b.get(e + 11) & 0xFF;
                        int vdata = b.getInt(e + 12);
                        out.append("  ").append(name).append(" = ").append(simpleValue(global, vtype, vdata)).append("\n");
                    }
                    shown++;
                }
                if (shown >= limitPerType) {
                    // marca truncado apenas uma vez por tipo
                }
            }
            pos += size;
        }
        return out.toString();
    }

    private static boolean isDefaultConfig(ByteBuffer b, int off) {
        int size = b.getInt(off);
        for (int i = 4; i < size; i++) {
            if (b.get(off + i) != 0) return false;
        }
        return true;
    }

    private static String decodeName(ByteBuffer b, int off) {
        byte[] x = new byte[256];
        for (int i = 0; i < 256; i++) x[i] = b.get(off + i);
        String s = new String(x, StandardCharsets.UTF_16LE);
        int z = s.indexOf('\0');
        return z >= 0 ? s.substring(0, z) : s;
    }
}
