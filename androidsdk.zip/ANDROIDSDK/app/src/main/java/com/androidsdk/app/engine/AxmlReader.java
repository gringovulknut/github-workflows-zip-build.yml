package com.androidsdk.app.engine;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Converte o XML binário do Android (AndroidManifest.xml dentro de um APK) de volta para texto legível. */
public final class AxmlReader {

    private static final float[] RADIX = {0.00390625f, 3.051758E-5f, 1.192093E-7f, 4.656613E-10f};
    private static final String[] DIM = {"px", "dip", "sp", "pt", "in", "mm"};

    public static String decode(byte[] data) throws Exception {
        ByteBuffer b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        if (data.length < 8 || (b.getShort(0) & 0xFFFF) != 0x0003) throw new Exception("Não é um XML binário do Android");
        int pos = 8;
        List<String> pool = new ArrayList<>();
        int[] resMap = new int[0];
        Map<String, String> prefixOf = new HashMap<>(); // uri -> prefix
        List<String[]> pendingNs = new ArrayList<>();
        StringBuilder out = new StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
        int depth = 0;
        boolean openTag = false;

        while (pos + 8 <= data.length) {
            int type = b.getShort(pos) & 0xFFFF;
            int size = b.getInt(pos + 4);
            if (size < 8 || pos + size > data.length) break;
            switch (type) {
                case 0x0001:
                    readPool(b, pos, pool);
                    break;
                case 0x0180: {
                    int n = (size - 8) / 4;
                    resMap = new int[n];
                    for (int i = 0; i < n; i++) resMap[i] = b.getInt(pos + 8 + 4 * i);
                    break;
                }
                case 0x0100: {
                    String prefix = str(pool, b.getInt(pos + 16));
                    String uri = str(pool, b.getInt(pos + 20));
                    prefixOf.put(uri, prefix);
                    pendingNs.add(new String[]{prefix, uri});
                    break;
                }
                case 0x0102: {
                    int nsIdx = b.getInt(pos + 16 + 0);
                    int nameIdx = b.getInt(pos + 20);
                    int attrStart = b.getShort(pos + 24) & 0xFFFF;
                    int attrSize = b.getShort(pos + 26) & 0xFFFF;
                    int count = b.getShort(pos + 28) & 0xFFFF;
                    if (openTag) out.append(">\n");
                    indent(out, depth);
                    out.append('<').append(qname(pool, prefixOf, nsIdx, nameIdx));
                    for (String[] ns : pendingNs) {
                        out.append("\n");
                        indent(out, depth + 2);
                        out.append("xmlns:").append(ns[0]).append("=\"").append(esc(ns[1])).append('"');
                    }
                    pendingNs.clear();
                    int base = pos + 16 + attrStart;
                    for (int i = 0; i < count; i++) {
                        int a = base + i * attrSize;
                        int ans = b.getInt(a);
                        int aname = b.getInt(a + 4);
                        int raw = b.getInt(a + 8);
                        int vtype = b.get(a + 15) & 0xFF;
                        int vdata = b.getInt(a + 16);
                        String name = attrName(pool, prefixOf, resMap, ans, aname);
                        String val = value(pool, vtype, vdata, raw);
                        out.append("\n");
                        indent(out, depth + 2);
                        out.append(name).append("=\"").append(esc(val)).append('"');
                    }
                    openTag = true;
                    depth++;
                    break;
                }
                case 0x0103: {
                    depth--;
                    if (openTag) {
                        out.append(" />\n");
                        openTag = false;
                    } else {
                        indent(out, depth);
                        out.append("</").append(qname(pool, prefixOf, b.getInt(pos + 16), b.getInt(pos + 20))).append(">\n");
                    }
                    break;
                }
                case 0x0104: {
                    int idx = b.getInt(pos + 16);
                    if (openTag) {
                        out.append(">\n");
                        openTag = false;
                    }
                    indent(out, depth);
                    out.append(esc(str(pool, idx))).append("\n");
                    break;
                }
                default:
                    break;
            }
            pos += size;
        }
        return out.toString();
    }

    private static void readPool(ByteBuffer b, int pos, List<String> pool) {
        int n = b.getInt(pos + 8);
        int flags = b.getInt(pos + 16);
        int stringsStart = b.getInt(pos + 20);
        boolean utf8 = (flags & 0x100) != 0;
        for (int i = 0; i < n; i++) {
            int off = b.getInt(pos + 28 + 4 * i);
            int p = pos + stringsStart + off;
            if (utf8) {
                int u16len = b.get(p) & 0xFF;
                p += 1;
                if ((u16len & 0x80) != 0) {
                    p += 1;
                }
                int blen = b.get(p) & 0xFF;
                p += 1;
                if ((blen & 0x80) != 0) {
                    blen = ((blen & 0x7F) << 8) | (b.get(p) & 0xFF);
                    p += 1;
                }
                byte[] x = new byte[blen];
                for (int k = 0; k < blen; k++) x[k] = b.get(p + k);
                pool.add(new String(x, StandardCharsets.UTF_8));
            } else {
                int len = b.getShort(p) & 0xFFFF;
                p += 2;
                if ((len & 0x8000) != 0) {
                    len = ((len & 0x7FFF) << 16) | (b.getShort(p) & 0xFFFF);
                    p += 2;
                }
                byte[] x = new byte[len * 2];
                for (int k = 0; k < x.length; k++) x[k] = b.get(p + k);
                pool.add(new String(x, StandardCharsets.UTF_16LE));
            }
        }
    }

    private static String str(List<String> pool, int idx) {
        return idx >= 0 && idx < pool.size() ? pool.get(idx) : "";
    }

    private static String qname(List<String> pool, Map<String, String> prefixOf, int nsIdx, int nameIdx) {
        String name = str(pool, nameIdx);
        if (nsIdx >= 0) {
            String p = prefixOf.get(str(pool, nsIdx));
            if (p != null && !p.isEmpty()) return p + ":" + name;
        }
        return name;
    }

    private static String attrName(List<String> pool, Map<String, String> prefixOf, int[] resMap, int nsIdx, int nameIdx) {
        String name = str(pool, nameIdx);
        if (name.isEmpty() && nameIdx >= 0 && nameIdx < resMap.length) {
            name = String.format("attr_0x%08x", resMap[nameIdx]);
        }
        if (nsIdx >= 0) {
            String p = prefixOf.get(str(pool, nsIdx));
            if (p != null && !p.isEmpty()) return p + ":" + name;
        }
        return name;
    }

    private static String value(List<String> pool, int type, int data, int raw) {
        switch (type) {
            case 0x03:
                return str(pool, data);
            case 0x01:
                return data == 0 ? "@null" : String.format("@0x%08x", data);
            case 0x02:
                return String.format("?0x%08x", data);
            case 0x04:
                return String.valueOf(Float.intBitsToFloat(data));
            case 0x05: {
                float v = (data & 0xFFFFFF00) * RADIX[(data >> 4) & 3];
                int u = data & 0xF;
                return v + (u < DIM.length ? DIM[u] : "");
            }
            case 0x06: {
                float v = (data & 0xFFFFFF00) * RADIX[(data >> 4) & 3] * 100f;
                return v + (((data & 0xF) == 0) ? "%" : "%p");
            }
            case 0x10:
                return String.valueOf(data);
            case 0x11:
                return String.format("0x%x", data);
            case 0x12:
                return data != 0 ? "true" : "false";
            case 0x1c:
            case 0x1d:
            case 0x1e:
            case 0x1f:
                return String.format("#%08x", data);
            default:
                return raw >= 0 ? str(pool, raw) : String.format("0x%x", data);
        }
    }

    private static void indent(StringBuilder sb, int depth) {
        for (int i = 0; i < depth; i++) sb.append("    ");
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace("\"", "&quot;");
    }
}
