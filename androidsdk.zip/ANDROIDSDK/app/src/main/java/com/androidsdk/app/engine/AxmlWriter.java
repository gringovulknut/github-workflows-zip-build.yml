package com.androidsdk.app.engine;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/**
 * Converte um AndroidManifest.xml de texto para o XML binário (AXML) que o Android exige dentro do APK.
 * Cobre o essencial (sem resources do app): package, uses-sdk, permissões, application, activity,
 * intent-filter, service, receiver e meta-data.
 */
public final class AxmlWriter {

    /** Resolve referências do framework, ex.: ("style", "Theme.Material.NoActionBar"). */
    public interface Resolver {
        int resolve(String type, String name);
    }

    private static final String NS = "http://schemas.android.com/apk/res/android";
    private static final String XMLNS = "http://www.w3.org/2000/xmlns/";

    private static final int T_REF = 0x01;
    private static final int T_STR = 0x03;
    private static final int T_DEC = 0x10;
    private static final int T_HEX = 0x11;
    private static final int T_BOOL = 0x12;

    private static final Map<String, Integer> IDS = new HashMap<>();
    private static final Map<String, String> KIND = new HashMap<>();
    private static final Map<String, Integer> CONFIG = new HashMap<>();
    private static final Map<String, Integer> LAUNCH = new HashMap<>();
    private static final Map<String, Integer> ORIENT = new HashMap<>();

    private static void a(String name, int id, String kind) {
        IDS.put(name, id);
        KIND.put(name, kind);
    }

    static {
        a("theme", 0x01010000, "ref");
        a("label", 0x01010001, "strref");
        a("icon", 0x01010002, "ref");
        a("name", 0x01010003, "str");
        a("exported", 0x01010010, "bool");
        a("launchMode", 0x0101001d, "launch");
        a("screenOrientation", 0x0101001e, "orient");
        a("configChanges", 0x0101001f, "flags");
        a("value", 0x01010024, "str");
        a("resource", 0x01010025, "ref");
        a("minSdkVersion", 0x0101020c, "int");
        a("versionCode", 0x0101021b, "int");
        a("versionName", 0x0101021c, "str");
        a("targetSdkVersion", 0x01010270, "int");
        a("maxSdkVersion", 0x01010271, "int");
        a("allowBackup", 0x01010280, "bool");
        a("required", 0x0101028e, "bool");
        a("hardwareAccelerated", 0x010102d3, "bool");
        a("largeHeap", 0x0101035a, "bool");
        a("supportsRtl", 0x010103af, "bool");
        a("usesCleartextTraffic", 0x010104ec, "bool");

        CONFIG.put("mcc", 0x1);
        CONFIG.put("mnc", 0x2);
        CONFIG.put("locale", 0x4);
        CONFIG.put("touchscreen", 0x8);
        CONFIG.put("keyboard", 0x10);
        CONFIG.put("keyboardHidden", 0x20);
        CONFIG.put("navigation", 0x40);
        CONFIG.put("orientation", 0x80);
        CONFIG.put("screenLayout", 0x100);
        CONFIG.put("uiMode", 0x200);
        CONFIG.put("screenSize", 0x400);
        CONFIG.put("smallestScreenSize", 0x800);
        CONFIG.put("density", 0x1000);
        CONFIG.put("layoutDirection", 0x2000);
        CONFIG.put("colorMode", 0x4000);
        CONFIG.put("fontScale", 0x40000000);

        LAUNCH.put("standard", 0);
        LAUNCH.put("singleTop", 1);
        LAUNCH.put("singleTask", 2);
        LAUNCH.put("singleInstance", 3);

        ORIENT.put("unspecified", -1);
        ORIENT.put("landscape", 0);
        ORIENT.put("portrait", 1);
        ORIENT.put("user", 2);
        ORIENT.put("behind", 3);
        ORIENT.put("sensor", 4);
        ORIENT.put("nosensor", 5);
        ORIENT.put("sensorLandscape", 6);
        ORIENT.put("sensorPortrait", 7);
        ORIENT.put("reverseLandscape", 8);
        ORIENT.put("reversePortrait", 9);
        ORIENT.put("fullSensor", 10);
        ORIENT.put("userLandscape", 11);
        ORIENT.put("userPortrait", 12);
        ORIENT.put("fullUser", 13);
        ORIENT.put("locked", 14);
    }

    private static final class Val {
        int type;
        int data;
        String str;
    }

    private static final class Attr {
        String ns;
        String name;
        int resId;
        Val val;
    }

    private static final class Elem {
        String name;
        List<Attr> attrs = new ArrayList<>();
        List<Elem> kids = new ArrayList<>();
    }

    // ---------------------------------------------------------------- API

    public static byte[] build(String xml, String pkg, int minSdk, int targetSdk,
                               int versionCode, String versionName, Resolver resolver) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        Document doc = f.newDocumentBuilder().parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        Element root = doc.getDocumentElement();
        if (!"manifest".equals(root.getLocalName())) {
            throw new Exception("O arquivo não é um AndroidManifest (raiz: " + root.getLocalName() + ")");
        }
        if (!root.hasAttributeNS(null, "package")) root.setAttributeNS(null, "package", pkg);
        if (!root.hasAttributeNS(NS, "versionCode")) root.setAttributeNS(NS, "android:versionCode", String.valueOf(versionCode));
        if (!root.hasAttributeNS(NS, "versionName")) root.setAttributeNS(NS, "android:versionName", versionName);

        boolean hasSdk = false;
        for (Node n = root.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n instanceof Element && "uses-sdk".equals(n.getLocalName())) hasSdk = true;
        }
        if (!hasSdk) {
            Element sdk = doc.createElementNS(null, "uses-sdk");
            sdk.setAttributeNS(NS, "android:minSdkVersion", String.valueOf(minSdk));
            sdk.setAttributeNS(NS, "android:targetSdkVersion", String.valueOf(targetSdk));
            root.insertBefore(sdk, root.getFirstChild());
        }

        Elem tree = convert(root, resolver);
        return encode(tree);
    }

    // ---------------------------------------------------------------- DOM -> árvore

    private static Elem convert(Element el, Resolver r) throws Exception {
        Elem e = new Elem();
        e.name = el.getLocalName() != null ? el.getLocalName() : el.getNodeName();
        NamedNodeMap m = el.getAttributes();
        for (int i = 0; i < m.getLength(); i++) {
            Node a = m.item(i);
            String ns = a.getNamespaceURI();
            if (XMLNS.equals(ns)) continue;
            Attr at = new Attr();
            at.name = a.getLocalName() != null ? a.getLocalName() : a.getNodeName();
            if (ns == null) {
                at.ns = null;
                at.resId = 0;
                at.val = new Val();
                at.val.type = T_STR;
                at.val.str = a.getNodeValue();
            } else if (NS.equals(ns)) {
                Integer id = IDS.get(at.name);
                if (id == null) {
                    throw new Exception("Atributo do manifest ainda não suportado: android:" + at.name);
                }
                at.ns = NS;
                at.resId = id;
                at.val = convertValue(at.name, KIND.get(at.name), a.getNodeValue(), r);
            } else {
                continue; // tools: e outros namespaces são ignorados
            }
            e.attrs.add(at);
        }
        e.attrs.sort(Comparator.comparingInt(a -> a.resId == 0 ? Integer.MAX_VALUE : a.resId));
        for (Node n = el.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n instanceof Element) e.kids.add(convert((Element) n, r));
        }
        return e;
    }

    private static Val convertValue(String attr, String kind, String v, Resolver r) throws Exception {
        Val out = new Val();
        v = v.trim();
        switch (kind) {
            case "str":
                out.type = T_STR;
                out.str = v;
                return out;
            case "strref":
                if (v.startsWith("@")) return ref(attr, v, r);
                out.type = T_STR;
                out.str = v;
                return out;
            case "ref":
                return ref(attr, v, r);
            case "bool":
                out.type = T_BOOL;
                if (v.equals("true")) out.data = -1;
                else if (v.equals("false")) out.data = 0;
                else throw new Exception("Valor booleano inválido em android:" + attr + ": " + v);
                return out;
            case "int":
                out.type = T_DEC;
                try {
                    out.data = v.startsWith("0x") ? (int) Long.parseLong(v.substring(2), 16) : Integer.parseInt(v);
                } catch (NumberFormatException ex) {
                    throw new Exception("Número inválido em android:" + attr + ": " + v);
                }
                return out;
            case "flags": {
                int bits = 0;
                for (String part : v.split("\\|")) {
                    Integer b = CONFIG.get(part.trim());
                    if (b == null) throw new Exception("Valor não suportado em android:" + attr + ": " + part.trim());
                    bits |= b;
                }
                out.type = T_HEX;
                out.data = bits;
                return out;
            }
            case "launch": {
                Integer b = LAUNCH.get(v);
                if (b == null) throw new Exception("Valor não suportado em android:" + attr + ": " + v);
                out.type = T_HEX;
                out.data = b;
                return out;
            }
            case "orient": {
                Integer b = ORIENT.get(v);
                if (b == null) throw new Exception("Valor não suportado em android:" + attr + ": " + v);
                out.type = T_HEX;
                out.data = b;
                return out;
            }
            default:
                throw new Exception("Tipo interno desconhecido: " + kind);
        }
    }

    private static Val ref(String attr, String v, Resolver r) throws Exception {
        Val out = new Val();
        out.type = T_REF;
        if (v.equals("@null")) {
            out.data = 0;
            return out;
        }
        if (v.startsWith("@android:")) {
            String rest = v.substring("@android:".length());
            int slash = rest.indexOf('/');
            if (slash > 0) {
                int id = r.resolve(rest.substring(0, slash), rest.substring(slash + 1));
                if (id == 0) throw new Exception("Recurso do Android não encontrado: " + v);
                out.data = id;
                return out;
            }
        }
        throw new Exception("Referência ainda não suportada em android:" + attr + ": " + v
                + " (recursos do app, como @string/ e @drawable/, chegam na etapa de XML)");
    }

    // ---------------------------------------------------------------- Codificação binária

    private static final class Out {
        final ByteArrayOutputStream b = new ByteArrayOutputStream();

        void u8(int v) {
            b.write(v & 0xFF);
        }

        void u16(int v) {
            b.write(v & 0xFF);
            b.write((v >> 8) & 0xFF);
        }

        void u32(int v) {
            b.write(v & 0xFF);
            b.write((v >> 8) & 0xFF);
            b.write((v >> 16) & 0xFF);
            b.write((v >> 24) & 0xFF);
        }

        void bytes(byte[] x) {
            b.write(x, 0, x.length);
        }

        int size() {
            return b.size();
        }

        byte[] toBytes() {
            return b.toByteArray();
        }
    }

    private static byte[] encode(Elem root) throws Exception {
        // 1) tabela de strings: nomes de atributo com ID primeiro (ordem do ID), depois o resto
        TreeMap<Integer, String> byId = new TreeMap<>();
        collectIds(root, byId);
        LinkedHashMap<String, Integer> pool = new LinkedHashMap<>();
        List<Integer> resMap = new ArrayList<>();
        for (Map.Entry<Integer, String> en : byId.entrySet()) {
            pool.put(en.getValue(), pool.size());
            resMap.add(en.getKey());
        }
        intern(pool, "android");
        intern(pool, NS);
        collectStrings(root, pool);

        // 2) corpo (namespace + elementos)
        Out body = new Out();
        int android = pool.get("android");
        int uri = pool.get(NS);
        nsChunk(body, 0x0100, android, uri);
        element(body, root, pool);
        nsChunk(body, 0x0101, android, uri);

        // 3) string pool
        List<String> strs = new ArrayList<>(pool.keySet());
        Out data = new Out();
        int[] offs = new int[strs.size()];
        for (int i = 0; i < strs.size(); i++) {
            offs[i] = data.size();
            String s = strs.get(i);
            if (s.length() > 0x7FFF) throw new Exception("String longa demais no manifest");
            data.u16(s.length());
            data.bytes(s.getBytes(StandardCharsets.UTF_16LE));
            data.u16(0);
        }
        while (data.size() % 4 != 0) data.u8(0);
        int stringsStart = 28 + 4 * strs.size();

        Out sp = new Out();
        sp.u16(0x0001);
        sp.u16(28);
        sp.u32(stringsStart + data.size());
        sp.u32(strs.size());
        sp.u32(0);
        sp.u32(0);
        sp.u32(stringsStart);
        sp.u32(0);
        for (int o : offs) sp.u32(o);
        sp.bytes(data.toBytes());

        // 4) mapa de IDs de recurso
        Out rm = new Out();
        rm.u16(0x0180);
        rm.u16(8);
        rm.u32(8 + 4 * resMap.size());
        for (int id : resMap) rm.u32(id);

        byte[] spB = sp.toBytes();
        byte[] rmB = rm.toBytes();
        byte[] bodyB = body.toBytes();
        Out file = new Out();
        file.u16(0x0003);
        file.u16(8);
        file.u32(8 + spB.length + rmB.length + bodyB.length);
        file.bytes(spB);
        file.bytes(rmB);
        file.bytes(bodyB);
        return file.toBytes();
    }

    private static void collectIds(Elem e, TreeMap<Integer, String> byId) {
        for (Attr a : e.attrs) {
            if (a.resId != 0) byId.put(a.resId, a.name);
        }
        for (Elem k : e.kids) collectIds(k, byId);
    }

    private static void intern(Map<String, Integer> pool, String s) {
        if (!pool.containsKey(s)) pool.put(s, pool.size());
    }

    private static void collectStrings(Elem e, Map<String, Integer> pool) {
        intern(pool, e.name);
        for (Attr a : e.attrs) {
            intern(pool, a.name);
            if (a.val.type == T_STR) intern(pool, a.val.str);
        }
        for (Elem k : e.kids) collectStrings(k, pool);
    }

    private static void nsChunk(Out o, int type, int prefix, int uri) {
        o.u16(type);
        o.u16(16);
        o.u32(24);
        o.u32(1);
        o.u32(-1);
        o.u32(prefix);
        o.u32(uri);
    }

    private static void element(Out o, Elem e, Map<String, Integer> pool) {
        int name = pool.get(e.name);
        int n = e.attrs.size();
        o.u16(0x0102);
        o.u16(16);
        o.u32(36 + 20 * n);
        o.u32(1);
        o.u32(-1);
        o.u32(-1);
        o.u32(name);
        o.u16(0x14);
        o.u16(0x14);
        o.u16(n);
        o.u16(0);
        o.u16(0);
        o.u16(0);
        for (Attr a : e.attrs) {
            o.u32(a.ns == null ? -1 : pool.get(NS));
            o.u32(pool.get(a.name));
            o.u32(a.val.type == T_STR ? pool.get(a.val.str) : -1);
            o.u16(8);
            o.u8(0);
            o.u8(a.val.type);
            o.u32(a.val.type == T_STR ? pool.get(a.val.str) : a.val.data);
        }
        for (Elem k : e.kids) element(o, k, pool);
        o.u16(0x0103);
        o.u16(16);
        o.u32(24);
        o.u32(1);
        o.u32(-1);
        o.u32(-1);
        o.u32(name);
    }
}
