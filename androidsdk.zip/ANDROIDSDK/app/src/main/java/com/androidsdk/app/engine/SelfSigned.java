package com.androidsdk.app.engine;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/** Gera uma chave RSA e um certificado X.509 autoassinado em DER puro, sem bibliotecas extras. */
public final class SelfSigned {

    public static final class Result {
        public final PrivateKey key;
        public final X509Certificate cert;

        Result(PrivateKey key, X509Certificate cert) {
            this.key = key;
            this.cert = cert;
        }
    }

    public static Result create(String cn) throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        KeyPair kp = kpg.generateKeyPair();

        byte[] sigAlg = hex("300D06092A864886F70D01010B0500"); // sha256WithRSAEncryption + NULL
        byte[] name = seq(set(seq(cat(hex("0603550403"), tlv(0x0C, cn.getBytes(StandardCharsets.UTF_8))))));

        long now = System.currentTimeMillis();
        byte[] notBefore = tlv(0x17, time("yyMMddHHmmss'Z'", now - 24L * 3600 * 1000));
        byte[] notAfter = tlv(0x18, time("yyyyMMddHHmmss'Z'", now + 25L * 365 * 24 * 3600 * 1000));

        byte[] tbs = seq(cat(
                hex("A003020102"),                                           // versão 3
                tlv(0x02, BigInteger.valueOf(now).toByteArray()),            // serial
                sigAlg,
                name,                                                         // emissor
                seq(cat(notBefore, notAfter)),                               // validade
                name,                                                         // titular
                kp.getPublic().getEncoded()                                   // SubjectPublicKeyInfo
        ));

        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(kp.getPrivate());
        s.update(tbs);
        byte[] sig = s.sign();

        byte[] cert = seq(cat(tbs, sigAlg, tlv(0x03, cat(new byte[]{0}, sig))));
        X509Certificate x = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(cert));
        return new Result(kp.getPrivate(), x);
    }

    // ---- DER ----

    private static byte[] time(String fmt, long ms) {
        SimpleDateFormat f = new SimpleDateFormat(fmt);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(ms)).getBytes(StandardCharsets.US_ASCII);
    }

    private static byte[] len(int n) {
        if (n < 128) return new byte[]{(byte) n};
        if (n < 256) return new byte[]{(byte) 0x81, (byte) n};
        return new byte[]{(byte) 0x82, (byte) (n >> 8), (byte) n};
    }

    private static byte[] tlv(int tag, byte[] v) {
        return cat(new byte[]{(byte) tag}, len(v.length), v);
    }

    private static byte[] seq(byte[] v) {
        return tlv(0x30, v);
    }

    private static byte[] set(byte[] v) {
        return tlv(0x31, v);
    }

    private static byte[] cat(byte[]... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] p : parts) o.write(p, 0, p.length);
        return o.toByteArray();
    }

    private static byte[] hex(String s) {
        byte[] b = new byte[s.length() / 2];
        for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
        return b;
    }
}
