package com.androidsdk.app.engine;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/**
 * Compila a pasta res/ de um app: gera resources.arsc, os XMLs binários (layout, drawable, menu...),
 * copia imagens/raw e escreve o R.java. Sem aapt2.
 */
public final class ResCompiler {

    /** Acesso ao framework do Android (ids de atributos e recursos @android:...). */
    public interface Env {
        int attr(String name);

        int framework(String type, String name);
    }

    public static final class Out {
        public byte[] arsc;
        public final Map<String, byte[]> files = new LinkedHashMap<>(); // "res/layout/x.xml" -> bytes
        public String rJava;
        final Map<String, Integer> ids = new HashMap<>();

        public int idOf(String type, String name) {
            Integer v = ids.get(type + "/" + name);
            return v == null ? 0 : v;
        }
    }

    private static final String AUTO = "http://schemas.android.com/apk/res-auto";
    private static final String XMLNS = "http://www.w3.org/2000/xmlns/";

    private static final List<String> TYPE_ORDER = Arrays.asList(
            "anim", "animator", "bool", "color", "dimen", "drawable", "id", "integer", "interpolator",
            "layout", "menu", "mipmap", "raw", "string", "style", "xml");
    private static final Set<String> FILE_TYPES = new HashSet<>(Arrays.asList(
            "anim", "animator", "color", "drawable", "interpolator", "layout", "menu", "mipmap", "raw", "xml"));
    private static final Set<String> VALUE_TYPES = new HashSet<>(Arrays.asList(
            "bool", "color", "dimen", "id", "integer", "string", "style"));

    private static final Set<String> STRING_ATTRS = new HashSet<>(Arrays.asList(
            "text", "hint", "contentDescription", "title", "titleCondensed", "label", "tag", "name", "description",
            "summary", "prompt", "fontFamily", "onClick", "transitionName", "tooltipText", "packageName",
            "targetClass", "action", "mimeType", "data", "key", "value"));
    private static final Set<String> FLOAT_ATTRS = new HashSet<>(Arrays.asList(
            "layout_weight", "weightSum", "alpha", "viewportWidth", "viewportHeight", "fillAlpha", "strokeAlpha",
            "rotation", "scaleX", "scaleY", "pivotX", "pivotY", "textScaleX", "lineSpacingMultiplier",
            "startOffset", "toAlpha", "fromAlpha", "trimPathStart", "trimPathEnd", "trimPathOffset"));
    private static final Set<String> FLAG_ATTRS = new HashSet<>(Arrays.asList(
            "gravity", "layout_gravity", "foregroundGravity", "textStyle", "inputType", "autoLink"));
    private static final Map<String, Map<String, Integer>> ENUMS = new HashMap<>();

    private static void en(String attr, Object... kv) {
        Map<String, Integer> m = new HashMap<>();
        for (int i = 0; i < kv.length; i += 2) m.put((String) kv[i], (Integer) kv[i + 1]);
        ENUMS.put(attr, m);
    }

    static {
        en("layout_width", "match_parent", -1, "fill_parent", -1, "wrap_content", -2);
        en("layout_height", "match_parent", -1, "fill_parent", -1, "wrap_content", -2);
        Object[] gravity = {"top", 0x30, "bottom", 0x50, "left", 0x3, "right", 0x5, "center_vertical", 0x10,
                "fill_vertical", 0x70, "center_horizontal", 0x1, "fill_horizontal", 0x7, "center", 0x11,
                "fill", 0x77, "clip_vertical", 0x80, "clip_horizontal", 0x8, "start", 0x00800003, "end", 0x00800005};
        en("gravity", gravity);
        en("layout_gravity", gravity);
        en("foregroundGravity", gravity);
        en("visibility", "visible", 0, "invisible", 1, "gone", 2);
        en("orientation", "horizontal", 0, "vertical", 1);
        en("textStyle", "normal", 0, "bold", 1, "italic", 2);
        en("scaleType", "matrix", 0, "fitXY", 1, "fitStart", 2, "fitCenter", 3, "fitEnd", 4, "center", 5,
                "centerCrop", 6, "centerInside", 7);
        en("ellipsize", "none", 0, "start", 1, "middle", 2, "end", 3, "marquee", 4);
        en("typeface", "normal", 0, "sans", 1, "serif", 2, "monospace", 3);
        en("shape", "rectangle", 0, "oval", 1, "line", 2, "ring", 3);
        en("textAlignment", "inherit", 0, "gravity", 1, "textStart", 2, "textEnd", 3, "textCenter", 4,
                "viewStart", 5, "viewEnd", 6);
        en("layoutDirection", "ltr", 0, "rtl", 1, "inherit", 2, "locale", 3);
        en("autoLink", "none", 0, "web", 1, "email", 2, "phone", 4, "map", 8, "all", 0xf);
        en("inputType", "none", 0, "text", 1, "textCapCharacters", 0x1001, "textCapWords", 0x2001,
                "textCapSentences", 0x4001, "textAutoCorrect", 0x8001, "textAutoComplete", 0x10001,
                "textMultiLine", 0x20001, "textImeMultiLine", 0x40001, "textNoSuggestions", 0x80001,
                "textUri", 0x11, "textEmailAddress", 0x21, "textEmailSubject", 0x31, "textShortMessage", 0x41,
                "textLongMessage", 0x51, "textPersonName", 0x61, "textPostalAddress", 0x71, "textPassword", 0x81,
                "textVisiblePassword", 0x91, "textWebEditText", 0xa1, "textFilter", 0xb1, "textPhonetic", 0xc1,
                "textWebEmailAddress", 0xd1, "textWebPassword", 0xe1, "number", 0x2, "numberSigned", 0x1002,
                "numberDecimal", 0x2002, "numberPassword", 0x12, "phone", 0x3, "datetime", 0x4, "date", 0x14,
                "time", 0x24);
    }

    // ------------------------------------------------------------------ estruturas

    private static final class Cfg {
        String key = "";
        byte[] bytes = new byte[64];
        int flags = 0;

        Cfg() {
            put32(bytes, 0, 64);
        }
    }

    private static final class Res {
        String type;
        String name;
        Cfg cfg;
        AxmlWriter.Val val;        // recurso simples
        boolean bag;
        int parent;
        List<int[]> keys = new ArrayList<>();               // bag: [attrId]
        List<AxmlWriter.Val> vals = new ArrayList<>();      // bag: valores na mesma ordem
    }

    private static final class Decl {
        String type;
        String name;
        Cfg cfg;
        Element el;
    }

    private final Env env;
    private final String pkg;
    private final Out out = new Out();
    private final Map<String, TreeSet<String>> names = new HashMap<>();   // type -> nomes
    private final Map<String, Integer> typeIds = new HashMap<>();
    private final List<Res> all = new ArrayList<>();
    private final Set<String> styleNames = new HashSet<>();

    private ResCompiler(String pkg, Env env) {
        this.pkg = pkg;
        this.env = env;
    }

    public static Out compile(Map<String, byte[]> res, String pkg, Env env) throws Exception {
        return new ResCompiler(pkg, env).run(res);
    }

    // ------------------------------------------------------------------ fluxo

    private Out run(Map<String, byte[]> res) throws Exception {
        List<String> paths = new ArrayList<>(res.keySet());
        java.util.Collections.sort(paths);

        // 1) registrar nomes e ler os arquivos de values
        List<Decl> decls = new ArrayList<>();
        List<String[]> fileRes = new ArrayList<>(); // {path, type, name, cfgKey}
        Map<String, Cfg> cfgs = new HashMap<>();
        Pattern idRef = Pattern.compile("@\\+id/([A-Za-z0-9_.]+)");
        for (String path : paths) {
            int slash = path.indexOf('/');
            if (slash < 0) continue;
            String dir = path.substring(0, slash);
            String file = path.substring(slash + 1);
            if (file.contains("/") || file.startsWith(".")) continue;
            String type = dir;
            String qual = "";
            int dash = dir.indexOf('-');
            if (dash >= 0) {
                type = dir.substring(0, dash);
                qual = dir.substring(dash + 1);
            }
            Cfg cfg = cfgs.get(qual);
            if (cfg == null) {
                cfg = parseCfg(qual, dir);
                cfgs.put(qual, cfg);
            }
            byte[] data = res.get(path);
            if (file.endsWith(".xml")) {
                Matcher m = idRef.matcher(new String(data, StandardCharsets.UTF_8));
                while (m.find()) register("id", m.group(1));
            }
            if (type.equals("values")) {
                if (!file.endsWith(".xml")) continue;
                Document doc = parse(data, path);
                for (Node n = doc.getDocumentElement().getFirstChild(); n != null; n = n.getNextSibling()) {
                    if (!(n instanceof Element)) continue;
                    Element e = (Element) n;
                    String tag = e.getTagName();
                    String t = tag;
                    if (tag.equals("item")) t = e.getAttribute("type");
                    if (tag.equals("declare-styleable") || tag.equals("attr") || tag.equals("plurals")
                            || tag.endsWith("-array") || tag.equals("array") || tag.equals("public")
                            || tag.equals("eat-comment") || tag.equals("skip")) {
                        if (tag.equals("eat-comment") || tag.equals("skip")) continue;
                        throw new Exception("<" + tag + "> em " + path + " ainda não é suportado");
                    }
                    if (!VALUE_TYPES.contains(t)) throw new Exception("Tipo de valor não suportado em " + path + ": <" + tag + ">");
                    Decl d = new Decl();
                    d.type = t;
                    d.name = e.getAttribute("name");
                    if (d.name.isEmpty()) throw new Exception("<" + tag + "> sem name em " + path);
                    d.cfg = cfg;
                    d.el = e;
                    decls.add(d);
                    register(t, d.name);
                    if (t.equals("style")) styleNames.add(d.name);
                }
            } else if (FILE_TYPES.contains(type)) {
                if (file.endsWith(".9.png")) throw new Exception(path + ": imagens 9-patch ainda não são suportadas");
                int dot = file.indexOf('.');
                String name = dot > 0 ? file.substring(0, dot) : file;
                if (!type.equals("raw") && dot < 0) continue;
                register(type, name);
                fileRes.add(new String[]{path, type, name, qual});
            } else {
                throw new Exception("Pasta de recursos não suportada: res/" + dir + "/");
            }
        }

        // 2) ids por tipo
        int typeId = 1;
        for (String t : TYPE_ORDER) {
            TreeSet<String> set = names.get(t);
            if (set == null || set.isEmpty()) continue;
            typeIds.put(t, typeId);
            int entry = 0;
            for (String n : set) {
                out.ids.put(t + "/" + n, 0x7f000000 | (typeId << 16) | entry);
                entry++;
            }
            typeId++;
        }

        // 3) arquivos (compila XML, copia o resto)
        for (String[] f : fileRes) {
            String path = f[0];
            byte[] data = res.get(path);
            Res r = new Res();
            r.type = f[1];
            r.name = f[2];
            r.cfg = cfgs.get(f[3]);
            String apkPath = "res/" + path;
            if (path.endsWith(".xml")) {
                out.files.put(apkPath, compileXml(parse(data, path), path));
            } else {
                if (f[1].equals("color") || f[1].equals("layout") || f[1].equals("menu")) {
                    throw new Exception(path + ": esse tipo de pasta só aceita arquivos .xml");
                }
                out.files.put(apkPath, data);
            }
            r.val = new AxmlWriter.Val();
            r.val.type = AxmlWriter.T_STR;
            r.val.str = apkPath;
            all.add(r);
        }

        // 4) valores
        for (Decl d : decls) all.add(buildValue(d));

        // ids declarados só por @+id
        TreeSet<String> idNames = names.get("id");
        if (idNames != null) {
            Set<String> have = new HashSet<>();
            for (Res r : all) if (r.type.equals("id")) have.add(r.name);
            Cfg def = new Cfg();
            for (String n : idNames) {
                if (have.contains(n)) continue;
                Res r = new Res();
                r.type = "id";
                r.name = n;
                r.cfg = def;
                r.val = bool(false);
                all.add(r);
            }
        }

        out.arsc = writeTable();
        out.rJava = writeR();
        return out;
    }

    private void register(String type, String name) {
        TreeSet<String> s = names.get(type);
        if (s == null) {
            s = new TreeSet<>();
            names.put(type, s);
        }
        s.add(name);
    }

    private static Document parse(byte[] data, String path) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        try {
            f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        } catch (Exception ignored) {
        }
        try {
            return f.newDocumentBuilder().parse(new ByteArrayInputStream(data));
        } catch (Exception e) {
            throw new Exception("XML inválido em " + path + ": " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ valores

    private int lookup(String type, String name) throws Exception {
        Integer v = out.ids.get(type + "/" + name);
        if (v == null) throw new Exception("Recurso não encontrado: @" + type + "/" + name);
        return v;
    }

    private static AxmlWriter.Val bool(boolean b) {
        AxmlWriter.Val v = new AxmlWriter.Val();
        v.type = AxmlWriter.T_BOOL;
        v.data = b ? -1 : 0;
        return v;
    }

    private static AxmlWriter.Val str(String s) {
        AxmlWriter.Val v = new AxmlWriter.Val();
        v.type = AxmlWriter.T_STR;
        v.str = s;
        return v;
    }

    private static AxmlWriter.Val num(int type, int data) {
        AxmlWriter.Val v = new AxmlWriter.Val();
        v.type = type;
        v.data = data;
        return v;
    }

    private Res buildValue(Decl d) throws Exception {
        Res r = new Res();
        r.type = d.type;
        r.name = d.name;
        r.cfg = d.cfg;
        String text = d.el.getTextContent();
        switch (d.type) {
            case "string": {
                String t = text.trim();
                r.val = t.startsWith("@") && !t.contains(" ") ? ref(t) : str(processString(text));
                break;
            }
            case "color":
                r.val = text.trim().startsWith("@") ? ref(text.trim()) : color(text.trim());
                break;
            case "dimen":
                r.val = text.trim().startsWith("@") ? ref(text.trim()) : dimension(text.trim(), d.name);
                break;
            case "integer": {
                String t = text.trim();
                if (t.startsWith("@")) {
                    r.val = ref(t);
                } else {
                    r.val = num(AxmlWriter.T_DEC, parseInt(t, d.name));
                }
                break;
            }
            case "bool": {
                String t = text.trim();
                if (t.startsWith("@")) r.val = ref(t);
                else if (t.equals("true")) r.val = bool(true);
                else if (t.equals("false")) r.val = bool(false);
                else throw new Exception("Valor inválido em <bool name=\"" + d.name + "\">: " + t);
                break;
            }
            case "id":
                r.val = bool(false);
                break;
            case "style":
                buildStyle(r, d.el);
                break;
            default:
                throw new Exception("Tipo não suportado: " + d.type);
        }
        return r;
    }

    private void buildStyle(Res r, Element e) throws Exception {
        r.bag = true;
        String parent = e.hasAttribute("parent") ? e.getAttribute("parent").trim() : null;
        if (parent == null) {
            int dot = r.name.lastIndexOf('.');
            if (dot > 0) {
                String implicit = r.name.substring(0, dot);
                if (!styleNames.contains(implicit)) throw new Exception("Estilo pai não encontrado: " + implicit);
                r.parent = lookup("style", implicit);
            }
        } else if (!parent.isEmpty()) {
            String p = parent.startsWith("@") ? parent.substring(1) : parent;
            if (p.startsWith("style/")) p = p.substring(6);
            if (p.startsWith("android:")) {
                String n = p.substring(8);
                if (n.startsWith("style/")) n = n.substring(6);
                int id = env.framework("style", n);
                if (id == 0) throw new Exception("Estilo do Android não encontrado: " + parent);
                r.parent = id;
            } else {
                r.parent = lookup("style", p);
            }
        }
        TreeMap<Long, AxmlWriter.Val> items = new TreeMap<>();
        for (Node n = e.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (!(n instanceof Element) || !((Element) n).getTagName().equals("item")) continue;
            Element it = (Element) n;
            String an = it.getAttribute("name");
            if (!an.startsWith("android:")) throw new Exception("Item de estilo com atributo que não é do Android: " + an + " (em " + r.name + ")");
            String local = an.substring(8);
            int id = env.attr(local);
            if (id == 0) throw new Exception("Atributo desconhecido em estilo: " + an);
            AxmlWriter.Val v = infer(local, it.getTextContent().trim());
            items.put(id & 0xFFFFFFFFL, v);
        }
        for (Map.Entry<Long, AxmlWriter.Val> en : items.entrySet()) {
            r.keys.add(new int[]{(int) (long) en.getKey()});
            r.vals.add(en.getValue());
        }
    }

    // ------------------------------------------------------------------ valores: texto

    static String processString(String raw) {
        String s = raw;
        String t = s.trim();
        boolean quoted = t.length() >= 2 && t.startsWith("\"") && t.endsWith("\"");
        if (quoted) {
            s = t.substring(1, t.length() - 1);
        } else {
            s = t.replaceAll("\\s+", " ");
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                switch (n) {
                    case 'n':
                        sb.append('\n');
                        break;
                    case 't':
                        sb.append('\t');
                        break;
                    case 'u':
                        if (i + 4 < s.length()) {
                            try {
                                sb.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16));
                                i += 4;
                                break;
                            } catch (NumberFormatException ignored) {
                            }
                        }
                        sb.append('u');
                        break;
                    default:
                        sb.append(n);
                }
            } else if (c == '"' && !quoted) {
                // aspas soltas são removidas, como no aapt
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private static int parseInt(String t, String what) throws Exception {
        try {
            return t.startsWith("0x") ? (int) Long.parseLong(t.substring(2), 16) : Integer.parseInt(t);
        } catch (NumberFormatException e) {
            throw new Exception("Número inválido em " + what + ": " + t);
        }
    }

    static AxmlWriter.Val color(String t) throws Exception {
        if (!t.startsWith("#")) throw new Exception("Cor inválida: " + t);
        String h = t.substring(1);
        long v;
        try {
            v = Long.parseLong(h, 16);
        } catch (NumberFormatException e) {
            throw new Exception("Cor inválida: " + t);
        }
        switch (h.length()) {
            case 3: {
                int r = (int) ((v >> 8) & 0xF) * 17, g = (int) ((v >> 4) & 0xF) * 17, b = (int) (v & 0xF) * 17;
                return num(0x1f, 0xFF000000 | (r << 16) | (g << 8) | b);
            }
            case 4: {
                int a = (int) ((v >> 12) & 0xF) * 17, r = (int) ((v >> 8) & 0xF) * 17,
                        g = (int) ((v >> 4) & 0xF) * 17, b = (int) (v & 0xF) * 17;
                return num(0x1e, (a << 24) | (r << 16) | (g << 8) | b);
            }
            case 6:
                return num(0x1d, 0xFF000000 | (int) v);
            case 8:
                return num(0x1c, (int) v);
            default:
                throw new Exception("Cor inválida: " + t);
        }
    }

    private static final Pattern DIM = Pattern.compile("^(-?[0-9]*\\.?[0-9]+)(dp|dip|sp|px|pt|in|mm)$");

    static AxmlWriter.Val dimension(String t, String what) throws Exception {
        Matcher m = DIM.matcher(t);
        if (!m.matches()) throw new Exception("Dimensão inválida em " + what + ": " + t + " (use, por exemplo, 16dp)");
        return num(0x05, complex(Float.parseFloat(m.group(1)), unit(m.group(2))));
    }

    private static int unit(String u) {
        switch (u) {
            case "px":
                return 0;
            case "dp":
            case "dip":
                return 1;
            case "sp":
                return 2;
            case "pt":
                return 3;
            case "in":
                return 4;
            default:
                return 5; // mm
        }
    }

    /** Codifica valor + unidade no formato "complex" do Android. */
    static int complex(float value, int unit) {
        boolean neg = value < 0;
        if (neg) value = -value;
        long bits = (long) (value * (1 << 23) + 0.5f);
        int radix;
        int shift;
        if ((bits & 0x7fffff) == 0) {
            radix = 0;
            shift = 23;
        } else if ((bits & 0xffffffffff800000L) == 0) {
            radix = 3;
            shift = 0;
        } else if ((bits & 0xffffffff80000000L) == 0) {
            radix = 2;
            shift = 8;
        } else if ((bits & 0xffffff8000000000L) == 0) {
            radix = 1;
            shift = 16;
        } else {
            radix = 0;
            shift = 23;
        }
        int mantissa = (int) ((bits >> shift) & 0xffffff);
        if (neg) mantissa = (-mantissa) & 0xffffff;
        return (mantissa << 8) | (radix << 4) | unit;
    }

    // ------------------------------------------------------------------ referências e inferência

    private AxmlWriter.Val ref(String v) throws Exception {
        String s = v.substring(1);
        if (s.equals("null")) return num(AxmlWriter.T_REF, 0);
        if (s.startsWith("+")) s = s.substring(1);
        if (s.startsWith("*")) s = s.substring(1);
        int slash = s.indexOf('/');
        if (slash < 0) throw new Exception("Referência inválida: " + v);
        String left = s.substring(0, slash);
        String name = s.substring(slash + 1);
        String type = left;
        String p = null;
        int colon = left.indexOf(':');
        if (colon >= 0) {
            p = left.substring(0, colon);
            type = left.substring(colon + 1);
        }
        int id;
        if ("android".equals(p)) {
            id = env.framework(type, name);
            if (id == 0) throw new Exception("Recurso do Android não encontrado: " + v);
        } else {
            id = lookup(type, name);
        }
        return num(AxmlWriter.T_REF, id);
    }

    private AxmlWriter.Val attrRef(String v) throws Exception {
        String s = v.substring(1);
        if (s.startsWith("android:")) s = s.substring(8);
        else throw new Exception("Referência ?attr do app não é suportada: " + v);
        if (s.startsWith("attr/")) s = s.substring(5);
        int id = env.attr(s);
        if (id == 0) throw new Exception("Atributo do Android não encontrado: " + v);
        return num(0x02, id);
    }

    private static final Pattern INT = Pattern.compile("^-?[0-9]+$|^0x[0-9a-fA-F]+$");
    private static final Pattern FLT = Pattern.compile("^-?[0-9]*\\.[0-9]+$");

    private AxmlWriter.Val infer(String attr, String text) throws Exception {
        String t = text.trim();
        if (t.startsWith("@")) return ref(t);
        if (t.startsWith("?")) return attrRef(t);
        if (STRING_ATTRS.contains(attr)) return str(processString(text));

        Map<String, Integer> table = ENUMS.get(attr);
        if (table != null) {
            boolean decimal = attr.equals("layout_width") || attr.equals("layout_height");
            if (table.containsKey(t) && !(t.isEmpty())) return num(decimal ? AxmlWriter.T_DEC : AxmlWriter.T_HEX, table.get(t));
            if (FLAG_ATTRS.contains(attr) && t.contains("|")) {
                int bits = 0;
                for (String part : t.split("\\|")) {
                    Integer b = table.get(part.trim());
                    if (b == null) throw new Exception("Valor não suportado em android:" + attr + ": " + part.trim());
                    bits |= b;
                }
                return num(AxmlWriter.T_HEX, bits);
            }
        }
        if (t.startsWith("#")) return color(t);
        if (DIM.matcher(t).matches()) return dimension(t, "android:" + attr);
        if (t.equals("true")) return bool(true);
        if (t.equals("false")) return bool(false);
        if (FLOAT_ATTRS.contains(attr) && (INT.matcher(t).matches() || FLT.matcher(t).matches())) {
            return num(0x04, Float.floatToIntBits(Float.parseFloat(t)));
        }
        if (INT.matcher(t).matches()) return num(AxmlWriter.T_DEC, parseInt(t, "android:" + attr));
        if (FLT.matcher(t).matches()) return num(0x04, Float.floatToIntBits(Float.parseFloat(t)));
        if (table != null) throw new Exception("Valor não suportado em android:" + attr + ": " + t);
        return str(processString(text));
    }

    // ------------------------------------------------------------------ XML -> binário

    private byte[] compileXml(Document doc, String path) throws Exception {
        try {
            return AxmlWriter.encode(convert(doc.getDocumentElement()));
        } catch (Exception e) {
            throw new Exception(path + ": " + e.getMessage());
        }
    }

    private AxmlWriter.Elem convert(Element el) throws Exception {
        AxmlWriter.Elem e = new AxmlWriter.Elem();
        e.name = el.getLocalName() != null ? el.getLocalName() : el.getNodeName();
        NamedNodeMap m = el.getAttributes();
        for (int i = 0; i < m.getLength(); i++) {
            Node a = m.item(i);
            String ns = a.getNamespaceURI();
            if (XMLNS.equals(ns)) continue;
            String local = a.getLocalName() != null ? a.getLocalName() : a.getNodeName();
            AxmlWriter.Attr at = new AxmlWriter.Attr();
            at.name = local;
            if (ns == null) {
                String v = a.getNodeValue().trim();
                at.ns = null;
                at.resId = 0;
                at.val = v.startsWith("@") ? ref(v) : str(v);
            } else if (AxmlWriter.NS.equals(ns)) {
                int id = env.attr(local);
                if (id == 0) throw new Exception("Atributo desconhecido: android:" + local + " em <" + e.name + ">");
                at.ns = AxmlWriter.NS;
                at.resId = id;
                at.val = infer(local, a.getNodeValue());
            } else if (AUTO.equals(ns)) {
                throw new Exception("O atributo app:" + local + " precisa de bibliotecas (AppCompat/Material), que o motor local ainda não tem");
            } else {
                continue; // tools: e outros são ignorados
            }
            e.attrs.add(at);
        }
        e.attrs.sort(Comparator.comparingLong(a -> a.resId == 0 ? Long.MAX_VALUE : (a.resId & 0xFFFFFFFFL)));
        for (Node n = el.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n instanceof Element) e.kids.add(convert((Element) n));
        }
        return e;
    }

    // ------------------------------------------------------------------ configurações (qualificadores)

    private static Cfg parseCfg(String qual, String dir) throws Exception {
        Cfg c = new Cfg();
        if (qual.isEmpty()) return c;
        c.key = qual;
        String[] parts = qual.split("-");
        for (int i = 0; i < parts.length; i++) {
            String p = parts[i];
            Integer dens = density(p);
            if (dens != null) {
                put16(c.bytes, 14, dens);
                c.flags |= 0x1000;
            } else if (p.equals("port") || p.equals("land")) {
                c.bytes[12] = (byte) (p.equals("port") ? 1 : 2);
                c.flags |= 0x80;
            } else if (p.equals("night") || p.equals("notnight")) {
                c.bytes[29] = (byte) (p.equals("night") ? 0x20 : 0x10);
                c.flags |= 0x200;
            } else if (p.matches("v[0-9]+")) {
                put16(c.bytes, 24, Integer.parseInt(p.substring(1)));
                c.flags |= 0x8000;
            } else if (p.matches("sw[0-9]+dp")) {
                put16(c.bytes, 30, Integer.parseInt(p.substring(2, p.length() - 2)));
                c.flags |= 0x800;
            } else if (p.matches("w[0-9]+dp")) {
                put16(c.bytes, 32, Integer.parseInt(p.substring(1, p.length() - 2)));
                c.flags |= 0x400;
            } else if (p.matches("h[0-9]+dp")) {
                put16(c.bytes, 34, Integer.parseInt(p.substring(1, p.length() - 2)));
                c.flags |= 0x400;
            } else if (p.matches("[a-z]{2}")) {
                c.bytes[8] = (byte) p.charAt(0);
                c.bytes[9] = (byte) p.charAt(1);
                c.flags |= 0x4;
            } else if (p.matches("r[A-Z]{2}") && c.bytes[8] != 0) {
                c.bytes[10] = (byte) p.charAt(1);
                c.bytes[11] = (byte) p.charAt(2);
            } else {
                throw new Exception("Qualificador não suportado na pasta res/" + dir + "/: " + p);
            }
        }
        return c;
    }

    private static Integer density(String p) {
        switch (p) {
            case "ldpi":
                return 120;
            case "mdpi":
                return 160;
            case "tvdpi":
                return 213;
            case "hdpi":
                return 240;
            case "xhdpi":
                return 320;
            case "xxhdpi":
                return 480;
            case "xxxhdpi":
                return 640;
            case "nodpi":
                return 0xFFFF;
            case "anydpi":
                return 0xFFFE;
            default:
                return null;
        }
    }

    // ------------------------------------------------------------------ escrita binária

    private static void put16(byte[] b, int o, int v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
    }

    private static void put32(byte[] b, int o, int v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
        b[o + 2] = (byte) (v >> 16);
        b[o + 3] = (byte) (v >> 24);
    }

    private static final class W {
        final ByteArrayOutputStream b = new ByteArrayOutputStream();

        void u8(int v) {
            b.write(v & 0xFF);
        }

        void u16(int v) {
            b.write(v & 0xFF);
            b.write((v >> 8) & 0xFF);
        }

        void u32(int v) {
            u16(v & 0xFFFF);
            u16((v >>> 16) & 0xFFFF);
        }

        void bytes(byte[] x) {
            b.write(x, 0, x.length);
        }

        int size() {
            return b.size();
        }

        byte[] get() {
            return b.toByteArray();
        }
    }

    private static final class Pool {
        final LinkedHashMap<String, Integer> map = new LinkedHashMap<>();

        int idx(String s) {
            Integer i = map.get(s);
            if (i == null) {
                i = map.size();
                map.put(s, i);
            }
            return i;
        }

        byte[] chunk() throws Exception {
            List<String> strs = new ArrayList<>(map.keySet());
            W data = new W();
            int[] offs = new int[strs.size()];
            for (int i = 0; i < strs.size(); i++) {
                offs[i] = data.size();
                String s = strs.get(i);
                if (s.length() > 0x7FFF) throw new Exception("Texto longo demais nos recursos");
                data.u16(s.length());
                data.bytes(s.getBytes(StandardCharsets.UTF_16LE));
                data.u16(0);
            }
            while (data.size() % 4 != 0) data.u8(0);
            int stringsStart = 28 + 4 * strs.size();
            W w = new W();
            w.u16(0x0001);
            w.u16(28);
            w.u32(stringsStart + data.size());
            w.u32(strs.size());
            w.u32(0);
            w.u32(0);
            w.u32(stringsStart);
            w.u32(0);
            for (int o : offs) w.u32(o);
            w.bytes(data.get());
            return w.get();
        }
    }

    private void writeValue(W w, AxmlWriter.Val v, Pool global) {
        w.u16(8);
        w.u8(0);
        w.u8(v.type);
        w.u32(v.type == AxmlWriter.T_STR ? global.idx(v.str) : v.data);
    }

    private byte[] writeTable() throws Exception {
        Pool global = new Pool();
        Pool typePool = new Pool();
        Pool keyPool = new Pool();
        W types = new W();

        int typeCount = 0;
        for (String t : TYPE_ORDER) {
            Integer tid = typeIds.get(t);
            if (tid == null) continue;
            typeCount++;
            typePool.idx(t);
            TreeSet<String> nameSet = names.get(t);
            List<String> nameList = new ArrayList<>(nameSet);
            int entryCount = nameList.size();
            Map<String, Integer> entryIndex = new HashMap<>();
            for (int i = 0; i < nameList.size(); i++) {
                entryIndex.put(nameList.get(i), i);
                keyPool.idx(nameList.get(i));
            }

            // agrupar por configuração (padrão primeiro)
            Map<String, List<Res>> byCfg = new TreeMap<>();
            int[] spec = new int[entryCount];
            for (Res r : all) {
                if (!r.type.equals(t)) continue;
                byCfg.computeIfAbsent(r.cfg.key, k -> new ArrayList<>()).add(r);
                spec[entryIndex.get(r.name)] |= r.cfg.flags;
            }

            W ts = new W();
            ts.u16(0x0202);
            ts.u16(16);
            ts.u32(16 + 4 * entryCount);
            ts.u8(tid);
            ts.u8(0);
            ts.u16(0);
            ts.u32(entryCount);
            for (int f : spec) ts.u32(f);
            types.bytes(ts.get());

            for (Map.Entry<String, List<Res>> g : byCfg.entrySet()) {
                List<Res> list = g.getValue();
                Map<Integer, byte[]> data = new TreeMap<>();
                for (Res r : list) {
                    if (data.containsKey(entryIndex.get(r.name))) {
                        throw new Exception("Recurso duplicado: " + t + "/" + r.name);
                    }
                    W e = new W();
                    int key = keyPool.idx(r.name);
                    if (!r.bag) {
                        e.u16(8);
                        e.u16(0);
                        e.u32(key);
                        writeValue(e, r.val, global);
                    } else {
                        e.u16(16);
                        e.u16(1);
                        e.u32(key);
                        e.u32(r.parent);
                        e.u32(r.keys.size());
                        for (int i = 0; i < r.keys.size(); i++) {
                            e.u32(r.keys.get(i)[0]);
                            writeValue(e, r.vals.get(i), global);
                        }
                    }
                    data.put(entryIndex.get(r.name), e.get());
                }
                W body = new W();
                int[] offs = new int[entryCount];
                Arrays.fill(offs, -1);
                for (Map.Entry<Integer, byte[]> en : data.entrySet()) {
                    offs[en.getKey()] = body.size();
                    body.bytes(en.getValue());
                }
                int headerSize = 84;
                W tc = new W();
                tc.u16(0x0201);
                tc.u16(headerSize);
                tc.u32(headerSize + 4 * entryCount + body.size());
                tc.u8(tid);
                tc.u8(0);
                tc.u16(0);
                tc.u32(entryCount);
                tc.u32(headerSize + 4 * entryCount);
                tc.bytes(list.get(0).cfg.bytes);
                for (int o : offs) tc.u32(o);
                tc.bytes(body.get());
                types.bytes(tc.get());
            }
        }

        byte[] gp = global.chunk();
        byte[] tp = typePool.chunk();
        byte[] kp = keyPool.chunk();
        byte[] body = types.get();

        W pk = new W();
        pk.u16(0x0200);
        pk.u16(288);
        pk.u32(288 + tp.length + kp.length + body.length);
        pk.u32(0x7f);
        byte[] nameBytes = new byte[256];
        byte[] pn = pkg.getBytes(StandardCharsets.UTF_16LE);
        System.arraycopy(pn, 0, nameBytes, 0, Math.min(pn.length, 254));
        pk.bytes(nameBytes);
        pk.u32(288);
        pk.u32(typeCount);
        pk.u32(288 + tp.length);
        pk.u32(keyPool.map.size());
        pk.u32(0);
        pk.bytes(tp);
        pk.bytes(kp);
        pk.bytes(body);
        byte[] pkgChunk = pk.get();

        W t = new W();
        t.u16(0x0002);
        t.u16(12);
        t.u32(12 + gp.length + pkgChunk.length);
        t.u32(1);
        t.bytes(gp);
        t.bytes(pkgChunk);
        return t.get();
    }

    private String writeR() {
        StringBuilder sb = new StringBuilder();
        sb.append("/* Gerado pelo ANDROIDSDK. Não edite. */\n");
        sb.append("package ").append(pkg).append(";\n\n");
        sb.append("public final class R {\n");
        for (String t : TYPE_ORDER) {
            TreeSet<String> set = names.get(t);
            if (set == null || set.isEmpty()) continue;
            sb.append("    public static final class ").append(t).append(" {\n");
            for (String n : set) {
                sb.append("        public static final int ").append(n.replace('.', '_').replace('-', '_'))
                        .append(" = 0x").append(Integer.toHexString(out.ids.get(t + "/" + n))).append(";\n");
            }
            sb.append("    }\n");
        }
        sb.append("}\n");
        return sb.toString();
    }
}
