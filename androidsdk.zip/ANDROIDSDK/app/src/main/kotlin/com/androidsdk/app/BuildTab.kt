package com.androidsdk.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import java.io.File
import java.io.InputStream
import kotlin.concurrent.thread

class BuildTab(private val a: MainActivity) {

    private class Src(val name: String, val read: () -> ByteArray, val dir: (() -> File)? = null)

    private var src: Src? = null
    private var log = ""
    private var busy = false
    private var apk: File? = null
    private var logView: TextView? = null
    private var progress: ProgressBar? = null

    fun useProject(name: String) {
        val d = Projects.dir(a, name)
        src = Src("$name.zip", { Zips.zipBytes(d) }, { d })
    }

    private fun unpack(name: String, open: () -> InputStream?): File {
        val d = File(a.cacheDir, "zipsrc/" + Projects.safe(name))
        d.deleteRecursively()
        val ins = open() ?: throw Exception("Arquivo ilegível")
        ins.use { Zips.unzip(it, d) }
        return d
    }

    private fun addLog(m: String) {
        log += (if (log.isEmpty()) "" else "\n") + m
        a.runOnUiThread { logView?.text = log }
    }

    fun show() {
        val ui = a.ui
        val r = a.root
        ui.add(r, ui.title(t("Compilar APK", "Build APK")), 4)
        ui.add(r, ui.sub(t("Escolha o que compilar e o motor.", "Choose what to build and the engine.")), 12)

        val eng = ui.card()
        eng.addView(ui.text(t("Motores de compilação", "Build engines"), ui.fs, ui.p.text, true))
        eng.addView(ui.sub("🏠 " + t("Local (no celular, sem GitHub): Java e XML/res. Kotlin é experimental.", "Local (on-device, no GitHub): Java and XML/res. Kotlin is experimental.")))
        val kt = if (KotlinEngine.bundled(a) || KotlinEngine.ready(a)) t("embutido neste app", "bundled in this app") else t("não embutido neste build", "not bundled in this build")
        eng.addView(ui.sub("🧪 Kotlin (" + t("experimental, roda em processo separado", "experimental, runs in a separate process") + "): $kt"))
        val gh = if (GitHubSvc.connected()) t("conectado como @", "connected as @") + Cfg.ghLogin else t("não conectado", "not connected")
        eng.addView(ui.sub("☁ GitHub (" + t("opcional; compila qualquer projeto Gradle", "optional; builds any Gradle project") + "): $gh"))
        ui.add(r, eng, 12)

        val s = src
        val srcCard = ui.card()
        srcCard.addView(ui.text(t("O que compilar", "What to build"), ui.fs, ui.p.text, true))
        srcCard.addView(ui.sub(if (s == null) t("Nada escolhido.", "Nothing chosen.") else "✔ " + s.name))
        ui.add(r, srcCard, 8)

        ui.add(r, ui.btn("📁 " + t("Usar um projeto do app", "Use an app project")) { pickProject() })
        ui.add(r, ui.btn("📦 " + t("Escolher um ZIP", "Choose a ZIP")) { pickZip() })
        ui.add(r, ui.btn("🔎 " + t("Procurar ZIPs no celular", "Search ZIPs on the phone")) { scanZips() }, 12)

        ui.add(r, ui.btn(if (busy) t("Compilando...", "Building...") else "🏠 " + t("Compilar no celular", "Build on-device"), true) { startLocal() }, 8)
        if (GitHubSvc.connected()) {
            ui.add(r, ui.btn("☁ " + t("Compilar pelo GitHub", "Build via GitHub")) { startGitHub() }, 12)
        } else {
            ui.add(r, ui.btn("⚙ " + t("Conectar o GitHub (opcional)", "Connect GitHub (optional)")) { a.go(5) }, 12)
        }

        val pb = ProgressBar(a)
        pb.isIndeterminate = true
        pb.visibility = if (busy) View.VISIBLE else View.GONE
        progress = pb
        ui.add(r, pb, 8)

        val lv = ui.mono(log)
        logView = lv
        if (log.isNotEmpty() || busy) {
            val c = ui.card()
            c.addView(lv)
            ui.add(r, c, 8)
        }

        val f = apk
        if (f != null) {
            ui.add(r, ui.btn("📲 " + t("Instalar APK", "Install APK"), true) { a.installApk(f) }, 8)
        }
    }

    private fun begin(): Src? {
        val s = src
        if (s == null) {
            a.toast(t("Escolha o que compilar primeiro.", "Choose what to build first."))
            return null
        }
        if (busy) return null
        busy = true
        apk = null
        log = ""
        a.render()
        return s
    }

    private fun end() {
        busy = false
        a.runOnUiThread { if (a.cur == 2) a.render() }
    }

    private fun startLocal() {
        val s = begin() ?: return
        thread {
            try {
                val dirFn = s.dir ?: throw Exception("Fonte inválida")
                apk = LocalBuilder.build(a, dirFn(), s.name.removeSuffix(".zip"), { addLog(it) })
            } catch (e: Throwable) {
                addLog(t("Erro: ", "Error: ") + e.javaClass.simpleName + ": " + (e.message ?: ""))
                val trace = Log.getStackTraceString(e).lines().take(8).joinToString("\n")
                addLog(trace)
            }
            end()
        }
    }

    private fun startGitHub() {
        val s = begin() ?: return
        thread {
            try {
                val bytes = s.read()
                apk = GitHubSvc.build(a, s.name, bytes) { addLog(it) }
            } catch (e: Exception) {
                addLog(t("Erro: ", "Error: ") + e.message)
            }
            end()
        }
    }

    private fun pickProject() {
        val names = Projects.list(a)
        if (names.isEmpty()) {
            a.toast(t("Crie um projeto na aba Código primeiro.", "Create a project in the Code tab first."))
            return
        }
        a.choose(t("Projeto", "Project"), names) { i ->
            useProject(names[i])
            a.render()
        }
    }

    private fun pickZip() {
        a.pickFile { uri ->
            var name = "projeto.zip"
            a.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) name = c.getString(i) ?: name
            }
            val n = name
            src = Src(
                n,
                { a.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw Exception("Arquivo ilegível") },
                { unpack(n) { a.contentResolver.openInputStream(uri) } }
            )
            a.render()
        }
    }

    // ---------- Procurar ZIPs na memória ----------

    private fun hasStorage(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else a.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun scanZips() {
        if (!hasStorage()) {
            a.toast(t("Permita o acesso aos arquivos e volte aqui.", "Allow file access, then come back here."))
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    a.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${a.packageName}")))
                } catch (e: Exception) {
                    a.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            } else {
                a.requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 7)
            }
            return
        }
        a.toast(t("Procurando...", "Searching..."))
        thread {
            val found = ArrayList<File>()
            fun walk(d: File, depth: Int) {
                if (depth > 6 || found.size >= 200) return
                val list = d.listFiles() ?: return
                for (f in list) {
                    if (found.size >= 200) return
                    if (f.isDirectory) {
                        if (f.name.startsWith(".") || (depth == 0 && f.name == "Android")) continue
                        walk(f, depth + 1)
                    } else if (f.name.endsWith(".zip", true)) {
                        found.add(f)
                    }
                }
            }
            walk(Environment.getExternalStorageDirectory(), 0)
            found.sortByDescending { it.lastModified() }
            a.runOnUiThread {
                if (found.isEmpty()) {
                    a.toast(t("Nenhum ZIP encontrado.", "No ZIP found."))
                } else {
                    val shown = found.take(40)
                    a.choose(t("ZIPs encontrados", "ZIPs found"), shown.map { it.name + " (" + it.length() / 1024 + " KB)" }) { i ->
                        val f = shown[i]
                        src = Src(f.name, { f.readBytes() }, { unpack(f.name) { f.inputStream() } })
                        a.render()
                    }
                }
            }
        }
    }
}
