package com.androidsdk.app

import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Gh {
    class Resp(val code: Int, val body: String)

    fun call(
        method: String,
        url: String,
        token: String?,
        body: String? = null,
        contentType: String = "application/json",
        accept: String = "application/vnd.github+json"
    ): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20000
        c.readTimeout = 90000
        c.setRequestProperty("Accept", accept)
        c.setRequestProperty("User-Agent", "ANDROIDSDK-app")
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", contentType)
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val stream = if (code >= 400) c.errorStream else c.inputStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Resp(code, text)
    }

    /** Baixa um asset de release. O GitHub redireciona para outro servidor, que não aceita o token. */
    fun downloadAsset(repo: String, assetId: Long, token: String?, dest: File) {
        var c = URL("https://api.github.com/repos/$repo/releases/assets/$assetId")
            .openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.setRequestProperty("Accept", "application/octet-stream")
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("User-Agent", "ANDROIDSDK-app")
        var code = c.responseCode
        if (code in 300..399) {
            val loc = c.getHeaderField("Location")
            c = URL(loc).openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", "ANDROIDSDK-app")
            code = c.responseCode
        }
        if (code != 200) throw Exception("Download falhou ($code)")
        c.inputStream.use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
    }
}
