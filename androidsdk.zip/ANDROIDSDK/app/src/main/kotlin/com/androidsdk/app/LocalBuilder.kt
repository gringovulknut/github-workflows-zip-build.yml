package com.androidsdk.app

import android.content.Context
import android.content.res.Resources
import com.android.apksig.ApkSigner
import com.android.tools.r8.CompilationMode
import com.android.tools.r8.D8
import com.android.tools.r8.D8Command
import com.android.tools.r8.OutputMode
import com.androidsdk.app.engine.AxmlWriter
import com.androidsdk.app.engine.ResCompiler
import com.androidsdk.app.engine.SelfSigned
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec

/**
 * Motor de compilação 100% local (sem GitHub e sem internet).
 * res/ -> resources.arsc + XML binário + R.java; Kotlin/Java -> ECJ -> D8; manifest binário; assinatura (apksig).
 */
object LocalBuilder {

    private fun grab(text: String, re: String): String? = Regex(re).find(text)?.groupValues?.get(1)

    private val framework = object : ResCompiler.Env {
        override fun attr(name: String): Int = Resources.getSystem().getIdentifier(name, "attr", "android")
        override fun framework(type: String, name: String): Int = Resources.getSystem().getIdentifier(name, type, "android")
    }

    fun build(a: MainActivity, projectDir: File, rawName: String, log: (String) -> Unit): File {
        val name = Projects.safe(rawName).ifEmpty { "app" }
        val files = projectDir.walkTopDown().filter { it.isFile && !it.path.contains("/build/") }.toList()

        // ---- verificações do projeto ----
        val javaFiles = files.filter { it.extension == "java" }
        val ktFiles = files.filter { it.extension == "kt" }
        if (ktFiles.isNotEmpty() && !KotlinEngine.ready(a)) {
            if (KotlinEngine.bundled(a)) {
                KotlinEngine.prepare(a, log)
            } else {
                throw Exception(t("Este build do app não trouxe o compilador Kotlin. Gere o APK do ANDROIDSDK de novo pelo GitHub (a conversão é feita lá) ou compile este projeto pelo GitHub.", "This app build does not include the Kotlin compiler. Rebuild ANDROIDSDK via GitHub (the conversion happens there) or build this project via GitHub."))
            }
        }
        if (javaFiles.isEmpty() && ktFiles.isEmpty()) throw Exception(t("Nenhum arquivo .java ou .kt no projeto.", "No .java or .kt files in the project."))
        val manifests = files.filter { it.name == "AndroidManifest.xml" }
        val manifest = manifests.firstOrNull { it.path.contains("src/main") } ?: manifests.firstOrNull()
            ?: throw Exception(t("AndroidManifest.xml não encontrado no projeto.", "AndroidManifest.xml not found in the project."))
        val manifestText = manifest.readText()

        // ---- dados do app (manifest ou Gradle) ----
        val gradle = files.filter { it.name == "build.gradle" || it.name == "build.gradle.kts" }.joinToString("\n") { it.readText() }
        val pkg = grab(manifestText, """<manifest[^>]*\spackage\s*=\s*"([^"]+)"""")
            ?: grab(gradle, """namespace\s*=?\s*["']([^"']+)["']""")
            ?: javaFiles.firstNotNullOfOrNull { grab(it.readText(), """(?m)^\s*package\s+([\w.]+)\s*;""") }
            ?: throw Exception(t("Não achei o package do app.", "Could not find the app package."))
        val minSdk = grab(gradle, """minSdk(?:Version)?\s*=?\s*(\d+)""")?.toInt() ?: 24
        val targetSdk = grab(gradle, """targetSdk(?:Version)?\s*=?\s*(\d+)""")?.toInt() ?: 34
        val versionCode = grab(gradle, """versionCode\s*=?\s*(\d+)""")?.toInt() ?: 1
        val versionName = grab(gradle, """versionName\s*=?\s*["']([^"']+)["']""") ?: "1.0"
        log("📦 $pkg · minSdk $minSdk · targetSdk $targetSdk")

        val work = File(a.cacheDir, "localbuild/$name")
        work.deleteRecursively()
        work.mkdirs()

        // ---- 1) android.jar ----
        log("1/7 " + t("Preparando o android.jar...", "Preparing android.jar..."))
        val androidJar = ensureAndroidJar(a)

        // ---- 2) recursos (res/) ----
        var resOut: ResCompiler.Out? = null
        val gen = ArrayList<File>()
        val resDir = File(manifest.parentFile, "res").takeIf { it.isDirectory } ?: File(projectDir, "res").takeIf { it.isDirectory }
        if (resDir != null) {
            log("2/7 " + t("Compilando os recursos (res/)...", "Compiling resources (res/)..."))
            val map = LinkedHashMap<String, ByteArray>()
            resDir.walkTopDown().filter { it.isFile }.forEach { f ->
                map[f.relativeTo(resDir).path.replace(File.separatorChar, '/')] = f.readBytes()
            }
            resOut = ResCompiler.compile(map, pkg, framework)
            val g = File(work, "gen/" + pkg.replace('.', '/'))
            g.mkdirs()
            val rf = File(g, "R.java")
            rf.writeText(resOut.rJava)
            gen.add(rf)
        } else {
            log("2/7 " + t("Sem pasta res/, pulando.", "No res/ folder, skipping."))
        }

        // ---- 3) Kotlin e Java -> .class ----
        val classes = File(work, "classes")
        classes.mkdirs()
        val stdlib = KotlinEngine.stdlib(a)
        val allJava = javaFiles + gen
        if (ktFiles.isNotEmpty()) {
            log("3/7 " + t("Compilando Kotlin...", "Compiling Kotlin..."))
            val err = KotlinEngine.compile(a, androidJar, ktFiles + allJava, classes, log)
            if (err != null) throw Exception(err)
        }
        if (allJava.isNotEmpty()) {
            log("3/7 " + t("Compilando ${allJava.size} arquivo(s) Java...", "Compiling ${allJava.size} Java file(s)..."))
            val sw = StringWriter()
            val pw = PrintWriter(sw)
            val args = ArrayList<String>()
            args.addAll(listOf("-1.8", "-proc:none", "-nowarn", "-encoding", "UTF-8", "-bootclasspath", androidJar.path))
            if (ktFiles.isNotEmpty()) args.addAll(listOf("-classpath", classes.path + File.pathSeparator + stdlib.path))
            args.addAll(listOf("-d", classes.path))
            allJava.forEach { args.add(it.path) }
            val ok = org.eclipse.jdt.internal.compiler.batch.Main(pw, pw, false, null, null).compile(args.toTypedArray())
            pw.flush()
            if (!ok) throw Exception(t("Erros de compilação:\n", "Compilation errors:\n") + sw.toString().take(4000))
        }

        // ---- 4) .class -> classes.dex (D8) ----
        log("4/7 " + t("Gerando o DEX (D8)...", "Generating DEX (D8)..."))
        val jar = File(work, "classes.jar")
        jar.outputStream().use { Zips.zipTo(classes, it) }
        val dexDir = File(work, "dex")
        dexDir.mkdirs()
        val cmdB = D8Command.builder().addProgramFiles(jar.toPath())
        if (ktFiles.isNotEmpty()) cmdB.addProgramFiles(stdlib.toPath())
        val cmd = cmdB
            .addLibraryFiles(androidJar.toPath())
            .setOutput(dexDir.toPath(), OutputMode.DexIndexed)
            .setMinApiLevel(minSdk)
            .setMode(CompilationMode.DEBUG)
            .build()
        D8.run(cmd)
        val dexes = dexDir.listFiles()?.filter { it.name.endsWith(".dex") }?.sortedBy { it.name } ?: emptyList()
        if (dexes.isEmpty()) throw Exception(t("O D8 não gerou nenhum classes.dex.", "D8 produced no classes.dex."))

        // ---- 5) manifest binário ----
        log("5/7 " + t("Convertendo o AndroidManifest...", "Converting AndroidManifest..."))
        val ro = resOut
        val resolver = object : AxmlWriter.Resolver {
            override fun resolve(type: String, name: String): Int = Resources.getSystem().getIdentifier(name, type, "android")
            override fun resolveApp(type: String, name: String): Int = ro?.idOf(type, name) ?: 0
        }
        val axml = AxmlWriter.build(manifestText, pkg, minSdk, targetSdk, versionCode, versionName, resolver)

        // ---- 6) montar o APK ----
        log("6/7 " + t("Montando o APK...", "Packaging the APK..."))
        val unsigned = File(work, "unsigned.apk")
        AlignedZip(unsigned.outputStream().buffered()).use { z ->
            z.addDeflated("AndroidManifest.xml", axml)
            if (ro != null) {
                z.addStored("resources.arsc", ro.arsc)
                ro.files.forEach { (p, d) -> z.addDeflated(p, d) }
            }
            dexes.forEach { z.addDeflated(it.name, it.readBytes()) }
            val assets = File(manifest.parentFile, "assets")
            if (assets.isDirectory) {
                assets.walkTopDown().filter { it.isFile }.forEach { f ->
                    z.addDeflated("assets/" + f.relativeTo(assets).path.replace(File.separatorChar, '/'), f.readBytes())
                }
            }
        }

        // ---- 7) assinar ----
        log("7/7 " + t("Assinando o APK...", "Signing the APK..."))
        val out = File(File(a.getExternalFilesDir(null), "apks").apply { mkdirs() }, "$name-local.apk")
        sign(a, unsigned, out, minSdk)
        work.deleteRecursively()
        log(t("Pronto! APK gerado no celular (${out.length() / 1024} KB).", "Done! APK built on the phone (${out.length() / 1024} KB)."))
        return out
    }

    /** Assina com a chave própria do app (criada uma vez). */
    fun sign(a: Context, input: File, output: File, minSdk: Int) {
        val (key, cert) = signerKey(a)
        if (output.exists()) output.delete()
        val sc = ApkSigner.SignerConfig.Builder("androidsdk", key, listOf(cert)).build()
        ApkSigner.Builder(listOf(sc))
            .setInputApk(input)
            .setOutputApk(output)
            .setMinSdkVersion(minSdk)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(false)
            .build()
            .sign()
    }

    fun ensureAndroidJar(a: Context): File {
        val dst = File(a.filesDir, "engine/android.jar")
        if (dst.exists() && dst.length() > 1_000_000) return dst
        dst.parentFile?.mkdirs()
        try {
            a.assets.open("android.jar").use { input -> dst.outputStream().use { input.copyTo(it) } }
        } catch (e: Exception) {
            dst.delete()
            throw Exception(t("O android.jar não veio embutido neste build do app. Compile o ANDROIDSDK de novo pelo GitHub.", "android.jar was not bundled in this app build. Build ANDROIDSDK again via GitHub."))
        }
        return dst
    }

    /** Chave de assinatura própria, criada uma vez e guardada no app (mesma chave = atualizações funcionam). */
    private fun signerKey(a: Context): Pair<PrivateKey, X509Certificate> {
        val dir = File(a.filesDir, "engine")
        dir.mkdirs()
        val kf = File(dir, "key.pk8")
        val cf = File(dir, "cert.der")
        if (kf.exists() && cf.exists()) {
            try {
                val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
                val cert = cf.inputStream().use { CertificateFactory.getInstance("X.509").generateCertificate(it) } as X509Certificate
                return Pair(key, cert)
            } catch (e: Exception) {
                kf.delete()
                cf.delete()
            }
        }
        val r = SelfSigned.create("ANDROIDSDK")
        kf.writeBytes(r.key.encoded)
        cf.writeBytes(r.cert.encoded)
        return Pair(r.key, r.cert)
    }
}
