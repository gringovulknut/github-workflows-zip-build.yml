package com.androidsdk.app

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Fábrica de views com o tema, a fonte e o tamanho de texto escolhidos. */
class Ui(val a: Activity) {
    val p: Pal = Themes.get(Cfg.theme)
    val fs: Float = Cfg.fontSize.toFloat()
    val face: Typeface = Fonts.face(Cfg.font)

    fun dp(v: Int): Int = (v * a.resources.displayMetrics.density).toInt()

    fun shape(color: Int, radius: Int = 14, stroke: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) d.setStroke(dp(1), stroke)
        return d
    }

    fun text(s: String, size: Float = fs, color: Int = p.text, bold: Boolean = false): TextView {
        val t = TextView(a)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        t.typeface = if (bold) Typeface.create(face, Typeface.BOLD) else face
        return t
    }

    fun title(s: String): TextView = text(s, fs + 9, p.text, true)

    fun sub(s: String): TextView = text(s, fs - 2, p.sub)

    fun mono(s: String): TextView {
        val t = text(s, fs - 2)
        t.typeface = Typeface.MONOSPACE
        t.setTextIsSelectable(true)
        return t
    }

    fun btn(label: String, primary: Boolean = false, onClick: () -> Unit): Button {
        val b = Button(a)
        b.text = label
        b.isAllCaps = false
        b.textSize = fs - 1
        b.typeface = face
        b.stateListAnimator = null
        b.setTextColor(if (primary) p.onAccent else p.text)
        b.background = if (primary) shape(p.accent, 12) else shape(p.card, 12, p.border)
        b.setPadding(dp(14), dp(10), dp(14), dp(10))
        b.minHeight = 0
        b.minimumHeight = 0
        b.setOnClickListener { onClick() }
        return b
    }

    fun edit(hint: String, value: String? = null, mono: Boolean = false, lines: Int = 1): EditText {
        val e = EditText(a)
        e.hint = hint
        e.setText(value ?: "")
        e.setTextColor(p.text)
        e.setHintTextColor(p.sub)
        e.textSize = if (mono) fs - 1 else fs
        e.typeface = if (mono) Typeface.MONOSPACE else face
        e.background = shape(p.surface, 10, p.border)
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        if (lines > 1) {
            e.minLines = lines
            e.gravity = Gravity.TOP or Gravity.START
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        } else {
            e.setSingleLine(true)
        }
        return e
    }

    fun check(label: String, checked: Boolean, onChange: (Boolean) -> Unit): CheckBox {
        val c = CheckBox(a)
        c.text = label
        c.isChecked = checked
        c.textSize = fs
        c.typeface = face
        c.setTextColor(p.text)
        c.buttonTintList = ColorStateList.valueOf(p.accent)
        c.setOnCheckedChangeListener { _, v -> onChange(v) }
        return c
    }

    fun card(): LinearLayout {
        val l = LinearLayout(a)
        l.orientation = LinearLayout.VERTICAL
        l.background = shape(p.card, 16, p.border)
        l.setPadding(dp(14), dp(14), dp(14), dp(14))
        return l
    }

    fun row(): LinearLayout {
        val l = LinearLayout(a)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }

    fun add(parent: LinearLayout, v: View, mb: Int = 8) {
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(mb)
        parent.addView(v, lp)
    }

    fun addW(parent: LinearLayout, v: View, weight: Float = 1f, mr: Int = 0) {
        val lp = if (weight > 0f) {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight)
        } else {
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        lp.rightMargin = dp(mr)
        parent.addView(v, lp)
    }
}
