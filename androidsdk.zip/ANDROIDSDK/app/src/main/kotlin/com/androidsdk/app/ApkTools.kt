package com.androidsdk.app

import com.androidsdk.app.engine.ArscReader
import com.androidsdk.app.engine.AxmlReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import android.content.Context
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ApkTools {

    private fun find(text: String, re: String): String? = Regex(re).find(text)?.groupValues?.get(1)

    private fun findAll(text: String, re: String): List<String> =
        Regex(re).findAll(text).map { it.groupValues[1] }.toList()

    /** Abre o APK, gera um ZIP com todo o conteúdo + manifest legível + resumo, e devolve o resumo. */
    fun extract(input: InputStream, apkName: String, apkSize: Long, out: File): String {
        out.parentFile?.mkdirs()
        var manifest: ByteArray? = null
        var arsc: ByteArray? = null
        val entries = ArrayList<Pair<String, Long>>()
        var skipped = 0

        ZipOutputStream(out.outputStream().buffered()).use { zo ->
            ZipInputStream(input.buffered()).use { zi ->
                val seen = HashSet<String>()
                val buf = ByteArray(64 * 1024)
                var e = zi.nextEntry
                while (e != null) {
                    val name = e.name
                    if (!e.isDirectory) {
                        if (name.contains("..") || name.startsWith("/") || !seen.add(name)) {
                            skipped++
                        } else {
                            zo.putNextEntry(ZipEntry(name))
                            val keepManifest = if (name == "AndroidManifest.xml") ByteArrayOutputStream() else null
                            val keepArsc = if (name == "resources.arsc" && e.size in 1..30_000_000) ByteArrayOutputStream() else null
                            var total = 0L
                            while (true) {
                                val n = zi.read(buf)
                                if (n < 0) break
                                zo.write(buf, 0, n)
                                keepManifest?.write(buf, 0, n)
                                keepArsc?.write(buf, 0, n)
                                total += n
                            }
                            zo.closeEntry()
                            if (keepManifest != null) manifest = keepManifest.toByteArray()
                            if (keepArsc != null) arsc = keepArsc.toByteArray()
                            entries.add(name to total)
                        }
                    }
                    e = zi.nextEntry
                }
            }

            // manifest legível
            var decoded = ""
            var decodeError = ""
            val m = manifest
            if (m != null) {
                try {
                    decoded = AxmlReader.decode(m)
                    zo.putNextEntry(ZipEntry("decoded/AndroidManifest.xml"))
                    zo.write(decoded.toByteArray(Charsets.UTF_8))
                    zo.closeEntry()
                } catch (ex: Throwable) {
                    decodeError = ex.message ?: ex.javaClass.simpleName
                }
            }

            // resources.arsc legível (strings, cores, dimensões, estilos por tipo)
            var resSummary = ""
            val rs = arsc
            if (rs != null) {
                try {
                    resSummary = t("Recursos de ", "Resources from ") + apkName + ":\n\n" + ArscReader.summarize(rs, 400)
                    if (resSummary.isNotBlank()) {
                        zo.putNextEntry(ZipEntry("decoded/resources.txt"))
                        zo.write(resSummary.toByteArray(Charsets.UTF_8))
                        zo.closeEntry()
                    }
                } catch (ex: Throwable) {
                    // resumo é só um extra; nunca interrompe a extração
                }
            }

            val info = buildInfo(apkName, apkSize, entries, decoded, decodeError, skipped, resSummary.isNotBlank())
            zo.putNextEntry(ZipEntry("ANDROIDSDK-INFO.txt"))
            zo.write(info.toByteArray(Charsets.UTF_8))
            zo.closeEntry()
            return info
        }
    }

    private fun isSignature(n: String): Boolean =
        n == "META-INF/MANIFEST.MF" || (n.startsWith("META-INF/") && (n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC")))

    /**
     * Reconstrói um APK a partir de um ZIP extraído (o do "APK → ZIP", com arquivos trocados) e assina com a chave do app.
     * Reempacota os arquivos como estão. Não recompila DEX nem resources.arsc (isso é o que o apktool faz).
     */
    fun rebuild(a: Context, zipFile: File, out: File): String {
        val tmp = File(a.cacheDir, "rebuild/unsigned.apk")
        tmp.parentFile?.mkdirs()
        var minSdk = 24
        var count = 0
        ZipFile(zipFile).use { z ->
            val me = z.getEntry("AndroidManifest.xml") ?: throw Exception(t("O projeto não tem AndroidManifest.xml.", "The project has no AndroidManifest.xml."))
            try {
                val x = AxmlReader.decode(z.getInputStream(me).use { it.readBytes() })
                minSdk = find(x, """android:minSdkVersion="(\d+)"""")?.toInt() ?: 24
            } catch (e: Throwable) {
            }
            AlignedZip(tmp.outputStream().buffered()).use { w ->
                for (e in z.entries()) {
                    val n = e.name
                    if (e.isDirectory || n.startsWith("decoded/") || n == "ANDROIDSDK-INFO.txt" || isSignature(n) || n.contains("..")) continue
                    val data = z.getInputStream(e).use { it.readBytes() }
                    when {
                        n == "resources.arsc" -> w.addStored(n, data, 4)
                        n.startsWith("lib/") && n.endsWith(".so") -> w.addStored(n, data, 4096)
                        else -> w.addDeflated(n, data)
                    }
                    count++
                }
            }
        }
        LocalBuilder.sign(a, tmp, out, minSdk)
        tmp.delete()
        return t("APK reconstruído com $count arquivos e assinado com a chave do app (${out.length() / 1024} KB).", "APK rebuilt with $count files and signed with the app key (${out.length() / 1024} KB).")
    }

    private fun buildInfo(name: String, size: Long, entries: List<Pair<String, Long>>, xml: String, err: String, skipped: Int, hasRes: Boolean): String {
        val sb = StringBuilder()
        sb.append("APK: ").append(name)
        if (size > 0) sb.append(" (").append(size / 1024).append(" KB)")
        sb.append("\n")

        if (xml.isNotEmpty()) {
            sb.append(t("Pacote: ", "Package: ")).append(find(xml, """\spackage="([^"]+)"""") ?: "?").append("\n")
            sb.append(t("Versão: ", "Version: ")).append(find(xml, """android:versionName="([^"]*)"""") ?: "?")
                .append(" (code ").append(find(xml, """android:versionCode="([^"]*)"""") ?: "?").append(")\n")
            sb.append("minSdk ").append(find(xml, """android:minSdkVersion="([^"]*)"""") ?: "?")
                .append(" · targetSdk ").append(find(xml, """android:targetSdkVersion="([^"]*)"""") ?: "?").append("\n")
            val perms = findAll(xml, """<uses-permission[^>]*?android:name="([^"]+)"""")
            sb.append(t("Permissões (", "Permissions (")).append(perms.size).append("):\n")
            perms.take(40).forEach { sb.append("  • ").append(it).append("\n") }
            if (perms.size > 40) sb.append("  ...\n")
            val acts = findAll(xml, """<activity[^>]*?android:name="([^"]+)"""")
            sb.append("Activities (").append(acts.size).append("):\n")
            acts.take(15).forEach { sb.append("  • ").append(it).append("\n") }
            if (acts.size > 15) sb.append("  ...\n")
        } else if (err.isNotEmpty()) {
            sb.append(t("Não consegui decodificar o manifest: ", "Could not decode the manifest: ")).append(err).append("\n")
        } else {
            sb.append(t("AndroidManifest.xml não encontrado dentro do arquivo.", "AndroidManifest.xml not found in the file.")).append("\n")
        }

        val dex = entries.filter { Regex("""classes\d*\.dex""").matches(it.first) }
        val abis = entries.filter { it.first.startsWith("lib/") }.map { it.first.split("/").getOrNull(1) ?: "" }.filter { it.isNotEmpty() }.toSortedSet()
        val sigs = entries.filter { it.first.startsWith("META-INF/") && (it.first.endsWith(".RSA") || it.first.endsWith(".DSA") || it.first.endsWith(".EC") || it.first.endsWith(".SF")) }
        sb.append("\n").append(t("Arquivos: ", "Files: ")).append(entries.size).append("\n")
        sb.append("DEX: ").append(dex.size).append(" (").append(dex.sumOf { it.second } / 1024).append(" KB)\n")
        if (abis.isNotEmpty()) sb.append(t("Bibliotecas nativas: ", "Native libraries: ")).append(abis.joinToString(", ")).append("\n")
        entries.firstOrNull { it.first == "resources.arsc" }?.let { sb.append("resources.arsc: ").append(it.second / 1024).append(" KB\n") }
        sb.append(t("Assinaturas (META-INF): ", "Signatures (META-INF): ")).append(sigs.size).append("\n")
        if (skipped > 0) sb.append(t("Entradas ignoradas por segurança: ", "Entries skipped for safety: ")).append(skipped).append("\n")
        sb.append("\n").append(t(
            "O ZIP traz o conteúdo original do APK (classes.dex, resources.arsc, res/, assets/, lib/) mais decoded/AndroidManifest.xml legível",
            "The ZIP has the original APK content (classes.dex, resources.arsc, res/, assets/, lib/) plus a readable decoded/AndroidManifest.xml"
        )).append(
            if (hasRes) t(" e decoded/resources.txt com os valores (strings, cores, dimensões, estilos).", " and decoded/resources.txt with the values (strings, colors, dimensions, styles).")
            else "."
        ).append(" ").append(t(
            "O código continua em DEX; a conversão para Java/smali é uma próxima etapa.",
            "Code is still DEX; conversion to Java/smali is a future stage."
        ))
        return sb.toString()
    }
}
