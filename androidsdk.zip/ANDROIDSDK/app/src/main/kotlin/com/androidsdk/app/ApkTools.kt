package com.androidsdk.app

import com.androidsdk.app.engine.AxmlReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ApkTools {

    private fun find(text: String, re: String): String? = Regex(re).find(text)?.groupValues?.get(1)

    private fun findAll(text: String, re: String): List<String> =
        Regex(re).findAll(text).map { it.groupValues[1] }.toList()

    /** Abre o APK, gera um ZIP com todo o conteúdo + manifest legível + resumo, e devolve o resumo. */
    fun extract(input: InputStream, apkName: String, apkSize: Long, out: File): String {
        out.parentFile?.mkdirs()
        var manifest: ByteArray? = null
        val entries = ArrayList<Pair<String, Long>>()
        var skipped = 0

        ZipOutputStream(out.outputStream().buffered()).use { zo ->
            ZipInputStream(input.buffered()).use { zi ->
                val seen = HashSet<String>()
                val buf = ByteArray(64 * 1024)
                var e = zi.nextEntry
                while (e != null) {
                    val name = e.name
                    if (!e.isDirectory) {
                        if (name.contains("..") || name.startsWith("/") || !seen.add(name)) {
                            skipped++
                        } else {
                            zo.putNextEntry(ZipEntry(name))
                            val keep = if (name == "AndroidManifest.xml") ByteArrayOutputStream() else null
                            var total = 0L
                            while (true) {
                                val n = zi.read(buf)
                                if (n < 0) break
                                zo.write(buf, 0, n)
                                keep?.write(buf, 0, n)
                                total += n
                            }
                            zo.closeEntry()
                            if (keep != null) manifest = keep.toByteArray()
                            entries.add(name to total)
                        }
                    }
                    e = zi.nextEntry
                }
            }

            // manifest legível
            var decoded = ""
            var decodeError = ""
            val m = manifest
            if (m != null) {
                try {
                    decoded = AxmlReader.decode(m)
                    zo.putNextEntry(ZipEntry("decoded/AndroidManifest.xml"))
                    zo.write(decoded.toByteArray(Charsets.UTF_8))
                    zo.closeEntry()
                } catch (ex: Throwable) {
                    decodeError = ex.message ?: ex.javaClass.simpleName
                }
            }

            val info = buildInfo(apkName, apkSize, entries, decoded, decodeError, skipped)
            zo.putNextEntry(ZipEntry("ANDROIDSDK-INFO.txt"))
            zo.write(info.toByteArray(Charsets.UTF_8))
            zo.closeEntry()
            return info
        }
    }

    private fun buildInfo(name: String, size: Long, entries: List<Pair<String, Long>>, xml: String, err: String, skipped: Int): String {
        val sb = StringBuilder()
        sb.append("APK: ").append(name)
        if (size > 0) sb.append(" (").append(size / 1024).append(" KB)")
        sb.append("\n")

        if (xml.isNotEmpty()) {
            sb.append(t("Pacote: ", "Package: ")).append(find(xml, """\spackage="([^"]+)"""") ?: "?").append("\n")
            sb.append(t("Versão: ", "Version: ")).append(find(xml, """android:versionName="([^"]*)"""") ?: "?")
                .append(" (code ").append(find(xml, """android:versionCode="([^"]*)"""") ?: "?").append(")\n")
            sb.append("minSdk ").append(find(xml, """android:minSdkVersion="([^"]*)"""") ?: "?")
                .append(" · targetSdk ").append(find(xml, """android:targetSdkVersion="([^"]*)"""") ?: "?").append("\n")
            val perms = findAll(xml, """<uses-permission[^>]*?android:name="([^"]+)"""")
            sb.append(t("Permissões (", "Permissions (")).append(perms.size).append("):\n")
            perms.take(40).forEach { sb.append("  • ").append(it).append("\n") }
            if (perms.size > 40) sb.append("  ...\n")
            val acts = findAll(xml, """<activity[^>]*?android:name="([^"]+)"""")
            sb.append("Activities (").append(acts.size).append("):\n")
            acts.take(15).forEach { sb.append("  • ").append(it).append("\n") }
            if (acts.size > 15) sb.append("  ...\n")
        } else if (err.isNotEmpty()) {
            sb.append(t("Não consegui decodificar o manifest: ", "Could not decode the manifest: ")).append(err).append("\n")
        } else {
            sb.append(t("AndroidManifest.xml não encontrado dentro do arquivo.", "AndroidManifest.xml not found in the file.")).append("\n")
        }

        val dex = entries.filter { Regex("""classes\d*\.dex""").matches(it.first) }
        val abis = entries.filter { it.first.startsWith("lib/") }.map { it.first.split("/").getOrNull(1) ?: "" }.filter { it.isNotEmpty() }.toSortedSet()
        val sigs = entries.filter { it.first.startsWith("META-INF/") && (it.first.endsWith(".RSA") || it.first.endsWith(".DSA") || it.first.endsWith(".EC") || it.first.endsWith(".SF")) }
        sb.append("\n").append(t("Arquivos: ", "Files: ")).append(entries.size).append("\n")
        sb.append("DEX: ").append(dex.size).append(" (").append(dex.sumOf { it.second } / 1024).append(" KB)\n")
        if (abis.isNotEmpty()) sb.append(t("Bibliotecas nativas: ", "Native libraries: ")).append(abis.joinToString(", ")).append("\n")
        entries.firstOrNull { it.first == "resources.arsc" }?.let { sb.append("resources.arsc: ").append(it.second / 1024).append(" KB\n") }
        sb.append(t("Assinaturas (META-INF): ", "Signatures (META-INF): ")).append(sigs.size).append("\n")
        if (skipped > 0) sb.append(t("Entradas ignoradas por segurança: ", "Entries skipped for safety: ")).append(skipped).append("\n")
        sb.append("\n").append(t(
            "O ZIP traz o conteúdo original do APK (classes.dex, resources.arsc, res/, assets/, lib/) mais decoded/AndroidManifest.xml legível. O código continua em DEX; a conversão para Java/smali é uma próxima etapa.",
            "The ZIP has the original APK content (classes.dex, resources.arsc, res/, assets/, lib/) plus a readable decoded/AndroidManifest.xml. Code is still DEX; conversion to Java/smali is a future stage."
        ))
        return sb.toString()
    }
}
