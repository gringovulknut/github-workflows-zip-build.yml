package com.androidsdk.app

import java.io.Closeable
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** ZIP/APK que alinha entradas sem compressão (resources.arsc exige 4 bytes; .so, 4096). */
class AlignedZip(out: OutputStream) : Closeable {

    private class Counting(private val o: OutputStream) : OutputStream() {
        var count = 0L
        override fun write(b: Int) {
            o.write(b)
            count++
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            o.write(b, off, len)
            count += len
        }

        override fun flush() = o.flush()
        override fun close() = o.close()
    }

    private val cnt = Counting(out)
    private val zo = ZipOutputStream(cnt)
    private val seen = HashSet<String>()

    fun addDeflated(name: String, data: ByteArray) {
        if (!seen.add(name)) return
        zo.putNextEntry(ZipEntry(name))
        zo.write(data)
        zo.closeEntry()
    }

    fun addStored(name: String, data: ByteArray, align: Int = 4) {
        if (!seen.add(name)) return
        val e = ZipEntry(name)
        e.method = ZipEntry.STORED
        e.size = data.size.toLong()
        e.compressedSize = data.size.toLong()
        val crc = CRC32()
        crc.update(data)
        e.crc = crc.value
        val base = cnt.count + 30 + name.toByteArray(Charsets.UTF_8).size
        val pad = ((align - ((base + 4) % align)) % align).toInt()
        val extra = ByteArray(4 + pad)
        extra[0] = 0x35
        extra[1] = 0xD9.toByte()
        extra[2] = (pad and 0xFF).toByte()
        extra[3] = ((pad shr 8) and 0xFF).toByte()
        e.extra = extra
        zo.putNextEntry(e)
        zo.write(data)
        zo.closeEntry()
    }

    override fun close() {
        zo.close()
    }
}
