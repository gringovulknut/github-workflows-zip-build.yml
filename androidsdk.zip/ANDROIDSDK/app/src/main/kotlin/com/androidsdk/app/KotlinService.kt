package com.androidsdk.app

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.Process
import java.io.File

/** Roda o compilador Kotlin no processo ":kotlinc", isolado do app. */
class KotlinService : Service() {

    private val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            val data: Bundle = msg.data
            val reply = msg.replyTo
            // pilha grande: o compilador do Kotlin usa muita recursão
            val worker = Thread(null, {
                val err = try {
                    KotlinEngine.compileInProcess(
                        this@KotlinService,
                        File(data.getString("androidJar") ?: ""),
                        (data.getStringArrayList("sources") ?: ArrayList()).map { File(it) },
                        File(data.getString("out") ?: "")
                    )
                } catch (e: Throwable) {
                    "Kotlin: " + e.javaClass.name + ": " + e.message
                }
                try {
                    val r = Message.obtain()
                    val b = Bundle()
                    b.putString("error", err)
                    r.data = b
                    reply?.send(r)
                } catch (e: Exception) {
                }
                // libera a memória do compilador
                Handler(Looper.getMainLooper()).postDelayed({ Process.killProcess(Process.myPid()) }, 1500)
            }, "kotlinc", 128L * 1024 * 1024)
            worker.start()
        }
    }

    private val messenger = Messenger(handler)

    override fun onBind(intent: Intent?): IBinder = messenger.binder
}
