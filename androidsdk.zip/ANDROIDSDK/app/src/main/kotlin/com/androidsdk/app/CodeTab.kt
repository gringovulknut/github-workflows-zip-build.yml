package com.androidsdk.app

import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import java.io.File
import kotlin.concurrent.thread

/** Editor de código com projetos locais (espelho do GitHub, mas 100% no celular). */
class CodeTab(private val a: MainActivity) {

    private var project: String? = null
    private var file: File? = null
    private var output = ""
    private var edRef: EditText? = null
    private var outView: android.widget.TextView? = null

    fun openProject(name: String) {
        project = name
        file = null
        output = ""
        Cfg.lastProject = name
    }

    fun saveIfOpen() {
        val f = file
        val e = edRef
        if (f != null && e != null && f.exists()) {
            try {
                f.writeText(e.text.toString())
            } catch (ex: Exception) {
            }
        }
    }

    /** Volta um nível (editor -> projeto -> lista). Devolve false se já estava na lista. */
    fun back(): Boolean {
        if (file != null) {
            saveIfOpen()
            file = null
            edRef = null
            output = ""
            a.render()
            return true
        }
        if (project != null) {
            project = null
            a.render()
            return true
        }
        return false
    }

    fun show() {
        val f = file
        val pj = project
        when {
            f != null && pj != null -> editor(f, pj)
            pj != null -> projectView(pj)
            else -> listView()
        }
    }

    // ---------- Lista de projetos ----------

    private fun listView() {
        val ui = a.ui
        val r = a.root
        ui.add(r, ui.title(t("Código", "Code")), 4)
        ui.add(r, ui.sub(t("Seus projetos ficam salvos no celular.", "Your projects are stored on your phone.")), 12)
        ui.add(r, ui.btn("＋ " + t("Novo projeto", "New project"), true) { newProjectDialog() })
        ui.add(r, ui.btn("⬆ " + t("Importar ZIP como projeto", "Import ZIP as project")) { importAsProject() }, 14)

        val names = Projects.list(a)
        if (names.isEmpty()) {
            val c = ui.card()
            c.addView(ui.text(t("Nenhum projeto ainda", "No projects yet"), ui.fs, ui.p.text, true))
            c.addView(ui.sub(t("Toque em Novo projeto para começar: HTML, JavaScript, Lua ou um app Android.", "Tap New project to start: HTML, JavaScript, Lua or an Android app.")))
            ui.add(r, c)
        }
        names.forEach { n ->
            val d = Projects.dir(a, n)
            val c = ui.card()
            c.addView(ui.text("📁 $n", ui.fs + 1, ui.p.text, true))
            c.addView(ui.sub("${Projects.files(d).size} " + t("arquivos", "files") + if (Projects.isAndroid(d)) " · Android" else ""))
            c.setOnClickListener {
                openProject(n)
                a.render()
            }
            ui.add(r, c)
        }
    }

    fun newProjectDialog() {
        a.askText(t("Nome do projeto", "Project name"), "meu-projeto") { raw ->
            if (raw.isBlank()) return@askText
            val kinds = ArrayList<Pair<String, String>>()
            Langs.all.filter { Cfg.langOn(it.id) }.forEach { pl ->
                val tag = if (pl.mode == "remote") " (GitHub)" else ""
                kinds.add(pl.id to (pl.label + tag))
            }
            kinds.add("android-java" to t("App Android em Java (compila no celular)", "Android app in Java (builds on-device)"))
            kinds.add("android" to t("App Android em Kotlin (compila via GitHub)", "Android app in Kotlin (builds via GitHub)"))
            kinds.add("empty" to t("Projeto vazio", "Empty project"))
            a.choose(t("Modelo", "Template"), kinds.map { it.second }) { i ->
                try {
                    val d = Projects.create(a, raw, kinds[i].first)
                    openProject(d.name)
                    a.render()
                } catch (e: Exception) {
                    a.toast(e.message ?: "Erro")
                }
            }
        }
    }

    fun importAsProject() {
        a.pickFile { uri ->
            a.askText(t("Nome do projeto", "Project name"), "meu-projeto", Projects.safe(uri.lastPathSegment?.substringAfterLast('/')?.removeSuffix(".zip") ?: "importado")) { raw ->
                val name = Projects.safe(raw)
                if (name.isEmpty() || Projects.dir(a, name).exists()) {
                    a.toast(t("Nome inválido ou já existe.", "Invalid name or already exists."))
                    return@askText
                }
                thread {
                    try {
                        val ins = a.contentResolver.openInputStream(uri) ?: throw Exception("Arquivo ilegível")
                        ins.use { Zips.unzip(it, Projects.dir(a, name)) }
                        a.runOnUiThread {
                            openProject(name)
                            a.go(1)
                        }
                    } catch (e: Exception) {
                        Projects.dir(a, name).deleteRecursively()
                        a.runOnUiThread { a.toast(t("Erro ao importar: ", "Import error: ") + e.message) }
                    }
                }
            }
        }
    }

    // ---------- Dentro de um projeto ----------

    private fun projectView(pj: String) {
        val ui = a.ui
        val r = a.root
        val d = Projects.dir(a, pj)
        if (!d.exists()) {
            project = null
            a.render()
            return
        }
        ui.add(r, ui.btn("← " + t("Projetos", "Projects")) { back() }, 12)
        ui.add(r, ui.title("📁 $pj"), 2)
        val files = Projects.files(d)
        ui.add(r, ui.sub("${files.size} " + t("arquivos", "files")), 12)

        val row1 = ui.row()
        ui.addW(row1, ui.btn("＋ " + t("Arquivo", "File")) { newFile(d) }, 1f, 6)
        ui.addW(row1, ui.btn("⬆ " + t("Importar", "Import")) { importInto(d) }, 1f, 6)
        ui.addW(row1, ui.btn("⬇ ZIP") { exportZip(pj, d) }, 1f, 0)
        ui.add(r, row1, 8)

        val row2 = ui.row()
        ui.addW(row2, ui.btn("📸 Snapshot") { snapshot(pj) }, 1f, 6)
        ui.addW(row2, ui.btn("🕘 " + t("Histórico", "History")) { history(pj) }, 1f, 6)
        ui.addW(row2, ui.btn("🗑") { deleteProject(pj) }, 0.5f, 0)
        ui.add(r, row2, 12)

        if (Projects.isAndroid(d)) {
            ui.add(r, ui.btn("🔨 " + t("Compilar este app (GitHub)", "Build this app (GitHub)"), true) {
                a.build.useProject(pj)
                a.go(2)
            }, 12)
        }

        files.forEach { f ->
            val rel = f.relativeTo(d).path
            val row = ui.card()
            row.addView(ui.text("📄 $rel", ui.fs, ui.p.text, false))
            row.addView(ui.sub("${f.length()} bytes"))
            row.setOnClickListener { openFile(f) }
            row.setOnLongClickListener {
                a.choose(rel, listOf(t("Renomear", "Rename"), t("Excluir", "Delete"))) { i ->
                    if (i == 0) renameFile(d, f) else a.confirm(t("Excluir $rel?", "Delete $rel?")) {
                        f.delete()
                        a.render()
                    }
                }
                true
            }
            ui.add(r, row, 6)
        }
    }

    private fun inside(d: File, rel: String): File? {
        val f = File(d, rel)
        return if (rel.isNotBlank() && f.canonicalPath.startsWith(d.canonicalPath + File.separator)) f else null
    }

    private fun newFile(d: File) {
        a.askText(t("Novo arquivo (ex.: src/util.js)", "New file (e.g. src/util.js)"), "main.js") { rel ->
            val f = inside(d, rel)
            if (f == null || f.exists()) {
                a.toast(t("Nome inválido ou já existe.", "Invalid name or already exists."))
                return@askText
            }
            f.parentFile?.mkdirs()
            f.writeText("")
            openFile(f)
        }
    }

    private fun renameFile(d: File, f: File) {
        a.askText(t("Novo nome", "New name"), "", f.relativeTo(d).path) { rel ->
            val n = inside(d, rel)
            if (n == null || n.exists()) {
                a.toast(t("Nome inválido ou já existe.", "Invalid name or already exists."))
                return@askText
            }
            n.parentFile?.mkdirs()
            f.renameTo(n)
            a.render()
        }
    }

    private fun importInto(d: File) {
        a.pickFile { uri ->
            thread {
                try {
                    val name = a.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                        if (c.moveToFirst() && i >= 0) c.getString(i) else null
                    } ?: "arquivo"
                    val ins = a.contentResolver.openInputStream(uri) ?: throw Exception("Arquivo ilegível")
                    if (name.endsWith(".zip", true)) {
                        ins.use { Zips.unzip(it, d) }
                    } else {
                        File(d, Projects.safe(name)).outputStream().use { o -> ins.use { it.copyTo(o) } }
                    }
                    a.runOnUiThread { a.render() }
                } catch (e: Exception) {
                    a.runOnUiThread { a.toast(t("Erro ao importar: ", "Import error: ") + e.message) }
                }
            }
        }
    }

    private fun exportZip(pj: String, d: File) {
        a.createFile("$pj.zip") { uri ->
            thread {
                try {
                    val out = a.contentResolver.openOutputStream(uri) ?: throw Exception("Destino inválido")
                    Zips.zipTo(d, out)
                    a.runOnUiThread { a.toast(t("ZIP salvo!", "ZIP saved!")) }
                } catch (e: Exception) {
                    a.runOnUiThread { a.toast(t("Erro ao exportar: ", "Export error: ") + e.message) }
                }
            }
        }
    }

    private fun snapshot(pj: String) {
        a.askText(t("Mensagem do snapshot", "Snapshot message"), t("o que mudou?", "what changed?")) { msg ->
            try {
                Projects.snapshot(a, pj, msg)
                a.toast(t("Snapshot salvo.", "Snapshot saved."))
            } catch (e: Exception) {
                a.toast(e.message ?: "Erro")
            }
        }
    }

    private fun history(pj: String) {
        val snaps = Projects.snapshots(a, pj)
        if (snaps.isEmpty()) {
            a.toast(t("Nenhum snapshot ainda. Toque em Snapshot para criar.", "No snapshots yet. Tap Snapshot to create one."))
            return
        }
        a.choose(t("Restaurar versão", "Restore version"), snaps.map { Projects.snapLabel(it) }) { i ->
            a.confirm(t("Restaurar esta versão? A atual será salva antes como snapshot.", "Restore this version? The current one is saved as a snapshot first.")) {
                try {
                    Projects.snapshot(a, pj, "antes-de-restaurar")
                    Projects.restore(a, pj, snaps[i])
                    a.render()
                } catch (e: Exception) {
                    a.toast(e.message ?: "Erro")
                }
            }
        }
    }

    private fun deleteProject(pj: String) {
        a.confirm(t("Excluir o projeto $pj e seus snapshots?", "Delete project $pj and its snapshots?")) {
            Projects.dir(a, pj).deleteRecursively()
            Projects.snapDir(a, pj).deleteRecursively()
            project = null
            a.render()
        }
    }

    // ---------- Editor ----------

    private fun openFile(f: File) {
        val bytes = try { f.readBytes() } catch (e: Exception) { ByteArray(0) }
        if (bytes.size > 1_000_000 || bytes.any { it.toInt() == 0 }) {
            a.toast(t("Arquivo binário ou grande demais para editar.", "Binary or too large to edit."))
            return
        }
        file = f
        output = ""
        a.render()
    }

    private fun editor(f: File, pj: String) {
        val ui = a.ui
        val r = a.root
        val d = Projects.dir(a, pj)

        val top = ui.row()
        ui.addW(top, ui.btn("←") { back() }, 0f, 8)
        ui.addW(top, ui.text(f.relativeTo(d).path, ui.fs, ui.p.text, true), 1f, 0)
        ui.add(r, top, 10)

        // atalhos de símbolos
        val sc = HorizontalScrollView(a)
        sc.isHorizontalScrollBarEnabled = false
        val chips = ui.row()
        listOf("⇥" to "  ", "{" to "{", "}" to "}", "(" to "(", ")" to ")", "[" to "[", "]" to "]", ";" to ";", "\"" to "\"", "'" to "'", "=" to "=", "<" to "<", ">" to ">", "/" to "/", "#" to "#").forEach { (label, ins) ->
            val b = ui.btn(label) { edRef?.let { e -> insert(e, ins) } }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = ui.dp(6)
            chips.addView(b, lp)
        }
        sc.addView(chips)
        ui.add(r, sc, 8)

        val ed = ui.edit("", f.readText(), true, 14)
        edRef = ed
        ui.add(r, ed, 10)

        val actions = ui.row()
        ui.addW(actions, ui.btn("💾 " + t("Salvar", "Save")) {
            saveIfOpen()
            a.toast(t("Salvo.", "Saved."))
        }, 1f, 8)
        ui.addW(actions, ui.btn("▶ " + t("Executar", "Run"), true) { run(f, pj) }, 1f, 0)
        ui.add(r, actions, 10)

        val o = ui.mono(output)
        outView = o
        val card = ui.card()
        card.addView(ui.sub(t("Saída", "Output")))
        card.addView(o)
        card.visibility = if (output.isBlank()) View.GONE else View.VISIBLE
        outCard = card
        ui.add(r, card, 8)
    }

    private var outCard: View? = null

    private fun insert(e: EditText, s: String) {
        val st = maxOf(e.selectionStart, 0)
        val en = maxOf(e.selectionEnd, 0)
        e.text.replace(minOf(st, en), maxOf(st, en), s)
    }

    private fun show(text: String) {
        output = if (text.isBlank()) t("(sem saída)", "(no output)") else text
        outView?.text = output
        outCard?.visibility = View.VISIBLE
    }

    private fun run(f: File, pj: String) {
        saveIfOpen()
        val src = f.readText()
        val pl = Langs.byExt(f.extension)
        if (pl == null) {
            show(t("Esse tipo de arquivo não é executável.", "This file type is not runnable."))
            return
        }
        if (!Cfg.langOn(pl.id)) {
            show(t("${pl.label} está desativada em Configurações > Linguagens.", "${pl.label} is disabled in Settings > Languages."))
            return
        }
        when (pl.mode) {
            "html" -> Runner.preview(a, f)
            "js" -> {
                show(t("Executando...", "Running..."))
                Runner.js(a, src) { show(it) }
            }
            "lua" -> {
                show(t("Executando...", "Running..."))
                Runner.lua(a, src) { show(it) }
            }
            else -> {
                if (!GitHubSvc.connected()) {
                    show(t(
                        "${pl.label} roda no GitHub (opcional). Conecte sua conta em Configurações para usar.",
                        "${pl.label} runs on GitHub (optional). Connect your account in Settings to use it."
                    ))
                    return
                }
                show(t("Enviando para o GitHub...", "Sending to GitHub..."))
                thread {
                    val res = try {
                        GitHubSvc.runScript(a, pl, src) { m -> a.runOnUiThread { show(m) } }
                    } catch (e: Exception) {
                        t("Erro: ", "Error: ") + e.message
                    }
                    a.runOnUiThread { show(res) }
                }
            }
        }
    }
}
