package com.androidsdk.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.View
import android.widget.ProgressBar
import java.io.File
import java.io.InputStream
import kotlin.concurrent.thread

/** Aba "APK → ZIP": abre um APK e entrega o conteúdo em ZIP, com o manifest em XML legível. */
class ApkTab(private val a: MainActivity) {

    private class Src(val name: String, val size: Long, val open: () -> InputStream)

    private var src: Src? = null
    private var busy = false
    private var summary = ""
    private var result: File? = null
    private var rebuilt: File? = null

    fun show() {
        val ui = a.ui
        val r = a.root
        ui.add(r, ui.title("APK → ZIP"), 4)
        ui.add(r, ui.sub(t("Abre um APK e gera um ZIP com o conteúdo dele e o AndroidManifest em XML legível. Use com APKs seus ou que você tenha permissão para analisar.", "Opens an APK and builds a ZIP with its content and a readable AndroidManifest. Use it with your own APKs or ones you are allowed to analyze.")), 12)

        ui.add(r, ui.btn("📦 " + t("Escolher um APK", "Choose an APK")) { pick() })
        ui.add(r, ui.btn("🔎 " + t("Procurar APKs no celular", "Search APKs on the phone")) { scan() }, 12)

        val s = src
        val c = ui.card()
        c.addView(ui.text(t("APK escolhido", "Chosen APK"), ui.fs, ui.p.text, true))
        c.addView(ui.sub(if (s == null) t("Nada escolhido.", "Nothing chosen.") else "✔ " + s.name + if (s.size > 0) " (" + s.size / 1024 + " KB)" else ""))
        ui.add(r, c, 8)

        ui.add(r, ui.btn(if (busy) t("Extraindo...", "Extracting...") else "⚙ " + t("Gerar ZIP", "Build ZIP"), true) { extract() }, 12)

        val pb = ProgressBar(a)
        pb.isIndeterminate = true
        pb.visibility = if (busy) View.VISIBLE else View.GONE
        ui.add(r, pb, 8)

        if (summary.isNotEmpty()) {
            val sc = ui.card()
            sc.addView(ui.mono(summary))
            ui.add(r, sc, 8)
        }

        ui.add(r, ui.btn("🔨 " + t("Reconstruir APK de um projeto (reassinar)", "Rebuild APK from a project (re-sign)")) { rebuild() }, 8)
        ui.add(r, ui.sub(t(
            "Troque arquivos (assets, imagens, libs) no projeto aberto da aba Código e reconstrua. Não recompila o código (DEX) nem o resources.arsc: o apktool completo precisa do aapt2, que ainda não está embutido.",
            "Swap files (assets, images, libs) in the project opened in the Code tab and rebuild. It does not recompile code (DEX) or resources.arsc: full apktool needs aapt2, which is not bundled yet."
        )), 12)
        val rb = rebuilt
        if (rb != null) {
            ui.add(r, ui.btn("📲 " + t("Instalar o APK reconstruído", "Install the rebuilt APK"), true) { a.installApk(rb) }, 8)
        }

        val res = result
        if (res != null) {
            val base = res.nameWithoutExtension
            ui.add(r, ui.btn("💾 " + t("Salvar o ZIP", "Save the ZIP"), true) { save(res, base) }, 8)
            ui.add(r, ui.btn("📂 " + t("Abrir como projeto na aba Código", "Open as a project in the Code tab")) { openInCode(res, base) }, 8)
        }
    }

    private fun pick() {
        a.pickFile { uri ->
            var name = "app.apk"
            var size = 0L
            a.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
            src = Src(name, size) { a.contentResolver.openInputStream(uri) ?: throw Exception("Arquivo ilegível") }
            summary = ""
            result = null
            a.render()
        }
    }

    private fun hasStorage(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else a.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun scan() {
        if (!hasStorage()) {
            a.toast(t("Permita o acesso aos arquivos e volte aqui.", "Allow file access, then come back here."))
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    a.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${a.packageName}")))
                } catch (e: Exception) {
                    a.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            } else {
                a.requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 7)
            }
            return
        }
        a.toast(t("Procurando...", "Searching..."))
        thread {
            val found = ArrayList<File>()
            fun walk(d: File, depth: Int) {
                if (depth > 6 || found.size >= 200) return
                val list = d.listFiles() ?: return
                for (f in list) {
                    if (found.size >= 200) return
                    if (f.isDirectory) {
                        if (f.name.startsWith(".") || (depth == 0 && f.name == "Android")) continue
                        walk(f, depth + 1)
                    } else if (f.name.endsWith(".apk", true)) {
                        found.add(f)
                    }
                }
            }
            walk(Environment.getExternalStorageDirectory(), 0)
            found.sortByDescending { it.lastModified() }
            a.runOnUiThread {
                if (found.isEmpty()) {
                    a.toast(t("Nenhum APK encontrado.", "No APK found."))
                } else {
                    val shown = found.take(40)
                    a.choose(t("APKs encontrados", "APKs found"), shown.map { it.name + " (" + it.length() / 1024 + " KB)" }) { i ->
                        val f = shown[i]
                        src = Src(f.name, f.length()) { f.inputStream() }
                        summary = ""
                        result = null
                        a.render()
                    }
                }
            }
        }
    }

    private fun rebuild() {
        val names = Projects.list(a).filter { n ->
            val d = Projects.dir(a, n)
            File(d, "AndroidManifest.xml").exists() && (d.listFiles()?.any { it.name.startsWith("classes") && it.name.endsWith(".dex") } == true)
        }
        if (names.isEmpty()) {
            a.toast(t("Nenhum projeto vindo de um APK. Use 'Abrir como projeto na aba Código' primeiro.", "No project from an APK. Use 'Open as a project in the Code tab' first."))
            return
        }
        a.choose(t("Projeto", "Project"), names) { i ->
            val name = names[i]
            if (busy) return@choose
            busy = true
            a.render()
            thread {
                try {
                    val zip = File(a.cacheDir, "rebuild/in.zip")
                    zip.parentFile?.mkdirs()
                    zip.outputStream().use { Zips.zipTo(Projects.dir(a, name), it) }
                    val out = File(File(a.getExternalFilesDir(null), "apks").apply { mkdirs() }, "$name-rebuilt.apk")
                    summary = ApkTools.rebuild(a, zip, out)
                    rebuilt = out
                    zip.delete()
                } catch (e: Throwable) {
                    summary = t("Erro: ", "Error: ") + (e.message ?: e.javaClass.simpleName)
                }
                busy = false
                a.runOnUiThread { if (a.cur == 3) a.render() }
            }
        }
    }

    private fun extract() {
        val s = src
        if (s == null) {
            a.toast(t("Escolha um APK primeiro.", "Choose an APK first."))
            return
        }
        if (busy) return
        busy = true
        summary = ""
        result = null
        a.render()
        thread {
            try {
                val base = Projects.safe(s.name.removeSuffix(".apk")).ifEmpty { "app" }
                val out = File(a.cacheDir, "apkout/$base.zip")
                summary = ApkTools.extract(s.open(), s.name, s.size, out)
                result = out
            } catch (e: Throwable) {
                summary = t("Erro: ", "Error: ") + (e.message ?: e.javaClass.simpleName)
            }
            busy = false
            a.runOnUiThread { if (a.cur == 3) a.render() }
        }
    }

    private fun save(zip: File, base: String) {
        a.createFile("$base.zip") { uri ->
            thread {
                try {
                    val out = a.contentResolver.openOutputStream(uri) ?: throw Exception("Destino inválido")
                    out.use { o -> zip.inputStream().use { it.copyTo(o) } }
                    a.runOnUiThread { a.toast(t("ZIP salvo!", "ZIP saved!")) }
                } catch (e: Exception) {
                    a.runOnUiThread { a.toast(t("Erro ao salvar: ", "Save error: ") + e.message) }
                }
            }
        }
    }

    private fun openInCode(zip: File, base: String) {
        thread {
            try {
                var name = "$base-apk"
                var n = 2
                while (Projects.dir(a, name).exists()) {
                    name = "$base-apk$n"
                    n++
                }
                zip.inputStream().use { Zips.unzip(it, Projects.dir(a, name)) }
                a.runOnUiThread {
                    a.code.openProject(name)
                    a.go(1)
                }
            } catch (e: Exception) {
                a.runOnUiThread { a.toast(t("Erro: ", "Error: ") + e.message) }
            }
        }
    }
}
