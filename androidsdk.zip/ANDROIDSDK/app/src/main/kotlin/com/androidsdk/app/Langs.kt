package com.androidsdk.app

/** mode: "html" (prévia no celular), "js" e "lua" (rodam no celular), "remote" (rodam no GitHub, opcional). */
class PL(val id: String, val label: String, val ext: String, val mode: String, val sample: String)

object Langs {
    val all = listOf(
        PL(
            "html", "HTML / CSS / JS", "html", "html",
            """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Meu app</title>
<style>
  body { font-family: sans-serif; padding: 24px; background: #111; color: #eee; }
  button { padding: 12px 18px; border-radius: 10px; border: 0; }
</style>
</head>
<body>
  <h1>Ola, mundo!</h1>
  <p id="msg">Toque no botao.</p>
  <button onclick="document.getElementById('msg').textContent = 'Funcionou!'">Clique aqui</button>
</body>
</html>"""
        ),
        PL(
            "js", "JavaScript", "js", "js",
            """var soma = 0;
for (var i = 1; i <= 10; i++) soma += i;
console.log('Ola do JavaScript! Soma 1..10 = ' + soma);"""
        ),
        PL(
            "lua", "Lua", "lua", "lua",
            """local soma = 0
for i = 1, 10 do soma = soma + i end
print('Ola do Lua! Soma 1..10 = ' .. soma)"""
        ),
        PL("python", "Python", "py", "remote", """import sys
print('Ola do Python', sys.version.split()[0])"""),
        PL("ruby", "Ruby", "rb", "remote", """puts "Ola do Ruby #{RUBY_VERSION}""""),
        PL("php", "PHP", "php", "remote", """<?php
echo 'Ola do PHP ' . PHP_VERSION . "\n";"""),
        PL("bash", "Bash", "sh", "remote", """echo "Ola do Bash"
uname -a"""),
        PL("go", "Go", "go", "remote", """package main

import "fmt"

func main() {
	fmt.Println("Ola do Go")
}"""),
        PL("java", "Java", "java", "remote", """public class Main {
    public static void main(String[] args) {
        System.out.println("Ola do Java");
    }
}"""),
        PL("c", "C", "c", "remote", """#include <stdio.h>

int main(void) {
    printf("Ola do C\n");
    return 0;
}"""),
        PL("cpp", "C++", "cpp", "remote", """#include <iostream>

int main() {
    std::cout << "Ola do C++" << std::endl;
    return 0;
}"""),
        PL("rust", "Rust", "rs", "remote", """fn main() {
    println!("Ola do Rust");
}""")
    )

    fun byId(id: String): PL? = all.firstOrNull { it.id == id }

    fun byExt(ext: String): PL? {
        val e = ext.lowercase()
        if (e == "htm") return byId("html")
        return all.firstOrNull { it.ext == e }
    }
}
