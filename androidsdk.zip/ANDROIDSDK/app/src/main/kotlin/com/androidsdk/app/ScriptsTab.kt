package com.androidsdk.app

import android.annotation.SuppressLint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONObject
import org.json.JSONTokener
import org.luaj.vm2.Globals
import org.luaj.vm2.LoadState
import org.luaj.vm2.compiler.LuaC
import org.luaj.vm2.lib.BaseLib
import org.luaj.vm2.lib.Bit32Lib
import org.luaj.vm2.lib.PackageLib
import org.luaj.vm2.lib.StringLib
import org.luaj.vm2.lib.TableLib
import org.luaj.vm2.lib.jse.JseMathLib
import java.io.ByteArrayOutputStream
import java.io.PrintStream
import kotlin.concurrent.thread

class ScriptsTab(private val a: MainActivity) {

    private class Lang(val label: String, val id: String, val ext: String)

    private val langs = listOf(
        Lang("JavaScript (no celular)", "js-local", "js"),
        Lang("Lua (no celular)", "lua-local", "lua"),
        Lang("Python (GitHub)", "python", "py"),
        Lang("Node.js (GitHub)", "node", "js"),
        Lang("Ruby (GitHub)", "ruby", "rb"),
        Lang("PHP (GitHub)", "php", "php"),
        Lang("Bash (GitHub)", "bash", "sh"),
        Lang("Go (GitHub)", "go", "go"),
        Lang("Java (GitHub)", "java", "java"),
        Lang("C (GitHub)", "c", "c"),
        Lang("C++ (GitHub)", "cpp", "cpp"),
        Lang("Rust (GitHub)", "rust", "rs")
    )

    private val samples = mapOf(
        "js-local" to "var soma = 0;\nfor (var i = 1; i <= 10; i++) soma += i;\nconsole.log('Ola do JavaScript! Soma 1..10 = ' + soma);",
        "lua-local" to "local soma = 0\nfor i = 1, 10 do soma = soma + i end\nprint('Ola do Lua! Soma 1..10 = ' .. soma)",
        "python" to "import sys\nprint('Ola do Python', sys.version.split()[0])",
        "node" to "console.log('Ola do Node.js', process.version);",
        "ruby" to "puts \"Ola do Ruby #{RUBY_VERSION}\"",
        "php" to "<?php\necho 'Ola do PHP ' . PHP_VERSION . \"\\n\";",
        "bash" to "echo \"Ola do Bash\"\nuname -a",
        "go" to "package main\n\nimport \"fmt\"\n\nfunc main() {\n\tfmt.Println(\"Ola do Go\")\n}",
        "java" to "public class Main {\n    public static void main(String[] args) {\n        System.out.println(\"Ola do Java\");\n    }\n}",
        "c" to "#include <stdio.h>\n\nint main(void) {\n    printf(\"Ola do C\\n\");\n    return 0;\n}",
        "cpp" to "#include <iostream>\n\nint main() {\n    std::cout << \"Ola do C++\" << std::endl;\n    return 0;\n}",
        "rust" to "fn main() {\n    println!(\"Ola do Rust\");\n}"
    )

    private var current: Lang = langs[0]
    private var output: TextView? = null
    private var runBtn: Button? = null
    private var progress: ProgressBar? = null

    fun show() {
        val root = a.root
        root.removeAllViews()
        root.addView(a.tv("Scripts", 24f, true))
        root.addView(a.tv("As linguagens marcadas (no celular) rodam na hora. As marcadas (GitHub) rodam no GitHub Actions e o resultado volta para a tela.", 13f))

        val spinner = Spinner(a)
        spinner.adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, langs.map { it.label })
        root.addView(spinner)

        val ed = EditText(a)
        ed.minLines = 10
        ed.gravity = Gravity.TOP or Gravity.START
        ed.typeface = Typeface.MONOSPACE
        ed.textSize = 13f
        ed.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        root.addView(ed)

        spinner.setSelection(langs.indexOf(current))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val old = current
                current = langs[pos]
                val txt = ed.text.toString()
                if (txt.isBlank() || txt == samples[old.id]) ed.setText(samples[current.id] ?: "")
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        root.addView(a.tv("Repositório usado para rodar no GitHub:", 13f))
        val repoField = a.edit("usuario/repositorio", a.prefs.getString("repo", ""))
        root.addView(repoField)

        runBtn = a.btn("▶ Executar") { run(ed.text.toString(), repoField.text.toString().trim()) }
        root.addView(runBtn)
        progress = ProgressBar(a)
        progress?.isIndeterminate = true
        progress?.visibility = View.GONE
        root.addView(progress)

        val o = a.tv("", 13f)
        o.typeface = Typeface.MONOSPACE
        o.setTextIsSelectable(true)
        output = o
        root.addView(o)
    }

    private fun out(t: String) {
        a.runOnUiThread { output?.text = t }
    }

    private fun result(t: String) = out(if (t.isBlank()) "(sem saída)" else t)

    private fun setBusy(b: Boolean) {
        a.runOnUiThread {
            progress?.visibility = if (b) View.VISIBLE else View.GONE
            runBtn?.isEnabled = !b
        }
    }

    private fun run(src: String, repo: String) {
        if (src.isBlank()) {
            a.toast("Escreva um script primeiro.")
            return
        }
        when (current.id) {
            "js-local" -> runJs(src)
            "lua-local" -> runLua(src)
            else -> runRemote(src, repo)
        }
    }

    // ---------- JavaScript no celular (WebView) ----------

    private fun decode(r: String?): String {
        if (r == null) return ""
        return try {
            (JSONTokener(r).nextValue() as? String) ?: r
        } catch (e: Exception) {
            r
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun runJs(src: String) {
        out("Executando...")
        val wv = WebView(a)
        wv.settings.javaScriptEnabled = true
        var done = false
        val wrapped = "(function(){var out=[];" +
            "console.log=function(){out.push(Array.prototype.slice.call(arguments).join(' '))};" +
            "console.error=console.log;console.warn=console.log;" +
            "try{var r=(0,eval)(" + JSONObject.quote(src) + ");if(r!==undefined)out.push('=> '+r)}" +
            "catch(e){out.push('Erro: '+e)}" +
            "return out.join('\\n')})()"
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (done) return
                view?.evaluateJavascript(wrapped) { r ->
                    if (!done) {
                        done = true
                        result(decode(r))
                        wv.destroy()
                    }
                }
            }
        }
        Handler(Looper.getMainLooper()).postDelayed({
            if (!done) {
                done = true
                out("Tempo esgotado (10 s).")
                wv.destroy()
            }
        }, 10000)
        wv.loadDataWithBaseURL(null, "<html><body></body></html>", "text/html", "utf-8", null)
    }

    // ---------- Lua no celular (LuaJ, sem acesso a arquivos) ----------

    private fun runLua(src: String) {
        out("Executando...")
        setBusy(true)
        thread(isDaemon = true) {
            val baos = ByteArrayOutputStream()
            val msg = try {
                val g = Globals()
                g.load(BaseLib())
                g.load(PackageLib())
                g.load(Bit32Lib())
                g.load(TableLib())
                g.load(StringLib())
                g.load(JseMathLib())
                LoadState.install(g)
                LuaC.install(g)
                g.STDOUT = PrintStream(baos, true, "UTF-8")
                g.load(src, "script").call()
                baos.toString("UTF-8")
            } catch (e: Throwable) {
                baos.toString("UTF-8") + "\nErro: " + e.message
            }
            result(msg)
            setBusy(false)
        }
    }

    // ---------- Outras linguagens no GitHub Actions ----------

    private fun latestRunId(api: String, token: String): Long {
        val r = Gh.call("GET", "$api/actions/workflows/run-script.yml/runs?event=workflow_dispatch&per_page=1", token)
        if (r.code != 200) return 0L
        val arr = JSONObject(r.body).optJSONArray("workflow_runs") ?: return 0L
        return if (arr.length() > 0) arr.getJSONObject(0).getLong("id") else 0L
    }

    private fun runRemote(src: String, repo: String) {
        val token = a.prefs.getString("token", null)
        if (token == null) {
            a.toast("Entre na conta GitHub primeiro.")
            return
        }
        if (!Regex("[\\w.-]+/[\\w.-]+").matches(repo)) {
            a.toast("Digite o repositório como usuario/repositorio")
            return
        }
        a.prefs.edit().putString("repo", repo).apply()
        val lang = current
        setBusy(true)
        out("Verificando repositório...")
        thread {
            try {
                val api = "https://api.github.com/repos/$repo"
                val info = Gh.call("GET", api, token)
                if (info.code != 200) throw Exception("Repositório não encontrado ou sem permissão (${info.code})")
                val branch = JSONObject(info.body).getString("default_branch")

                out("Instalando o workflow de scripts...")
                val wf = a.assets.open("run-script.yml").use { it.readBytes() }
                a.putFile(api, token, ".github/workflows/run-script.yml", wf, branch, "ANDROIDSDK: workflow de scripts")

                out("Enviando o script...")
                val path = "scripts/${System.currentTimeMillis()}.${lang.ext}"
                a.putFile(api, token, path, src.toByteArray(), branch, "ANDROIDSDK: script ${lang.id}")

                val prev = latestRunId(api, token)

                out("Iniciando a execução...")
                var started = false
                for (i in 1..8) {
                    val body = JSONObject().put("ref", branch)
                        .put("inputs", JSONObject().put("script", path).put("lang", lang.id)).toString()
                    val r = Gh.call("POST", "$api/actions/workflows/run-script.yml/dispatches", token, body)
                    if (r.code == 204) {
                        started = true
                        break
                    }
                    Thread.sleep(4000)
                }
                if (!started) throw Exception("Não consegui iniciar. Confira se o token tem a permissão workflow.")

                out("Aguardando o GitHub executar (cerca de 1 minuto)...")
                var runId = 0L
                var url = ""
                var conclusion = ""
                val end = System.currentTimeMillis() + 10 * 60 * 1000L
                while (System.currentTimeMillis() < end) {
                    Thread.sleep(4000)
                    val r = Gh.call("GET", "$api/actions/workflows/run-script.yml/runs?event=workflow_dispatch&per_page=5", token)
                    if (r.code != 200) continue
                    val arr = JSONObject(r.body).optJSONArray("workflow_runs") ?: continue
                    var cur: JSONObject? = null
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        if (o.getLong("id") > prev) {
                            cur = o
                            break
                        }
                    }
                    if (cur == null) continue
                    if (cur.getString("status") == "completed") {
                        runId = cur.getLong("id")
                        url = cur.getString("html_url")
                        conclusion = cur.optString("conclusion")
                        break
                    }
                }
                if (runId == 0L) throw Exception("Tempo esgotado esperando o GitHub.")

                var text: String? = null
                for (i in 1..5) {
                    val rel = Gh.call("GET", "$api/releases/tags/run-$runId", token)
                    if (rel.code == 200) {
                        text = JSONObject(rel.body).optString("body", "")
                        break
                    }
                    Thread.sleep(3000)
                }
                if (text == null) throw Exception("A execução terminou ($conclusion), mas não achei o resultado. Veja em $url")
                result(text)
            } catch (e: Exception) {
                out("Erro: ${e.message}")
            }
            setBusy(false)
        }
    }
}
