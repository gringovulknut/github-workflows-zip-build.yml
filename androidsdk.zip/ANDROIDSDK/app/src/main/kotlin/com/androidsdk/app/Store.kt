package com.androidsdk.app

import android.content.Context
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Zips {
    fun zipTo(dir: File, out: OutputStream) {
        ZipOutputStream(BufferedOutputStream(out)).use { zo ->
            dir.walkTopDown().filter { it.isFile }.forEach { f ->
                zo.putNextEntry(ZipEntry(f.relativeTo(dir).path.replace(File.separatorChar, '/')))
                f.inputStream().use { it.copyTo(zo) }
                zo.closeEntry()
            }
        }
    }

    fun zipBytes(dir: File): ByteArray {
        val b = ByteArrayOutputStream()
        zipTo(dir, b)
        return b.toByteArray()
    }

    fun unzip(input: InputStream, dest: File) {
        dest.mkdirs()
        val base = dest.canonicalPath + File.separator
        ZipInputStream(input).use { zi ->
            var e = zi.nextEntry
            var count = 0
            while (e != null) {
                count++
                if (count > 5000) throw Exception(t("ZIP com arquivos demais.", "ZIP has too many files."))
                val f = File(dest, e.name)
                if (!f.canonicalPath.startsWith(base)) throw SecurityException("ZIP inválido")
                if (e.isDirectory) {
                    f.mkdirs()
                } else {
                    f.parentFile?.mkdirs()
                    f.outputStream().use { zi.copyTo(it) }
                }
                e = zi.nextEntry
            }
        }
    }
}

object Projects {
    fun root(c: Context): File = File(c.filesDir, "projects").apply { mkdirs() }

    fun safe(n: String): String = n.trim().replace(Regex("[^A-Za-z0-9._-]"), "_").take(60)

    fun list(c: Context): List<String> =
        root(c).listFiles()?.filter { it.isDirectory }?.map { it.name }?.sorted() ?: emptyList()

    fun dir(c: Context, name: String): File = File(root(c), name)

    fun files(dir: File): List<File> =
        dir.walkTopDown().filter { it.isFile }.sortedBy { it.relativeTo(dir).path }.toList()

    fun isAndroid(dir: File): Boolean =
        files(dir).any { it.name == "settings.gradle" || it.name == "settings.gradle.kts" }

    fun create(c: Context, rawName: String, kind: String): File {
        val name = safe(rawName)
        if (name.isEmpty()) throw Exception(t("Nome inválido.", "Invalid name."))
        val d = dir(c, name)
        if (d.exists()) throw Exception(t("Já existe um projeto com esse nome.", "A project with this name already exists."))
        d.mkdirs()
        when (kind) {
            "empty" -> File(d, "README.md").writeText("# $name\n")
            "android" -> androidTemplate(d, name)
            "android-java" -> androidJavaTemplate(d, name)
            "android-java-xml" -> androidJavaXmlTemplate(d, name)
            else -> {
                val pl = Langs.byId(kind)
                if (pl != null) {
                    val fn = when (pl.id) {
                        "html" -> "index.html"
                        "java" -> "Main.java"
                        else -> "main.${pl.ext}"
                    }
                    File(d, fn).writeText(pl.sample)
                }
            }
        }
        return d
    }

    private fun androidTemplate(d: File, name: String) {
        fun w(path: String, text: String) {
            val f = File(d, path)
            f.parentFile?.mkdirs()
            f.writeText(text)
        }
        w("settings.gradle.kts", """pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "$name"
include(":app")
""")
        w("build.gradle.kts", """plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
""")
        w("gradle.properties", """org.gradle.jvmargs=-Xmx2g
android.useAndroidX=true
android.nonTransitiveRClass=true
""")
        w("app/build.gradle.kts", """plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.meuapp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.meuapp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}
""")
        w("app/src/main/AndroidManifest.xml", """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:label="$name"
        android:theme="@android:style/Theme.Material.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
""")
        w("app/src/main/kotlin/com/example/meuapp/MainActivity.kt", """package com.example.meuapp

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this)
        tv.text = "Ola, mundo! App criado no ANDROIDSDK"
        tv.textSize = 24f
        tv.setPadding(48, 96, 48, 48)
        setContentView(tv)
    }
}
""")
    }

    private fun androidJavaTemplate(d: File, name: String) {
        fun w(path: String, text: String) {
            val f = File(d, path)
            f.parentFile?.mkdirs()
            f.writeText(text)
        }
        w("settings.gradle.kts", """pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "$name"
include(":app")
""")
        w("build.gradle.kts", """plugins {
    id("com.android.application") version "8.5.2" apply false
}
""")
        w("gradle.properties", """org.gradle.jvmargs=-Xmx2g
android.useAndroidX=true
android.nonTransitiveRClass=true
""")
        w("app/build.gradle.kts", """plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.meuapp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.meuapp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}
""")
        w("app/src/main/AndroidManifest.xml", """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:label="$name"
        android:theme="@android:style/Theme.Material.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
""")
        w("app/src/main/java/com/example/meuapp/MainActivity.java", """package com.example.meuapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText("Ola, mundo! App criado no ANDROIDSDK");
        tv.setTextSize(24);
        tv.setPadding(48, 96, 48, 48);
        setContentView(tv);
    }
}
""")
    }

    private fun androidJavaXmlTemplate(d: File, name: String) {
        androidJavaTemplate(d, name)
        fun w(path: String, text: String) {
            val f = File(d, path)
            f.parentFile?.mkdirs()
            f.writeText(text)
        }
        w("app/src/main/AndroidManifest.xml", """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:label="@string/app_name"
        android:theme="@style/AppTheme">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
""")
        w("app/src/main/java/com/example/meuapp/MainActivity.java", """package com.example.meuapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int cliques = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView texto = findViewById(R.id.texto);
        Button botao = findViewById(R.id.botao);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cliques++;
                texto.setText(getString(R.string.cliques, cliques));
            }
        });
    }
}
""")
        w("app/src/main/res/layout/activity_main.xml", """<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center"
    android:orientation="vertical"
    android:padding="24dp">

    <TextView
        android:id="@+id/texto"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/inicio"
        android:textColor="@color/texto"
        android:textSize="24sp" />

    <Button
        android:id="@+id/botao"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="16dp"
        android:text="@string/botao" />
</LinearLayout>
""")
        w("app/src/main/res/values/strings.xml", """<resources>
    <string name="app_name">$name</string>
    <string name="inicio">Ola! Toque no botao.</string>
    <string name="botao">Contar</string>
    <string name="cliques">Cliques: %d</string>
</resources>
""")
        w("app/src/main/res/values/colors.xml", """<resources>
    <color name="fundo">#111113</color>
    <color name="texto">#E7E7EA</color>
</resources>
""")
        w("app/src/main/res/values/styles.xml", """<resources>
    <style name="AppTheme" parent="android:Theme.Material.NoActionBar">
        <item name="android:windowBackground">@color/fundo</item>
    </style>
</resources>
""")
    }

    // ---- Snapshots (como commits locais) ----

    fun snapDir(c: Context, name: String): File = File(File(c.filesDir, "snapshots"), name).apply { mkdirs() }

    fun snapshot(c: Context, name: String, msg: String) {
        val m = safe(msg.ifBlank { "snapshot" })
        val out = File(snapDir(c, name), "${System.currentTimeMillis()}__$m.zip")
        out.outputStream().use { Zips.zipTo(dir(c, name), it) }
    }

    fun snapshots(c: Context, name: String): List<File> =
        snapDir(c, name).listFiles()?.filter { it.name.endsWith(".zip") }?.sortedByDescending { it.name } ?: emptyList()

    fun snapLabel(f: File): String {
        val ts = f.name.substringBefore("__").toLongOrNull() ?: 0L
        val msg = f.name.substringAfter("__").removeSuffix(".zip")
        val date = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(ts))
        return "$date · $msg"
    }

    fun restore(c: Context, name: String, snap: File) {
        val d = dir(c, name)
        d.listFiles()?.forEach { it.deleteRecursively() }
        snap.inputStream().use { Zips.unzip(it, d) }
    }
}
