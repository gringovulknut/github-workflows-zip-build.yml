package com.androidsdk.app

import android.view.Gravity
import android.widget.LinearLayout

class HomeTab(private val a: MainActivity) {

    fun show() {
        val ui = a.ui
        val r = a.root

        val head = ui.row()
        val logo = ui.text("🔧", 30f)
        logo.gravity = Gravity.CENTER
        logo.background = ui.shape(ui.p.accent, 18)
        logo.setPadding(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(8))
        head.addView(logo)
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ui.dp(14), 0, 0, 0)
        col.addView(ui.text("ANDROIDSDK", ui.fs + 10, ui.p.text, true))
        col.addView(ui.sub(t("Crie, rode e empacote apps no próprio celular", "Create, run and package apps on your phone")))
        head.addView(col)
        ui.add(r, head, 16)

        // números rápidos
        val stats = ui.row()
        val nProj = Projects.list(a).size
        val nLang = Langs.all.count { Cfg.langOn(it.id) }
        val gh = if (GitHubSvc.connected()) "@" + Cfg.ghLogin else "offline"
        listOf(
            nProj.toString() to t("projetos", "projects"),
            nLang.toString() to t("linguagens", "languages"),
            gh to "GitHub"
        ).forEachIndexed { i, (big, small) ->
            val c = ui.card()
            c.addView(ui.text(big, ui.fs + 4, ui.p.accent, true))
            c.addView(ui.sub(small))
            ui.addW(stats, c, 1f, if (i < 2) 8 else 0)
        }
        ui.add(r, stats, 16)

        // ações rápidas
        ui.add(r, ui.btn("＋ " + t("Novo projeto", "New project"), true) {
            a.go(1)
            a.code.newProjectDialog()
        })
        val last = Cfg.lastProject
        if (last.isNotBlank() && Projects.dir(a, last).exists()) {
            ui.add(r, ui.btn("▶ " + t("Continuar: ", "Continue: ") + last) {
                a.code.openProject(last)
                a.go(1)
            })
        }
        ui.add(r, ui.btn("⬆ " + t("Importar ZIP como projeto", "Import ZIP as project")) {
            a.go(1)
            a.code.importAsProject()
        })
        ui.add(r, ui.btn("🔨 " + t("Compilar um app Android", "Build an Android app")) { a.go(2) })
        ui.add(r, ui.btn("⚙ " + t("Configurações (temas, fontes, idioma)", "Settings (themes, fonts, language)")) { a.go(4) }, 16)

        val how = ui.card()
        how.addView(ui.text(t("Como funciona", "How it works"), ui.fs + 1, ui.p.text, true))
        how.addView(ui.sub(
            t(
                "• Código: crie projetos, edite, zipe e rode HTML, JavaScript e Lua direto no celular, sem internet.\n" +
                    "• Snapshots funcionam como commits locais: você volta a qualquer versão do projeto.\n" +
                    "• GitHub é opcional e funciona como espelho: compila o APK e roda linguagens extras (Python, Java, C...). Conecte em Configurações.",
                "• Code: create projects, edit, zip and run HTML, JavaScript and Lua right on your phone, offline.\n" +
                    "• Snapshots work like local commits: you can go back to any version of a project.\n" +
                    "• GitHub is optional and works as a mirror: it builds the APK and runs extra languages (Python, Java, C...). Connect it in Settings."
            )
        ))
        ui.add(r, how, 8)
    }
}
