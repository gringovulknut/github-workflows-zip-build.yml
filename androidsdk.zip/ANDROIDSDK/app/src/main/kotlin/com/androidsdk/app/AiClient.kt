package com.androidsdk.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Conversa com o Claude pela API da Anthropic. Você usa a sua própria chave de API (Configurações). */
object AiClient {

    private fun system(): String = t(
        "Você é o assistente de programação dentro do app ANDROIDSDK, um ambiente que roda no celular Android. " +
            "O app tem editor de código, projetos locais, execução de HTML, JavaScript e Lua no próprio celular, " +
            "e compila apps Android em Java (com layouts XML) e Kotlin. Ajude a escrever código, corrigir erros de compilação e " +
            "explicar conceitos. Responda em português do Brasil, de forma direta e curta (a tela é de celular). " +
            "Sempre coloque código em blocos com a linguagem indicada (```java, ```kotlin, ```xml etc.).",
        "You are the coding assistant inside ANDROIDSDK, an environment that runs on an Android phone. " +
            "The app has a code editor, local projects, on-device execution of HTML, JavaScript and Lua, " +
            "and builds Android apps in Java (with XML layouts) and Kotlin. Help write code, fix build errors and " +
            "explain concepts. Answer in English, direct and short (the screen is a phone). " +
            "Always put code in fenced blocks with the language (```java, ```kotlin, ```xml etc.)."
    )

    /** history: pares (role, texto), começando por "user" e alternando. */
    fun ask(history: List<Pair<String, String>>): String {
        val key = Cfg.aiKey
        if (key.isBlank()) {
            throw Exception(t("Coloque sua chave da API em Configurações > Assistente de IA.", "Set your API key in Settings > AI assistant."))
        }
        val msgs = JSONArray()
        history.forEach { (role, text) -> msgs.put(JSONObject().put("role", role).put("content", text)) }
        val body = JSONObject()
            .put("model", Cfg.aiModel)
            .put("max_tokens", 4096)
            .put("system", system())
            .put("messages", msgs)
            .toString()
            .toByteArray(Charsets.UTF_8)

        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 180000
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.doOutput = true
            c.setFixedLengthStreamingMode(body.size)
            c.outputStream.use { it.write(body) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try { JSONObject(text).getJSONObject("error").optString("message") } catch (e: Exception) { "" }
                val hint = when (code) {
                    401 -> t("Chave da API inválida.", "Invalid API key.")
                    404 -> t("Modelo não encontrado. Confira o nome do modelo em Configurações.", "Model not found. Check the model name in Settings.")
                    429 -> t("Limite de uso atingido. Tente de novo em instantes.", "Rate limit reached. Try again shortly.")
                    else -> ""
                }
                throw Exception("API ($code) $hint " + msg.ifBlank { text.take(200) })
            }
            val arr = JSONObject(text).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val b = arr.getJSONObject(i)
                if (b.optString("type") == "text") sb.append(b.optString("text"))
            }
            return sb.toString().ifBlank { t("(resposta vazia)", "(empty reply)") }
        } finally {
            c.disconnect()
        }
    }
}
