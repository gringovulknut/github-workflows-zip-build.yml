package com.androidsdk.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import org.json.JSONObject
import org.json.JSONTokener
import org.luaj.vm2.Globals
import org.luaj.vm2.LoadState
import org.luaj.vm2.compiler.LuaC
import org.luaj.vm2.lib.BaseLib
import org.luaj.vm2.lib.Bit32Lib
import org.luaj.vm2.lib.PackageLib
import org.luaj.vm2.lib.StringLib
import org.luaj.vm2.lib.TableLib
import org.luaj.vm2.lib.jse.JseMathLib
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.PrintStream
import kotlin.concurrent.thread

/** Execução local (sem internet e sem GitHub): JavaScript, Lua e prévia de HTML. */
object Runner {

    private fun decode(r: String?): String {
        if (r == null) return ""
        return try {
            (JSONTokener(r).nextValue() as? String) ?: r
        } catch (e: Exception) {
            r
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun js(a: Activity, src: String, cb: (String) -> Unit) {
        val wv = WebView(a)
        wv.settings.javaScriptEnabled = true
        var done = false
        val wrapped = "(function(){var out=[];" +
            "console.log=function(){out.push(Array.prototype.slice.call(arguments).join(' '))};" +
            "console.error=console.log;console.warn=console.log;" +
            "try{var r=(0,eval)(" + JSONObject.quote(src) + ");if(r!==undefined)out.push('=> '+r)}" +
            "catch(e){out.push('Erro: '+e)}" +
            "return out.join('\\n')})()"
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (done) return
                view?.evaluateJavascript(wrapped) { r ->
                    if (!done) {
                        done = true
                        cb(decode(r))
                        wv.destroy()
                    }
                }
            }
        }
        Handler(Looper.getMainLooper()).postDelayed({
            if (!done) {
                done = true
                cb(t("Tempo esgotado (10 s).", "Timed out (10 s)."))
                wv.destroy()
            }
        }, 10000)
        wv.loadDataWithBaseURL(null, "<html><body></body></html>", "text/html", "utf-8", null)
    }

    fun lua(a: Activity, src: String, cb: (String) -> Unit) {
        thread(isDaemon = true) {
            val baos = ByteArrayOutputStream()
            val msg = try {
                val g = Globals()
                g.load(BaseLib())
                g.load(PackageLib())
                g.load(Bit32Lib())
                g.load(TableLib())
                g.load(StringLib())
                g.load(JseMathLib())
                LoadState.install(g)
                LuaC.install(g)
                g.STDOUT = PrintStream(baos, true, "UTF-8")
                g.load(src, "script").call()
                baos.toString("UTF-8")
            } catch (e: Throwable) {
                baos.toString("UTF-8") + "\nErro: " + e.message
            }
            a.runOnUiThread { cb(msg) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun preview(a: MainActivity, file: File) {
        val ui = a.ui
        val d = Dialog(a, android.R.style.Theme_Material_NoActionBar)
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(ui.p.bg)
        val bar = ui.row()
        bar.setBackgroundColor(ui.p.surface)
        bar.setPadding(ui.dp(12), ui.dp(8), ui.dp(12), ui.dp(8))
        ui.addW(bar, ui.text(file.name, ui.fs, ui.p.text, true), 1f)
        bar.addView(ui.btn("✕") { d.dismiss() })
        col.addView(
            bar,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )
        val wv = WebView(a)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.allowFileAccess = true
        wv.loadUrl("file://" + file.absolutePath)
        col.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        d.setContentView(col)
        d.setOnDismissListener { wv.destroy() }
        d.show()
    }
}
