package com.androidsdk.app

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private data class ZipItem(val name: String, val size: Long, val file: File?, val uri: Uri?)

    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout

    private var selected: ZipItem? = null
    private var apkFile: File? = null
    private var logView: TextView? = null
    private var zipBox: LinearLayout? = null
    private var selView: TextView? = null
    private var progress: ProgressBar? = null
    private var installBtn: Button? = null
    private var compileBtn: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        prefs = EncryptedSharedPreferences.create(
            this,
            "androidsdk_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }
        scroll.addView(root)
        setContentView(scroll)

        if (prefs.getString("token", null) == null) showLogin() else showHome()
    }

    // ---------- Ajudantes de interface ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float = 16f, bold: Boolean = false): TextView {
        val view = TextView(this)
        view.text = t
        view.textSize = size
        view.setTextColor(0xFF24292F.toInt())
        if (bold) view.setTypeface(view.typeface, Typeface.BOLD)
        view.setPadding(0, dp(6), 0, dp(6))
        return view
    }

    private fun btn(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setAllCaps(false)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun edit(hint: String, value: String?): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value ?: "")
        e.setSingleLine(true)
        return e
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun log(m: String) {
        runOnUiThread { logView?.append(m + "\n") }
    }

    // ---------- Tela de login ----------

    private fun showLogin() {
        root.removeAllViews()
        root.addView(tv("ANDROIDSDK", 28f, true))
        root.addView(tv("Transforme um ZIP em APK usando o GitHub.", 15f))
        root.addView(tv("Passo 1: conecte sua conta do GitHub", 18f, true))

        val clientId = edit("Client ID do OAuth App", prefs.getString("client_id", ""))
        val status = tv("", 15f)

        root.addView(tv("Opção A: login pelo navegador (precisa de um OAuth App com Device Flow ativado em github.com/settings/developers).", 13f))
        root.addView(clientId)
        root.addView(btn("Entrar com GitHub") { deviceLogin(clientId.text.toString().trim(), status) })

        root.addView(tv("Opção B: token pessoal com permissões repo e workflow.", 13f))
        val tokenField = edit("Cole o token (ghp_... ou github_pat_...)", "")
        root.addView(tokenField)
        root.addView(btn("Entrar com token") {
            val t = tokenField.text.toString().trim()
            if (t.isEmpty()) {
                status.text = "Cole o token primeiro."
            } else {
                status.text = "Verificando..."
                thread {
                    try {
                        finishLogin(t)
                    } catch (e: Exception) {
                        runOnUiThread { status.text = "Erro: ${e.message}" }
                    }
                }
            }
        })
        root.addView(status)
    }

    private fun deviceLogin(clientId: String, status: TextView) {
        if (clientId.isBlank()) {
            status.text = "Informe o Client ID ou use um token."
            return
        }
        prefs.edit().putString("client_id", clientId).apply()
        status.text = "Contactando o GitHub..."
        thread {
            try {
                val r = Gh.call(
                    "POST", "https://github.com/login/device/code", null,
                    "client_id=$clientId&scope=repo%20workflow",
                    "application/x-www-form-urlencoded", "application/json"
                )
                val j = JSONObject(r.body)
                if (!j.has("device_code")) {
                    throw Exception(j.optString("error_description", "Client ID inválido ou Device Flow desativado"))
                }
                val code = j.getString("user_code")
                val url = j.getString("verification_uri")
                val device = j.getString("device_code")
                var interval = j.optInt("interval", 5)
                runOnUiThread {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("codigo", code))
                    status.text = "Código: $code (copiado). Cole na página do GitHub que abriu e autorize."
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
                val deadline = System.currentTimeMillis() + j.optInt("expires_in", 900) * 1000L
                while (System.currentTimeMillis() < deadline) {
                    Thread.sleep(interval * 1000L)
                    val p = JSONObject(
                        Gh.call(
                            "POST", "https://github.com/login/oauth/access_token", null,
                            "client_id=$clientId&device_code=$device&grant_type=urn:ietf:params:oauth:grant-type:device_code",
                            "application/x-www-form-urlencoded", "application/json"
                        ).body
                    )
                    val tok = p.optString("access_token", "")
                    if (tok.isNotEmpty()) {
                        finishLogin(tok)
                        return@thread
                    }
                    when (p.optString("error")) {
                        "authorization_pending" -> {}
                        "slow_down" -> interval += 5
                        else -> throw Exception(p.optString("error_description", "Login cancelado"))
                    }
                }
                throw Exception("O código expirou. Tente de novo.")
            } catch (e: Exception) {
                runOnUiThread { status.text = "Erro: ${e.message}" }
            }
        }
    }

    private fun finishLogin(token: String) {
        val r = Gh.call("GET", "https://api.github.com/user", token)
        if (r.code != 200) throw Exception("Token inválido (${r.code})")
        val login = JSONObject(r.body).optString("login")
        prefs.edit().putString("token", token).putString("login", login).apply()
        runOnUiThread { showHome() }
    }

    // ---------- Tela principal ----------

    private fun showHome() {
        root.removeAllViews()
        selected = null
        apkFile = null

        root.addView(tv("ANDROIDSDK", 28f, true))
        root.addView(tv("Conectado como @${prefs.getString("login", "?")}", 15f))
        root.addView(btn("Sair da conta") {
            prefs.edit().remove("token").remove("login").apply()
            showLogin()
        })

        root.addView(tv("1. Repositório que vai compilar", 18f, true))
        val repo = edit("usuario/repositorio", prefs.getString("repo", ""))
        root.addView(repo)

        root.addView(tv("2. Escolha o ZIP", 18f, true))
        root.addView(btn("Procurar ZIPs no celular") { scanZips() })
        root.addView(btn("Escolher arquivo manualmente") { pickZip() })
        zipBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(zipBox)
        selView = tv("Nenhum ZIP selecionado", 15f)
        root.addView(selView)

        root.addView(tv("3. Compilar", 18f, true))
        compileBtn = btn("Compilar APK") { startBuild(repo.text.toString().trim()) }
        root.addView(compileBtn)
        progress = ProgressBar(this).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        root.addView(progress)
        logView = tv("", 13f)
        root.addView(logView)
        installBtn = btn("Instalar APK") { apkFile?.let { installApk(it) } }
        installBtn?.visibility = View.GONE
        root.addView(installBtn)
    }

    // ---------- Permissão e busca de ZIPs ----------

    private fun hasStorageAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        }
    }

    private fun scanZips() {
        if (!hasStorageAccess()) {
            requestStorage()
            toast("Permita o acesso aos arquivos e toque em Procurar de novo.")
            return
        }
        zipBox?.removeAllViews()
        selView?.text = "Procurando..."
        thread {
            val found = mutableListOf<File>()
            fun walk(d: File, depth: Int) {
                if (depth > 5 || found.size >= 100) return
                val list = d.listFiles() ?: return
                for (f in list) {
                    if (f.name.startsWith(".")) continue
                    if (f.isDirectory) {
                        if (f.name != "Android") walk(f, depth + 1)
                    } else if (f.name.endsWith(".zip", true)) {
                        found.add(f)
                    }
                }
            }
            walk(Environment.getExternalStorageDirectory(), 0)
            found.sortByDescending { it.lastModified() }
            runOnUiThread {
                selView?.text = if (found.isEmpty()) {
                    "Nenhum ZIP encontrado."
                } else {
                    "${found.size} ZIP(s) encontrado(s). Toque para escolher:"
                }
                found.forEach { f -> addZipButton(ZipItem(f.name, f.length(), f, null)) }
            }
        }
    }

    private fun addZipButton(z: ZipItem) {
        val mb = String.format("%.1f", z.size / 1048576.0)
        zipBox?.addView(btn("${z.name}  ($mb MB)") {
            selected = z
            selView?.text = "Selecionado: ${z.name}"
        })
    }

    private fun pickZip() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed"))
        startActivityForResult(i, 7)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 7 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        var name = "projeto.zip"
        var size = 0L
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (n >= 0) name = c.getString(n)
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (s >= 0) size = c.getLong(s)
            }
        }
        selected = ZipItem(name, size, null, uri)
        selView?.text = "Selecionado: $name"
    }

    // ---------- Build ----------

    private fun startBuild(repo: String) {
        val token = prefs.getString("token", null)
        if (token == null) {
            showLogin()
            return
        }
        if (!Regex("[\\w.-]+/[\\w.-]+").matches(repo)) {
            toast("Digite o repositório como usuario/repositorio")
            return
        }
        val z = selected
        if (z == null) {
            toast("Escolha um ZIP primeiro")
            return
        }
        prefs.edit().putString("repo", repo).apply()
        logView?.text = ""
        installBtn?.visibility = View.GONE
        progress?.visibility = View.VISIBLE
        compileBtn?.isEnabled = false
        thread {
            try {
                runBuild(token, repo, z)
            } catch (e: Exception) {
                log("Erro: ${e.message}")
            }
            runOnUiThread {
                progress?.visibility = View.GONE
                compileBtn?.isEnabled = true
            }
        }
    }

    private fun putFile(api: String, token: String, path: String, data: ByteArray, branch: String, msg: String) {
        val encoded = Base64.encodeToString(data, Base64.NO_WRAP)
        val cur = Gh.call("GET", "$api/contents/$path?ref=$branch", token)
        val body = JSONObject().put("message", msg).put("branch", branch).put("content", encoded)
        if (cur.code == 200) {
            val existing = JSONObject(cur.body)
            if (existing.optString("content").replace("\n", "") == encoded) return
            body.put("sha", existing.getString("sha"))
        }
        val r = Gh.call("PUT", "$api/contents/$path", token, body.toString())
        if (r.code !in 200..201) {
            val m = try { JSONObject(r.body).optString("message") } catch (e: Exception) { "" }
            throw Exception("Falha ao enviar $path (${r.code}) $m")
        }
    }

    private fun latestRunId(api: String, token: String): Long {
        val r = Gh.call("GET", "$api/actions/workflows/zip-build.yml/runs?event=workflow_dispatch&per_page=1", token)
        if (r.code != 200) return 0L
        val arr = JSONObject(r.body).optJSONArray("workflow_runs") ?: return 0L
        return if (arr.length() > 0) arr.getJSONObject(0).getLong("id") else 0L
    }

    private fun traduz(s: String): String = when (s) {
        "queued" -> "na fila"
        "in_progress" -> "compilando"
        "completed" -> "concluído"
        else -> s
    }

    private fun runBuild(token: String, repo: String, z: ZipItem) {
        val api = "https://api.github.com/repos/$repo"

        log("Verificando repositório...")
        val info = Gh.call("GET", api, token)
        if (info.code != 200) throw Exception("Repositório não encontrado ou sem permissão (${info.code})")
        val branch = JSONObject(info.body).getString("default_branch")

        log("Instalando o workflow de build...")
        val wf = assets.open("zip-build.yml").use { it.readBytes() }
        putFile(api, token, ".github/workflows/zip-build.yml", wf, branch, "ANDROIDSDK: workflow de build")

        log("Enviando ${z.name}...")
        val bytes = z.file?.readBytes()
            ?: contentResolver.openInputStream(z.uri!!)!!.use { it.readBytes() }
        if (bytes.size > 90 * 1024 * 1024) throw Exception("O ZIP passa de 90 MB, limite da API do GitHub.")
        val safe = z.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val zipPath = "uploads/${System.currentTimeMillis()}-$safe"
        putFile(api, token, zipPath, bytes, branch, "ANDROIDSDK: envio de ${z.name}")

        val prevId = latestRunId(api, token)

        log("Iniciando a compilação...")
        var started = false
        for (i in 1..8) {
            val body = JSONObject().put("ref", branch)
                .put("inputs", JSONObject().put("zip", zipPath)).toString()
            val r = Gh.call("POST", "$api/actions/workflows/zip-build.yml/dispatches", token, body)
            if (r.code == 204) {
                started = true
                break
            }
            Thread.sleep(4000)
        }
        if (!started) {
            throw Exception("Não consegui iniciar o build. Confira se o token tem a permissão workflow.")
        }

        log("Aguardando o GitHub compilar (pode levar alguns minutos)...")
        var runNumber = 0L
        var lastStatus = ""
        val end = System.currentTimeMillis() + 30 * 60 * 1000L
        while (System.currentTimeMillis() < end) {
            Thread.sleep(8000)
            val r = Gh.call("GET", "$api/actions/workflows/zip-build.yml/runs?event=workflow_dispatch&per_page=5", token)
            if (r.code != 200) continue
            val arr = JSONObject(r.body).optJSONArray("workflow_runs") ?: continue
            var cur: JSONObject? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.getLong("id") > prevId) {
                    cur = o
                    break
                }
            }
            if (cur == null) continue
            val status = cur.getString("status")
            if (status != lastStatus) {
                log("Status: ${traduz(status)}")
                lastStatus = status
            }
            if (status == "completed") {
                val conclusion = cur.optString("conclusion")
                if (conclusion != "success") {
                    throw Exception("O build falhou ($conclusion). Veja os logs em ${cur.getString("html_url")}")
                }
                runNumber = cur.getLong("run_number")
                break
            }
        }
        if (runNumber == 0L) throw Exception("Tempo esgotado esperando o build.")

        log("Baixando o APK...")
        var asset: JSONObject? = null
        for (i in 1..5) {
            val rel = Gh.call("GET", "$api/releases/tags/build-$runNumber", token)
            if (rel.code == 200) {
                val list = JSONObject(rel.body).getJSONArray("assets")
                if (list.length() > 0) {
                    asset = list.getJSONObject(0)
                    break
                }
            }
            Thread.sleep(3000)
        }
        if (asset == null) throw Exception("APK não encontrado nos Releases do repositório.")

        val dir = File(getExternalFilesDir(null), "apks")
        dir.mkdirs()
        val dest = File(dir, "ANDROIDSDK-build-$runNumber.apk")
        Gh.downloadAsset(repo, asset.getLong("id"), token, dest)
        apkFile = dest
        log("Pronto! APK baixado (${dest.length() / 1024} KB). Ele também está em Releases no GitHub.")
        runOnUiThread { installBtn?.visibility = View.VISIBLE }
    }

    // ---------- Instalação ----------

    private fun installApk(f: File) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            toast("Permita instalar apps deste aplicativo e toque em Instalar de novo.")
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }
}
