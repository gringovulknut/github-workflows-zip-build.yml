package com.androidsdk.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {

    lateinit var ui: Ui
    lateinit var root: LinearLayout
    lateinit var home: HomeTab
    lateinit var code: CodeTab
    lateinit var build: BuildTab
    lateinit var apk: ApkTab
    lateinit var updates: UpdatesTab
    lateinit var settings: SettingsTab

    var cur = 0
    private var pending: ((Uri) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.init(this)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        home = HomeTab(this)
        code = CodeTab(this)
        build = BuildTab(this)
        apk = ApkTab(this)
        updates = UpdatesTab(this)
        settings = SettingsTab(this)
        render()
    }

    override fun onPause() {
        code.saveIfOpen()
        super.onPause()
    }

    fun go(i: Int) {
        code.saveIfOpen()
        cur = i
        render()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (cur == 1 && code.back()) return
        if (cur != 0) {
            go(0)
            return
        }
        super.onBackPressed()
    }

    // ---------- Casca do app: conteúdo + barra de abas ----------

    fun render() {
        ui = Ui(this)
        applyWindow()

        val frame = LinearLayout(this)
        frame.orientation = LinearLayout.VERTICAL
        frame.setBackgroundColor(ui.p.bg)

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(ui.dp(16), ui.dp(16), ui.dp(16), ui.dp(24))
        scroll.addView(root)
        frame.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val line = View(this)
        line.setBackgroundColor(ui.p.border)
        frame.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
        frame.addView(
            nav(),
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )
        setContentView(frame)

        when (cur) {
            0 -> home.show()
            1 -> code.show()
            2 -> build.show()
            3 -> apk.show()
            4 -> updates.show()
            else -> settings.show()
        }
    }

    private fun nav(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(ui.p.surface)
        val items = listOf(
            "🏠" to t("Início", "Home"),
            "💻" to t("Código", "Code"),
            "🔨" to t("Compilar", "Build"),
            "📦" to "APK→ZIP",
            "⬆" to t("Atualizar", "Updates"),
            "⚙" to t("Config.", "Settings")
        )
        items.forEachIndexed { i, (icon, label) ->
            val tv = TextView(this)
            tv.text = "$icon\n$label"
            tv.gravity = android.view.Gravity.CENTER
            tv.textSize = 11f
            tv.typeface = ui.face
            tv.setPadding(0, ui.dp(8), 0, ui.dp(8))
            tv.setTextColor(if (i == cur) ui.p.accent else ui.p.sub)
            tv.setOnClickListener { go(i) }
            bar.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        return bar
    }

    @Suppress("DEPRECATION")
    private fun applyWindow() {
        window.statusBarColor = ui.p.bg
        window.navigationBarColor = ui.p.surface
        var f = window.decorView.systemUiVisibility
        if (ui.p.light) {
            f = f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        } else {
            f = f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            if (Build.VERSION.SDK_INT >= 26) f = f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        }
        window.decorView.systemUiVisibility = f
    }

    // ---------- Diálogos e seletores de arquivo ----------

    fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    fun askText(title: String, hint: String, def: String = "", ok: (String) -> Unit) {
        val e = ui.edit(hint, def)
        val box = FrameLayout(this)
        box.setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
        box.addView(e, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ -> ok(e.text.toString().trim()) }
            .setNegativeButton(t("Cancelar", "Cancel"), null)
            .show()
    }

    fun confirm(msg: String, ok: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(msg)
            .setPositiveButton(t("Sim", "Yes")) { _, _ -> ok() }
            .setNegativeButton(t("Não", "No"), null)
            .show()
    }

    fun choose(title: String, items: List<String>, cb: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(items.toTypedArray()) { _, i -> cb(i) }
            .show()
    }

    @Suppress("DEPRECATION")
    fun pickFile(cb: (Uri) -> Unit) {
        pending = cb
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, 101)
    }

    @Suppress("DEPRECATION")
    fun createFile(name: String, cb: (Uri) -> Unit) {
        pending = cb
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/zip"
        i.putExtra(Intent.EXTRA_TITLE, name)
        startActivityForResult(i, 102)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val cb = pending
        pending = null
        val u = data?.data
        if (resultCode == RESULT_OK && u != null && cb != null) cb(u)
    }

    // ---------- Instalação de APK ----------

    fun installApk(f: File) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            toast(t("Permita instalar apps deste aplicativo e toque em Instalar de novo.", "Allow installing apps from this app, then tap Install again."))
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }
}
