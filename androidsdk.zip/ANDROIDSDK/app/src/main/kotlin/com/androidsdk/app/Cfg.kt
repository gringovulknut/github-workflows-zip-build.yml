package com.androidsdk.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Texto bilíngue: devolve o português ou o inglês conforme o idioma escolhido. */
fun t(pt: String, en: String): String = if (Cfg.lang == "en") en else pt

object Cfg {
    private lateinit var sp: SharedPreferences
    private var secure: SharedPreferences? = null
    private val mem = HashMap<String, String>()

    fun init(c: Context) {
        sp = c.getSharedPreferences("androidsdk_cfg", Context.MODE_PRIVATE)
        secure = try {
            val key = MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                c, "androidsdk_prefs", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun sget(k: String): String = secure?.getString(k, "") ?: mem[k] ?: ""

    private fun sput(k: String, v: String) {
        val s = secure
        if (s != null) s.edit().putString(k, v).apply() else mem[k] = v
    }

    // ---- GitHub (opcional) ----
    var ghToken: String
        get() = sget("token")
        set(v) = sput("token", v)
    var ghLogin: String
        get() = sget("login")
        set(v) = sput("login", v)
    var ghClientId: String
        get() = sget("client_id")
        set(v) = sput("client_id", v)
    var ghRepo: String
        get() = sget("repo")
        set(v) = sput("repo", v)
    var ghPrivate: Boolean
        get() = sp.getBoolean("gh_private", true)
        set(v) = sp.edit().putBoolean("gh_private", v).apply()

    // ---- Aparência e idioma ----
    var theme: String
        get() = sp.getString("theme", "fosco") ?: "fosco"
        set(v) = sp.edit().putString("theme", v).apply()
    var font: String
        get() = sp.getString("font", "sans") ?: "sans"
        set(v) = sp.edit().putString("font", v).apply()
    var fontSize: Int
        get() = sp.getInt("font_size", 15)
        set(v) = sp.edit().putInt("font_size", v).apply()
    var lang: String
        get() = sp.getString("lang", "pt") ?: "pt"
        set(v) = sp.edit().putString("lang", v).apply()

    // ---- Linguagens e projetos ----
    fun langOn(id: String): Boolean = sp.getBoolean("lang_$id", true)
    fun setLangOn(id: String, v: Boolean) = sp.edit().putBoolean("lang_$id", v).apply()
    var lastProject: String
        get() = sp.getString("last_project", "") ?: ""
        set(v) = sp.edit().putString("last_project", v).apply()
    var updateRepo: String
        get() = sp.getString("update_repo", "") ?: ""
        set(v) = sp.edit().putString("update_repo", v).apply()
}
