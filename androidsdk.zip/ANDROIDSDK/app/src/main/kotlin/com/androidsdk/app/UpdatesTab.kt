package com.androidsdk.app

import android.content.Intent
import android.net.Uri
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

class UpdatesTab(private val a: MainActivity) {

    private class Entry(val tag: String, val date: String, val assetId: Long, val size: Long)

    private var list: LinearLayout? = null
    private var status: TextView? = null
    private var version = "?"
    private var repoField: android.widget.EditText? = null

    fun show() {
        val ui = a.ui
        val r = a.root
        ui.add(r, ui.title(t("Atualizações", "Updates")), 4)

        version = try {
            a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "?"
        } catch (e: Exception) {
            "?"
        }
        ui.add(r, ui.sub(t("Versão instalada: ", "Installed version: ") + version), 12)

        val saved = Cfg.updateRepo.ifBlank { if (GitHubSvc.connected()) GitHubSvc.repoName() else "" }
        ui.add(r, ui.sub(t("Repositório onde ficam os APKs (Releases). Funciona sem login se for público.", "Repository holding the APKs (Releases). Works without login if public.")), 4)
        val rf = ui.edit("usuario/repositorio", saved)
        repoField = rf
        ui.add(r, rf, 8)

        ui.add(r, ui.btn("🔍 " + t("Verificar atualizações", "Check for updates"), true) { check(rf.text.toString().trim()) })
        ui.add(r, ui.btn("🌐 " + t("Abrir minha página no GitHub", "Open my GitHub page")) {
            val owner = if (Cfg.ghLogin.isNotBlank()) Cfg.ghLogin else rf.text.toString().trim().substringBefore('/')
            if (owner.isBlank()) a.toast(t("Digite o repositório ou conecte o GitHub.", "Enter the repository or connect GitHub.")) else open("https://github.com/$owner")
        })
        ui.add(r, ui.btn("📦 " + t("Ver releases no GitHub", "View releases on GitHub")) {
            val repo = rf.text.toString().trim()
            if (!valid(repo)) a.toast(t("Digite o repositório como usuario/repositorio", "Enter the repository as user/repository")) else open("https://github.com/$repo/releases")
        }, 12)

        val st = ui.sub("")
        status = st
        ui.add(r, st, 8)
        val l = LinearLayout(a)
        l.orientation = LinearLayout.VERTICAL
        list = l
        ui.add(r, l, 8)
    }

    private fun valid(repo: String) = Regex("[\\w.-]+/[\\w.-]+").matches(repo)

    private fun open(url: String) {
        a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun setStatus(t: String) {
        a.runOnUiThread { status?.text = t }
    }

    private fun check(repo: String) {
        if (!valid(repo)) {
            a.toast(t("Digite o repositório como usuario/repositorio", "Enter the repository as user/repository"))
            return
        }
        Cfg.updateRepo = repo
        val token = if (GitHubSvc.connected()) Cfg.ghToken else null
        setStatus(t("Consultando o GitHub...", "Contacting GitHub..."))
        list?.removeAllViews()
        thread {
            try {
                val r = Gh.call("GET", "https://api.github.com/repos/$repo/releases?per_page=20", token)
                if (r.code != 200) throw Exception(t("Não consegui ler os releases", "Could not read the releases") + " (${r.code})")
                val arr = JSONArray(r.body)
                val found = mutableListOf<Entry>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optBoolean("prerelease")) continue
                    val assets = o.optJSONArray("assets") ?: continue
                    for (k in 0 until assets.length()) {
                        val s = assets.getJSONObject(k)
                        if (s.optString("name").endsWith(".apk", true)) {
                            found.add(Entry(o.optString("tag_name"), o.optString("published_at").take(10), s.getLong("id"), s.optLong("size")))
                            break
                        }
                    }
                    if (found.size >= 6) break
                }
                a.runOnUiThread {
                    if (found.isEmpty()) {
                        status?.text = t("Nenhum release com APK encontrado nesse repositório.", "No release with an APK found in this repository.")
                    } else {
                        status?.text = t("Toque em uma versão para baixar e instalar:", "Tap a version to download and install:")
                        found.forEach { e -> addEntry(repo, e) }
                    }
                }
            } catch (e: Exception) {
                setStatus(t("Erro: ", "Error: ") + e.message)
            }
        }
    }

    private fun addEntry(repo: String, e: Entry) {
        val mb = String.format(Locale.US, "%.1f", e.size / 1048576.0)
        val mark = if (e.tag.removePrefix("v") == version) "  (" + t("instalada", "installed") + ")" else ""
        list?.let { ui -> a.ui.add(ui, a.ui.btn("${e.tag} · ${e.date} · $mb MB$mark") { download(repo, e) }, 6) }
    }

    private fun download(repo: String, e: Entry) {
        val token = if (GitHubSvc.connected()) Cfg.ghToken else null
        setStatus(t("Baixando ${e.tag}...", "Downloading ${e.tag}..."))
        thread {
            try {
                val dir = File(a.getExternalFilesDir(null), "apks")
                dir.mkdirs()
                val dest = File(dir, "${repo.replace('/', '_')}-${e.tag}.apk")
                Gh.downloadAsset(repo, e.assetId, token, dest)
                a.runOnUiThread {
                    status?.text = t("Download concluído.", "Download complete.")
                    a.installApk(dest)
                }
            } catch (ex: Exception) {
                setStatus(t("Erro: ", "Error: ") + ex.message)
            }
        }
    }
}
