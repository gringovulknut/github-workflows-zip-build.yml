package com.androidsdk.app

import android.content.Intent
import android.net.Uri
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

class UpdatesTab(private val a: MainActivity) {

    private class Entry(val tag: String, val date: String, val assetId: Long, val size: Long)

    private var list: LinearLayout? = null
    private var status: TextView? = null
    private var version = "?"

    fun show() {
        val root = a.root
        root.removeAllViews()
        root.addView(a.tv("Atualizações", 24f, true))

        version = try {
            a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "?"
        } catch (e: Exception) {
            "?"
        }
        root.addView(a.tv("Versão instalada: $version", 15f))

        val login = a.prefs.getString("login", "") ?: ""
        val saved = a.prefs.getString("update_repo", null) ?: a.prefs.getString("repo", "") ?: ""
        root.addView(a.tv("Repositório onde ficam os APKs (Releases):", 13f))
        val repoField = a.edit("usuario/repositorio", saved)
        root.addView(repoField)

        root.addView(a.btn("🔍 Verificar atualizações") { check(repoField.text.toString().trim()) })
        root.addView(a.btn("🌐 Abrir minha página no GitHub") {
            if (login.isBlank()) a.toast("Entre na conta GitHub primeiro.") else open("https://github.com/$login")
        })
        root.addView(a.btn("📦 Ver releases no GitHub") {
            val r = repoField.text.toString().trim()
            if (!valid(r)) a.toast("Digite o repositório como usuario/repositorio") else open("https://github.com/$r/releases")
        })

        val st = a.tv("", 14f)
        status = st
        root.addView(st)
        val l = LinearLayout(a)
        l.orientation = LinearLayout.VERTICAL
        list = l
        root.addView(l)
    }

    private fun valid(repo: String) = Regex("[\\w.-]+/[\\w.-]+").matches(repo)

    private fun open(url: String) {
        a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun setStatus(t: String) {
        a.runOnUiThread { status?.text = t }
    }

    private fun check(repo: String) {
        if (!valid(repo)) {
            a.toast("Digite o repositório como usuario/repositorio")
            return
        }
        a.prefs.edit().putString("update_repo", repo).apply()
        val token = a.prefs.getString("token", null)
        setStatus("Consultando o GitHub...")
        list?.removeAllViews()
        thread {
            try {
                val r = Gh.call("GET", "https://api.github.com/repos/$repo/releases?per_page=20", token)
                if (r.code != 200) throw Exception("Não consegui ler os releases (${r.code})")
                val arr = org.json.JSONArray(r.body)
                val found = mutableListOf<Entry>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optBoolean("prerelease")) continue
                    val assets = o.optJSONArray("assets") ?: continue
                    for (k in 0 until assets.length()) {
                        val s = assets.getJSONObject(k)
                        if (s.optString("name").endsWith(".apk", true)) {
                            found.add(
                                Entry(
                                    o.optString("tag_name"),
                                    o.optString("published_at").take(10),
                                    s.getLong("id"),
                                    s.optLong("size")
                                )
                            )
                            break
                        }
                    }
                    if (found.size >= 6) break
                }
                a.runOnUiThread {
                    if (found.isEmpty()) {
                        status?.text = "Nenhum release com APK encontrado nesse repositório."
                    } else {
                        status?.text = "Toque em uma versão para baixar e instalar:"
                        found.forEach { e -> addEntry(repo, e) }
                    }
                }
            } catch (e: Exception) {
                setStatus("Erro: ${e.message}")
            }
        }
    }

    private fun addEntry(repo: String, e: Entry) {
        val mb = String.format(Locale.US, "%.1f", e.size / 1048576.0)
        val mark = if (e.tag.removePrefix("v") == version) "  (instalada)" else ""
        list?.addView(a.btn("${e.tag} · ${e.date} · $mb MB$mark") { download(repo, e) })
    }

    private fun download(repo: String, e: Entry) {
        val token = a.prefs.getString("token", null)
        if (token == null) {
            a.toast("Entre na conta GitHub primeiro.")
            return
        }
        setStatus("Baixando ${e.tag}...")
        thread {
            try {
                val dir = File(a.getExternalFilesDir(null), "apks")
                dir.mkdirs()
                val dest = File(dir, "${repo.replace('/', '_')}-${e.tag}.apk")
                Gh.downloadAsset(repo, e.assetId, token, dest)
                a.runOnUiThread {
                    status?.text = "Download concluído."
                    a.installApk(dest)
                }
            } catch (ex: Exception) {
                setStatus("Erro: ${ex.message}")
            }
        }
    }
}
