package com.androidsdk.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import dalvik.system.DexClassLoader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.PrintStream
import java.lang.reflect.InvocationTargetException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Motor Kotlin local. O compilador já vem convertido para DEX dentro do app (o GitHub faz isso no build),
 * então nada pesado roda no celular na hora de instalar. A compilação roda em um processo separado:
 * se faltar memória, só esse processo morre e o app continua aberto.
 */
object KotlinEngine {

    fun dir(a: Context): File = File(a.filesDir, "kotlin")

    fun jar(a: Context): File = File(dir(a), "kotlinc.jar")

    fun stdlib(a: Context): File = File(dir(a), "kotlin-stdlib.jar")

    fun ready(a: Context): Boolean = jar(a).exists() && stdlib(a).exists()

    fun bundled(a: Context): Boolean = try {
        a.assets.open("kotlinc.jar").close()
        a.assets.open("kotlin-stdlib.jar").close()
        true
    } catch (e: Exception) {
        false
    }

    fun remove(a: Context) {
        dir(a).deleteRecursively()
    }

    /** Copia o compilador embutido para a pasta do app. Rápido e sem internet. */
    fun prepare(a: Context, log: (String) -> Unit) {
        if (!bundled(a)) {
            throw Exception(t("Este build do app não trouxe o compilador Kotlin. Gere o APK do ANDROIDSDK de novo pelo GitHub (a conversão é feita lá).", "This app build does not include the Kotlin compiler. Rebuild ANDROIDSDK via GitHub (the conversion happens there)."))
        }
        dir(a).mkdirs()
        for (n in listOf("kotlinc.jar", "kotlin-stdlib.jar")) {
            val dst = File(dir(a), n)
            val tmp = File(dir(a), "$n.part")
            log("📥 $n")
            a.assets.open(n).use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            if (!tmp.renameTo(dst)) {
                dst.delete()
                tmp.renameTo(dst)
            }
        }
        log(t("Motor Kotlin ativado.", "Kotlin engine enabled."))
    }

    // ---------- cliente (processo principal) ----------

    fun compile(a: Context, androidJar: File, sources: List<File>, outDir: File, log: (String) -> Unit): String? {
        val app = a.applicationContext
        val latch = CountDownLatch(1)
        var result: String? = null
        var replied = false
        val replyMessenger = Messenger(Handler(Looper.getMainLooper()) { m ->
            result = m.data.getString("error")
            replied = true
            latch.countDown()
            true
        })
        val conn = object : ServiceConnection {
            override fun onServiceConnected(n: ComponentName, b: IBinder) {
                try {
                    val msg = Message.obtain()
                    msg.replyTo = replyMessenger
                    val d = Bundle()
                    d.putString("androidJar", androidJar.path)
                    d.putStringArrayList("sources", ArrayList(sources.map { it.path }))
                    d.putString("out", outDir.path)
                    msg.data = d
                    Messenger(b).send(msg)
                } catch (e: Exception) {
                    result = "Kotlin: " + e.message
                    replied = true
                    latch.countDown()
                }
            }

            override fun onServiceDisconnected(n: ComponentName) {
                if (!replied) {
                    result = t(
                        "O processo do compilador Kotlin foi encerrado pelo Android, provavelmente por falta de memória. O app continua aberto. Feche outros apps e tente de novo, ou compile pelo GitHub.",
                        "The Kotlin compiler process was killed by Android, probably out of memory. The app is still open. Close other apps and try again, or build via GitHub."
                    )
                    latch.countDown()
                }
            }
        }
        log(t("Iniciando o compilador Kotlin em processo separado...", "Starting the Kotlin compiler in a separate process..."))
        if (!app.bindService(Intent(app, KotlinService::class.java), conn, Context.BIND_AUTO_CREATE)) {
            return "Kotlin: não consegui iniciar o serviço do compilador."
        }
        val ok = latch.await(15, TimeUnit.MINUTES)
        try {
            app.unbindService(conn)
        } catch (e: Exception) {
        }
        return if (!ok) t("Tempo esgotado esperando o compilador Kotlin.", "Timed out waiting for the Kotlin compiler.") else result
    }

    // ---------- servidor (processo :kotlinc) ----------

    fun compileInProcess(a: Context, androidJar: File, sources: List<File>, outDir: File): String? {
        val bos = ByteArrayOutputStream()
        val old = Thread.currentThread().contextClassLoader
        try {
            val loader = DexClassLoader(jar(a).path, a.codeCacheDir.path, null, a.classLoader)
            Thread.currentThread().contextClassLoader = loader
            val cls = loader.loadClass("org.jetbrains.kotlin.cli.jvm.K2JVMCompiler")
            val inst = cls.getDeclaredConstructor().newInstance()
            val m = cls.methods.first { it.name == "exec" && it.parameterTypes.size == 2 && it.parameterTypes[0] == PrintStream::class.java }
            val ps = PrintStream(bos, true, "UTF-8")
            val args = ArrayList<String>()
            args.addAll(listOf(
                "-no-stdlib", "-no-reflect", "-no-jdk", "-jvm-target", "1.8", "-Xskip-prerelease-check", "-nowarn",
                "-classpath", androidJar.path + File.pathSeparator + stdlib(a).path,
                "-d", outDir.path
            ))
            sources.forEach { args.add(it.path) }
            val res = m.invoke(inst, ps, args.toTypedArray())
            ps.flush()
            return if (res.toString() == "OK") null else "Kotlin: $res\n" + bos.toString("UTF-8").take(4000)
        } catch (e: InvocationTargetException) {
            return diag(e.targetException ?: e, bos)
        } catch (e: Throwable) {
            return diag(e, bos)
        } finally {
            Thread.currentThread().contextClassLoader = old
        }
    }

    private fun diag(e: Throwable, out: ByteArrayOutputStream): String {
        val trace = e.stackTrace.take(8).joinToString("\n") { "   at $it" }
        return "Kotlin (experimental) " + t("falhou: ", "failed: ") + e.javaClass.name + ": " + (e.message ?: "") + "\n" + trace +
            (if (out.size() > 0) "\n" + out.toString("UTF-8").take(2000) else "")
    }
}
