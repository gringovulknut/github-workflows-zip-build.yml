package com.androidsdk.app

import android.content.Context
import com.android.tools.r8.CompilationMode
import com.android.tools.r8.D8
import com.android.tools.r8.D8Command
import com.android.tools.r8.OutputMode
import dalvik.system.DexClassLoader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.PrintStream
import java.lang.reflect.InvocationTargetException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Motor Kotlin LOCAL (experimental). Baixa o compilador oficial do Maven Central uma vez, converte para DEX
 * com o D8 embutido e o carrega com DexClassLoader. Fica separado do resto do app: se falhar, só o Kotlin é afetado.
 */
object KotlinEngine {
    const val V = "1.9.24"
    private const val M = "https://repo1.maven.org/maven2"

    private val jars = listOf(
        "kotlin-compiler-embeddable-$V.jar" to "$M/org/jetbrains/kotlin/kotlin-compiler-embeddable/$V/kotlin-compiler-embeddable-$V.jar",
        "kotlin-stdlib-$V.jar" to "$M/org/jetbrains/kotlin/kotlin-stdlib/$V/kotlin-stdlib-$V.jar",
        "kotlin-script-runtime-$V.jar" to "$M/org/jetbrains/kotlin/kotlin-script-runtime/$V/kotlin-script-runtime-$V.jar",
        "kotlin-reflect-1.6.10.jar" to "$M/org/jetbrains/kotlin/kotlin-reflect/1.6.10/kotlin-reflect-1.6.10.jar",
        "kotlin-daemon-embeddable-$V.jar" to "$M/org/jetbrains/kotlin/kotlin-daemon-embeddable/$V/kotlin-daemon-embeddable-$V.jar",
        "trove4j-1.0.20200330.jar" to "$M/org/jetbrains/intellij/deps/trove4j/1.0.20200330/trove4j-1.0.20200330.jar",
        "annotations-13.0.jar" to "$M/org/jetbrains/annotations/13.0/annotations-13.0.jar"
    )

    fun dir(a: Context): File = File(a.filesDir, "kotlin")

    fun stdlib(a: Context): File = File(dir(a), "kotlin-stdlib-$V.jar")

    fun ready(a: Context): Boolean = File(dir(a), "kotlinc.jar").exists() && stdlib(a).exists()

    fun remove(a: Context) {
        dir(a).deleteRecursively()
    }

    private fun download(url: String, dest: File, onProgress: (Long, Long) -> Unit) {
        val tmp = File(dest.path + ".part")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.setRequestProperty("User-Agent", "ANDROIDSDK-App")
        if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode} em $url")
        val total = c.contentLengthLong
        c.inputStream.use { input ->
            tmp.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var lastTick = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (done - lastTick > 2_000_000) {
                        lastTick = done
                        onProgress(done, total)
                    }
                }
            }
        }
        c.disconnect()
        if (!tmp.renameTo(dest)) throw Exception("Não consegui salvar " + dest.name)
    }

    private fun isSignature(n: String): Boolean =
        n == "META-INF/MANIFEST.MF" || (n.startsWith("META-INF/") && (n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC")))

    /** Baixa os jars, converte para DEX e monta o kotlinc.jar (classes.dex + recursos). */
    fun prepare(a: Context, androidJar: File, log: (String) -> Unit) {
        val d = dir(a)
        d.mkdirs()
        jars.forEachIndexed { i, (name, url) ->
            val f = File(d, name)
            if (!f.exists()) {
                log("⬇ ${i + 1}/${jars.size} $name")
                download(url, f) { done, total ->
                    log("   " + done / 1048576 + " MB" + if (total > 0) " / " + total / 1048576 + " MB" else "")
                }
            }
        }
        val finalJar = File(d, "kotlinc.jar")
        if (finalJar.exists()) return

        log(t("Convertendo o compilador Kotlin para o Android (D8). Pode levar vários minutos e usar bastante memória...", "Converting the Kotlin compiler for Android (D8). May take several minutes and a lot of memory..."))
        val dexZip = File(d, "kotlinc-dex.zip")
        dexZip.delete()
        val b = D8Command.builder()
        jars.forEach { b.addProgramFiles(File(d, it.first).toPath()) }
        b.addLibraryFiles(androidJar.toPath())
        b.setOutput(dexZip.toPath(), OutputMode.DexIndexed)
        b.setMinApiLevel(26)
        b.setMode(CompilationMode.DEBUG)
        D8.run(b.build())

        log(t("Juntando os recursos do compilador...", "Merging the compiler resources..."))
        val tmpJar = File(d, "kotlinc.jar.part")
        ZipOutputStream(tmpJar.outputStream().buffered()).use { zo ->
            val seen = HashSet<String>()
            ZipFile(dexZip).use { z ->
                for (e in z.entries()) {
                    if (e.isDirectory || !seen.add(e.name)) continue
                    zo.putNextEntry(ZipEntry(e.name))
                    z.getInputStream(e).use { it.copyTo(zo) }
                    zo.closeEntry()
                }
            }
            for ((name, _) in jars) {
                ZipFile(File(d, name)).use { z ->
                    for (e in z.entries()) {
                        if (e.isDirectory || e.name.endsWith(".class") || isSignature(e.name) || !seen.add(e.name)) continue
                        zo.putNextEntry(ZipEntry(e.name))
                        z.getInputStream(e).use { it.copyTo(zo) }
                        zo.closeEntry()
                    }
                }
            }
        }
        if (!tmpJar.renameTo(finalJar)) throw Exception("Não consegui criar o kotlinc.jar")
        dexZip.delete()
        log(t("Motor Kotlin instalado.", "Kotlin engine installed."))
    }

    private fun diag(e: Throwable, out: ByteArrayOutputStream): String {
        val trace = e.stackTrace.take(8).joinToString("\n") { "   at $it" }
        return "Kotlin (experimental) " + t("falhou: ", "failed: ") + e.javaClass.name + ": " + (e.message ?: "") + "\n" + trace +
            (if (out.size() > 0) "\n" + out.toString("UTF-8").take(2000) else "")
    }

    /** Compila .kt (e lê .java para resolver símbolos) para .class em outDir. Devolve null se deu certo, ou o erro. */
    fun compile(a: Context, androidJar: File, sources: List<File>, outDir: File): String? {
        val bos = ByteArrayOutputStream()
        val old = Thread.currentThread().contextClassLoader
        try {
            val loader = DexClassLoader(File(dir(a), "kotlinc.jar").path, a.codeCacheDir.path, null, a.classLoader)
            Thread.currentThread().contextClassLoader = loader
            val cls = loader.loadClass("org.jetbrains.kotlin.cli.jvm.K2JVMCompiler")
            val inst = cls.getDeclaredConstructor().newInstance()
            val m = cls.methods.first { it.name == "exec" && it.parameterTypes.size == 2 && it.parameterTypes[0] == PrintStream::class.java }
            val ps = PrintStream(bos, true, "UTF-8")
            val args = ArrayList<String>()
            args.addAll(listOf(
                "-no-stdlib", "-no-reflect", "-no-jdk", "-jvm-target", "1.8", "-Xskip-prerelease-check", "-nowarn",
                "-classpath", androidJar.path + File.pathSeparator + stdlib(a).path,
                "-d", outDir.path
            ))
            sources.forEach { args.add(it.path) }
            val res = m.invoke(inst, ps, args.toTypedArray())
            ps.flush()
            return if (res.toString() == "OK") null else "Kotlin: $res\n" + bos.toString("UTF-8").take(4000)
        } catch (e: InvocationTargetException) {
            return diag(e.targetException ?: e, bos)
        } catch (e: Throwable) {
            return diag(e, bos)
        } finally {
            Thread.currentThread().contextClassLoader = old
        }
    }
}
