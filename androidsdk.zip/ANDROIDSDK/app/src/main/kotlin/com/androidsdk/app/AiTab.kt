package com.androidsdk.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import java.io.File
import kotlin.concurrent.thread

/** Aba de IA: conversa com o Claude dentro do app. */
class AiTab(private val a: MainActivity) {

    private class Msg(val role: String, val text: String)

    private val msgs = ArrayList<Msg>()
    private var busy = false
    private var draft = ""
    private var error = ""
    private var inputRef: EditText? = null

    private val fence = Regex("```([A-Za-z0-9+#._-]*)\\n(.*?)```", RegexOption.DOT_MATCHES_ALL)

    fun show() {
        val ui = a.ui
        val r = a.root
        ui.add(r, ui.title("🤖 " + t("Assistente de IA", "AI assistant")), 4)
        ui.add(r, ui.sub(t("Converse com o Claude sobre o seu código, erros de compilação e ideias de app.", "Chat with Claude about your code, build errors and app ideas.")), 12)

        if (Cfg.aiKey.isBlank()) {
            val c = ui.card()
            c.addView(ui.text(t("Falta a chave da API", "API key missing"), ui.fs, ui.p.text, true))
            c.addView(ui.sub(t(
                "Para falar com o Claude por aqui você precisa de uma chave da API da Anthropic (console.anthropic.com). O uso é cobrado na sua conta da Anthropic. A chave fica guardada só no seu celular.",
                "To talk to Claude here you need an Anthropic API key (console.anthropic.com). Usage is billed to your Anthropic account. The key is stored only on your phone."
            )))
            ui.add(r, c, 8)
            ui.add(r, ui.btn("⚙ " + t("Colocar a chave em Configurações", "Set the key in Settings"), true) { a.go(5) }, 8)
            return
        }

        val top = ui.row()
        ui.addW(top, ui.btn("🗑 " + t("Nova conversa", "New chat")) {
            msgs.clear()
            error = ""
            draft = ""
            a.render()
        }, 1f, 8)
        ui.addW(top, ui.btn("📎 " + t("Anexar arquivo", "Attach file")) { attach() }, 1f, 0)
        ui.add(r, top, 12)

        if (msgs.isEmpty()) {
            val c = ui.card()
            c.addView(ui.sub(t("Exemplos: \"explique este erro do ECJ\", \"crie um app Java com um botão que conta cliques\", \"converta este layout para XML\".", "Examples: \"explain this ECJ error\", \"create a Java app with a click counter button\", \"turn this into an XML layout\".")))
            ui.add(r, c, 8)
        }

        msgs.forEach { m ->
            val c = ui.card()
            val mine = m.role == "user"
            c.addView(ui.text(if (mine) t("Você", "You") else "Claude", ui.fs - 2, if (mine) ui.p.sub else ui.p.accent, true))
            val body = ui.text(m.text, ui.fs, ui.p.text)
            body.setTextIsSelectable(true)
            c.addView(body)
            if (!mine) {
                val row = ui.row()
                row.setPadding(0, ui.dp(8), 0, 0)
                ui.addW(row, ui.btn("📋 " + t("Copiar", "Copy")) { copy(m.text) }, 1f, 8)
                if (fence.containsMatchIn(m.text)) {
                    ui.addW(row, ui.btn("💾 " + t("Salvar código", "Save code")) { saveCode(m.text) }, 1f, 0)
                }
                c.addView(row)
            }
            ui.add(r, c, 8)
        }

        if (busy) {
            val pb = ProgressBar(a)
            pb.isIndeterminate = true
            ui.add(r, pb, 8)
        }
        if (error.isNotEmpty()) {
            val c = ui.card()
            c.addView(ui.text(error, ui.fs - 1, ui.p.accent))
            ui.add(r, c, 8)
        }

        val input = ui.edit(t("Escreva sua mensagem...", "Type your message..."), draft, false, 3)
        inputRef = input
        ui.add(r, input, 8)
        ui.add(r, ui.btn(if (busy) t("Aguarde...", "Wait...") else "➤ " + t("Enviar", "Send"), true) { send(input.text.toString().trim()) }, 8)

        if (msgs.isNotEmpty()) a.scroll.post { a.scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun send(text: String) {
        if (busy || text.isBlank()) return
        error = ""
        draft = ""
        msgs.add(Msg("user", text))
        busy = true
        a.render()
        val history = msgs.map { it.role to it.text }
        thread {
            try {
                val reply = AiClient.ask(history)
                msgs.add(Msg("assistant", reply))
            } catch (e: Exception) {
                msgs.removeAt(msgs.size - 1)
                draft = text
                error = t("Erro: ", "Error: ") + (e.message ?: e.javaClass.simpleName)
            }
            busy = false
            a.runOnUiThread { if (a.cur == 4) a.render() }
        }
    }

    private fun copy(text: String) {
        val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("claude", text))
        a.toast(t("Copiado.", "Copied."))
    }

    private fun attach() {
        val pj = Cfg.lastProject
        val d = if (pj.isNotBlank()) Projects.dir(a, pj) else null
        if (d == null || !d.exists()) {
            a.toast(t("Abra um projeto na aba Código primeiro.", "Open a project in the Code tab first."))
            return
        }
        val files = Projects.files(d).filter { it.length() < 60_000 }
        if (files.isEmpty()) {
            a.toast(t("Nenhum arquivo de texto no projeto.", "No text files in the project."))
            return
        }
        val rels = files.map { it.relativeTo(d).path }
        a.choose(t("Anexar arquivo", "Attach file"), rels) { i ->
            val f: File = files[i]
            val body = try { f.readText() } catch (e: Exception) { "" }
            val cur = inputRef?.text?.toString() ?: draft
            draft = cur + (if (cur.isBlank()) "" else "\n\n") + "Arquivo ${rels[i]}:\n```\n$body\n```\n"
            a.render()
        }
    }

    private fun extFor(lang: String): String = when (lang.lowercase()) {
        "js", "javascript" -> "js"
        "kotlin", "kt" -> "kt"
        "java" -> "java"
        "python", "py" -> "py"
        "lua" -> "lua"
        "html" -> "html"
        "xml" -> "xml"
        "css" -> "css"
        "json" -> "json"
        "bash", "sh" -> "sh"
        "c" -> "c"
        "cpp", "c++" -> "cpp"
        "go" -> "go"
        "rust", "rs" -> "rs"
        "ruby", "rb" -> "rb"
        "php" -> "php"
        else -> "txt"
    }

    private fun saveCode(text: String) {
        val pj = Cfg.lastProject
        val d = if (pj.isNotBlank()) Projects.dir(a, pj) else null
        if (d == null || !d.exists()) {
            a.toast(t("Abra um projeto na aba Código primeiro.", "Open a project in the Code tab first."))
            return
        }
        val blocks = fence.findAll(text).map { it.groupValues[1] to it.groupValues[2] }.toList()
        if (blocks.isEmpty()) return
        val pick = { i: Int ->
            val (lang, code) = blocks[i]
            a.askText(t("Salvar em $pj como", "Save in $pj as"), "main.${extFor(lang)}", "main.${extFor(lang)}") { rel ->
                val f = File(d, rel)
                if (rel.isBlank() || !f.canonicalPath.startsWith(d.canonicalPath + File.separator)) {
                    a.toast(t("Nome inválido.", "Invalid name."))
                } else {
                    f.parentFile?.mkdirs()
                    f.writeText(code)
                    a.toast(t("Salvo em $pj/$rel", "Saved to $pj/$rel"))
                }
            }
        }
        if (blocks.size == 1) {
            pick(0)
        } else {
            a.choose(t("Qual bloco?", "Which block?"), blocks.mapIndexed { i, b -> "${i + 1} · ${b.first.ifBlank { "texto" }} · ${b.second.lines().size} " + t("linhas", "lines") }) { i -> pick(i) }
        }
    }
}
