package com.androidsdk.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Base64
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

/** Tudo que depende do GitHub. É opcional: o app funciona sem nada disso. */
object GitHubSvc {

    fun connected(): Boolean = Cfg.ghToken.isNotBlank()

    fun repoName(): String {
        val r = Cfg.ghRepo
        if (r.isNotBlank()) return r
        return "${Cfg.ghLogin}/androidsdk-builds"
    }

    private fun errMsg(body: String): String =
        try { JSONObject(body).optString("message") } catch (e: Exception) { "" }

    // ---------- Login ----------

    fun loginWithToken(token: String): String {
        val r = Gh.call("GET", "https://api.github.com/user", token)
        if (r.code != 200) throw Exception(t("Token inválido", "Invalid token") + " (${r.code})")
        val login = JSONObject(r.body).optString("login")
        Cfg.ghToken = token
        Cfg.ghLogin = login
        return login
    }

    fun deviceLogin(a: MainActivity, clientId: String, status: (String) -> Unit, done: () -> Unit) {
        if (clientId.isBlank()) {
            status(t("Informe o Client ID ou use um token.", "Enter the Client ID or use a token."))
            return
        }
        Cfg.ghClientId = clientId
        status(t("Contactando o GitHub...", "Contacting GitHub..."))
        thread {
            try {
                val r = Gh.call(
                    "POST", "https://github.com/login/device/code", null,
                    "client_id=$clientId&scope=repo%20workflow",
                    "application/x-www-form-urlencoded", "application/json"
                )
                val j = JSONObject(r.body)
                if (!j.has("device_code")) {
                    throw Exception(j.optString("error_description", t("Client ID inválido ou Device Flow desativado", "Invalid Client ID or Device Flow disabled")))
                }
                val code = j.getString("user_code")
                val url = j.getString("verification_uri")
                val device = j.getString("device_code")
                var interval = j.optInt("interval", 5)
                a.runOnUiThread {
                    val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("codigo", code))
                    status(t("Código: $code (copiado). Cole na página do GitHub que abriu e autorize.", "Code: $code (copied). Paste it on the GitHub page that opened and authorize."))
                    a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
                val deadline = System.currentTimeMillis() + j.optInt("expires_in", 900) * 1000L
                while (System.currentTimeMillis() < deadline) {
                    Thread.sleep(interval * 1000L)
                    val p = JSONObject(
                        Gh.call(
                            "POST", "https://github.com/login/oauth/access_token", null,
                            "client_id=$clientId&device_code=$device&grant_type=urn:ietf:params:oauth:grant-type:device_code",
                            "application/x-www-form-urlencoded", "application/json"
                        ).body
                    )
                    val tok = p.optString("access_token", "")
                    if (tok.isNotEmpty()) {
                        loginWithToken(tok)
                        a.runOnUiThread { done() }
                        return@thread
                    }
                    when (p.optString("error")) {
                        "authorization_pending" -> {}
                        "slow_down" -> interval += 5
                        else -> throw Exception(p.optString("error_description", t("Login cancelado", "Login cancelled")))
                    }
                }
                throw Exception(t("O código expirou. Tente de novo.", "The code expired. Try again."))
            } catch (e: Exception) {
                a.runOnUiThread { status(t("Erro: ", "Error: ") + e.message) }
            }
        }
    }

    // ---------- Repositório e arquivos ----------

    /** Garante que o repositório existe (cria na sua conta se precisar) e devolve o branch padrão. */
    fun ensureRepo(token: String, repo: String): String {
        val g = Gh.call("GET", "https://api.github.com/repos/$repo", token)
        if (g.code == 200) return JSONObject(g.body).getString("default_branch")
        if (g.code != 404) throw Exception("GitHub ${g.code} ${errMsg(g.body)}")
        val body = JSONObject()
            .put("name", repo.substringAfter('/'))
            .put("private", Cfg.ghPrivate)
            .put("auto_init", true)
            .put("description", "Builds do ANDROIDSDK")
            .toString()
        val c = Gh.call("POST", "https://api.github.com/user/repos", token, body)
        if (c.code != 201) throw Exception(t("Não consegui criar o repositório", "Could not create the repository") + " (${c.code}) ${errMsg(c.body)}")
        Thread.sleep(2500)
        return JSONObject(c.body).getString("default_branch")
    }

    fun putFile(api: String, token: String, path: String, data: ByteArray, branch: String, msg: String) {
        val encoded = Base64.encodeToString(data, Base64.NO_WRAP)
        var last = ""
        for (attempt in 1..3) {
            val cur = Gh.call("GET", "$api/contents/$path?ref=$branch", token)
            val body = JSONObject().put("message", msg).put("branch", branch).put("content", encoded)
            if (cur.code == 200) {
                val existing = JSONObject(cur.body)
                if (existing.optString("content").replace("\n", "") == encoded) return
                body.put("sha", existing.getString("sha"))
            }
            val r = Gh.call("PUT", "$api/contents/$path", token, body.toString())
            if (r.code in 200..201) return
            last = "(${r.code}) ${errMsg(r.body)}"
            Thread.sleep(2500)
        }
        throw Exception(t("Falha ao enviar", "Failed to upload") + " $path $last")
    }

    private fun latestRunId(api: String, token: String, wf: String): Long {
        val r = Gh.call("GET", "$api/actions/workflows/$wf/runs?event=workflow_dispatch&per_page=1", token)
        if (r.code != 200) return 0L
        val arr = JSONObject(r.body).optJSONArray("workflow_runs") ?: return 0L
        return if (arr.length() > 0) arr.getJSONObject(0).getLong("id") else 0L
    }

    private fun statusPt(s: String): String = when (s) {
        "queued" -> t("na fila", "queued")
        "in_progress" -> t("compilando", "building")
        "completed" -> t("concluído", "completed")
        else -> s
    }

    private fun dispatch(api: String, token: String, wf: String, branch: String, inputs: JSONObject): Boolean {
        for (i in 1..8) {
            val body = JSONObject().put("ref", branch).put("inputs", inputs).toString()
            val r = Gh.call("POST", "$api/actions/workflows/$wf/dispatches", token, body)
            if (r.code == 204) return true
            Thread.sleep(4000)
        }
        return false
    }

    // ---------- Compilar APK ----------

    fun build(a: MainActivity, zipName: String, bytes: ByteArray, log: (String) -> Unit): File {
        val token = Cfg.ghToken
        val repo = repoName()
        val api = "https://api.github.com/repos/$repo"

        log(t("Verificando repositório $repo...", "Checking repository $repo..."))
        val branch = ensureRepo(token, repo)

        log(t("Instalando o workflow de build...", "Installing the build workflow..."))
        val wf = a.assets.open("zip-build.yml").use { it.readBytes() }
        putFile(api, token, ".github/workflows/zip-build.yml", wf, branch, "ANDROIDSDK: workflow de build")

        log(t("Enviando $zipName...", "Uploading $zipName..."))
        if (bytes.size > 90 * 1024 * 1024) throw Exception(t("O ZIP passa de 90 MB, limite da API do GitHub.", "The ZIP is over 90 MB, the GitHub API limit."))
        val safe = zipName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val zipPath = "uploads/${System.currentTimeMillis()}-$safe"
        putFile(api, token, zipPath, bytes, branch, "ANDROIDSDK: envio de $zipName")

        val prevId = latestRunId(api, token, "zip-build.yml")

        log(t("Iniciando a compilação...", "Starting the build..."))
        if (!dispatch(api, token, "zip-build.yml", branch, JSONObject().put("zip", zipPath))) {
            throw Exception(t("Não consegui iniciar o build. Confira se o token tem a permissão workflow.", "Could not start the build. Check that the token has the workflow scope."))
        }

        log(t("Aguardando o GitHub compilar (pode levar alguns minutos)...", "Waiting for GitHub to build (may take a few minutes)..."))
        var runNumber = 0L
        var lastStatus = ""
        val end = System.currentTimeMillis() + 30 * 60 * 1000L
        while (System.currentTimeMillis() < end) {
            Thread.sleep(8000)
            val r = Gh.call("GET", "$api/actions/workflows/zip-build.yml/runs?event=workflow_dispatch&per_page=5", token)
            if (r.code != 200) continue
            val arr = JSONObject(r.body).optJSONArray("workflow_runs") ?: continue
            var cur: JSONObject? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.getLong("id") > prevId) {
                    cur = o
                    break
                }
            }
            if (cur == null) continue
            val status = cur.getString("status")
            if (status != lastStatus) {
                log("Status: ${statusPt(status)}")
                lastStatus = status
            }
            if (status == "completed") {
                val conclusion = cur.optString("conclusion")
                if (conclusion != "success") {
                    throw Exception(t("O build falhou ($conclusion). Veja os logs em ", "The build failed ($conclusion). See the logs at ") + cur.getString("html_url"))
                }
                runNumber = cur.getLong("run_number")
                break
            }
        }
        if (runNumber == 0L) throw Exception(t("Tempo esgotado esperando o build.", "Timed out waiting for the build."))

        log(t("Baixando o APK...", "Downloading the APK..."))
        var asset: JSONObject? = null
        for (i in 1..5) {
            val rel = Gh.call("GET", "$api/releases/tags/build-$runNumber", token)
            if (rel.code == 200) {
                val list = JSONObject(rel.body).getJSONArray("assets")
                if (list.length() > 0) {
                    asset = list.getJSONObject(0)
                    break
                }
            }
            Thread.sleep(3000)
        }
        if (asset == null) throw Exception(t("APK não encontrado nos Releases do repositório.", "APK not found in the repository Releases."))

        val dir = File(a.getExternalFilesDir(null), "apks")
        dir.mkdirs()
        val dest = File(dir, "ANDROIDSDK-build-$runNumber.apk")
        Gh.downloadAsset(repo, asset.getLong("id"), token, dest)
        log(t("Pronto! APK baixado (${dest.length() / 1024} KB).", "Done! APK downloaded (${dest.length() / 1024} KB)."))
        return dest
    }

    // ---------- Rodar linguagens extras ----------

    fun runScript(a: MainActivity, pl: PL, src: String, log: (String) -> Unit): String {
        val token = Cfg.ghToken
        val repo = repoName()
        val api = "https://api.github.com/repos/$repo"

        log(t("Verificando repositório...", "Checking repository..."))
        val branch = ensureRepo(token, repo)

        log(t("Instalando o workflow de scripts...", "Installing the scripts workflow..."))
        val wf = a.assets.open("run-script.yml").use { it.readBytes() }
        putFile(api, token, ".github/workflows/run-script.yml", wf, branch, "ANDROIDSDK: workflow de scripts")

        log(t("Enviando o script...", "Uploading the script..."))
        val path = "scripts/${System.currentTimeMillis()}.${pl.ext}"
        putFile(api, token, path, src.toByteArray(), branch, "ANDROIDSDK: script ${pl.id}")

        val prev = latestRunId(api, token, "run-script.yml")
        log(t("Iniciando a execução...", "Starting the run..."))
        if (!dispatch(api, token, "run-script.yml", branch, JSONObject().put("script", path).put("lang", pl.id))) {
            throw Exception(t("Não consegui iniciar. Confira se o token tem a permissão workflow.", "Could not start. Check that the token has the workflow scope."))
        }

        log(t("Aguardando o GitHub executar (cerca de 1 minuto)...", "Waiting for GitHub to run it (about 1 minute)..."))
        var runId = 0L
        var url = ""
        var conclusion = ""
        val end = System.currentTimeMillis() + 10 * 60 * 1000L
        while (System.currentTimeMillis() < end) {
            Thread.sleep(4000)
            val r = Gh.call("GET", "$api/actions/workflows/run-script.yml/runs?event=workflow_dispatch&per_page=5", token)
            if (r.code != 200) continue
            val arr = JSONObject(r.body).optJSONArray("workflow_runs") ?: continue
            var cur: JSONObject? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.getLong("id") > prev) {
                    cur = o
                    break
                }
            }
            if (cur == null) continue
            if (cur.getString("status") == "completed") {
                runId = cur.getLong("id")
                url = cur.getString("html_url")
                conclusion = cur.optString("conclusion")
                break
            }
        }
        if (runId == 0L) throw Exception(t("Tempo esgotado esperando o GitHub.", "Timed out waiting for GitHub."))

        for (i in 1..5) {
            val rel = Gh.call("GET", "$api/releases/tags/run-$runId", token)
            if (rel.code == 200) return JSONObject(rel.body).optString("body", "")
            Thread.sleep(3000)
        }
        throw Exception(t("A execução terminou ($conclusion), mas não achei o resultado. Veja em $url", "The run finished ($conclusion), but I could not find the result. See $url"))
    }
}
