package com.androidsdk.app

import android.graphics.Color
import android.graphics.Typeface

class Pal(
    val bg: Int,
    val surface: Int,
    val card: Int,
    val text: Int,
    val sub: Int,
    val accent: Int,
    val onAccent: Int,
    val border: Int,
    val light: Boolean
)

object Themes {
    private fun c(h: String): Int = Color.parseColor(h)

    val ids = listOf("fosco", "amoled", "grafite", "noite", "floresta", "claro")

    fun label(id: String): String = when (id) {
        "fosco" -> t("Preto fosco", "Matte black")
        "amoled" -> t("Preto AMOLED", "AMOLED black")
        "grafite" -> t("Grafite", "Graphite")
        "noite" -> t("Azul noite", "Night blue")
        "floresta" -> t("Verde floresta", "Forest green")
        else -> t("Claro", "Light")
    }

    fun get(id: String): Pal = when (id) {
        "amoled" -> Pal(c("#000000"), c("#070707"), c("#0E0E0E"), c("#EDEDED"), c("#8A8A8A"), c("#00E0A4"), c("#00130D"), c("#1F1F1F"), false)
        "grafite" -> Pal(c("#1A1C20"), c("#1F2227"), c("#262A30"), c("#E4E6EA"), c("#959AA3"), c("#FFA94D"), c("#1A1100"), c("#343840"), false)
        "noite" -> Pal(c("#0A0F1E"), c("#0E1527"), c("#131C33"), c("#E3E9F7"), c("#8C9AB8"), c("#5AA9FF"), c("#031325"), c("#1F2A47"), false)
        "floresta" -> Pal(c("#0D1410"), c("#111A15"), c("#16211A"), c("#E3EEE6"), c("#8FA597"), c("#5EDC8A"), c("#04140A"), c("#22332A"), false)
        "claro" -> Pal(c("#F3F4F6"), c("#FFFFFF"), c("#FFFFFF"), c("#16181D"), c("#6B7280"), c("#3B5BDB"), c("#FFFFFF"), c("#D9DCE3"), true)
        else -> Pal(c("#101012"), c("#151518"), c("#1B1B1F"), c("#E7E7EA"), c("#8E8E97"), c("#8AB4FF"), c("#0B0B0D"), c("#2A2A30"), false)
    }
}

object Fonts {
    val ids = listOf("sans", "condensed", "light", "serif", "mono", "casual")

    fun label(id: String): String = when (id) {
        "sans" -> t("Padrão", "Default")
        "condensed" -> t("Condensada", "Condensed")
        "light" -> t("Leve", "Light")
        "serif" -> t("Serifada", "Serif")
        "mono" -> t("Monoespaçada", "Monospace")
        else -> t("Casual", "Casual")
    }

    fun face(id: String): Typeface = when (id) {
        "condensed" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
        "light" -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        "serif" -> Typeface.SERIF
        "mono" -> Typeface.MONOSPACE
        "casual" -> Typeface.create("casual", Typeface.NORMAL)
        else -> Typeface.SANS_SERIF
    }
}
