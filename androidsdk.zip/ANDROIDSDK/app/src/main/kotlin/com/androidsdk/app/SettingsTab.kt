package com.androidsdk.app

import android.content.res.ColorStateList
import android.widget.SeekBar
import android.widget.TextView
import kotlin.concurrent.thread

class SettingsTab(private val a: MainActivity) {

    private var ghStatus = ""

    fun show() {
        val ui = a.ui
        val r = a.root
        ui.add(r, ui.title(t("Configurações", "Settings")), 12)

        // ---------- Aparência ----------
        val look = ui.card()
        look.addView(ui.text(t("Tema", "Theme"), ui.fs + 1, ui.p.text, true))
        Themes.ids.forEach { id ->
            val mark = if (Cfg.theme == id) "✔ " else ""
            ui.add(look, ui.btn(mark + Themes.label(id), Cfg.theme == id) {
                Cfg.theme = id
                a.render()
            }, 6)
        }
        ui.add(r, look, 12)

        val fonts = ui.card()
        fonts.addView(ui.text(t("Fonte", "Font"), ui.fs + 1, ui.p.text, true))
        Fonts.ids.forEach { id ->
            val mark = if (Cfg.font == id) "✔ " else ""
            val b = ui.btn(mark + Fonts.label(id), Cfg.font == id) {
                Cfg.font = id
                a.render()
            }
            b.typeface = Fonts.face(id)
            ui.add(fonts, b, 6)
        }
        ui.add(r, fonts, 12)

        val size = ui.card()
        size.addView(ui.text(t("Tamanho da fonte", "Font size"), ui.fs + 1, ui.p.text, true))
        val label: TextView = ui.text("${Cfg.fontSize} sp", ui.fs, ui.p.accent, true)
        size.addView(label)
        val sb = SeekBar(a)
        sb.max = 12
        sb.progress = Cfg.fontSize - 12
        sb.progressTintList = ColorStateList.valueOf(ui.p.accent)
        sb.thumbTintList = ColorStateList.valueOf(ui.p.accent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = "${p + 12} sp"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {
                Cfg.fontSize = (s?.progress ?: 3) + 12
                a.render()
            }
        })
        ui.add(size, sb, 4)
        size.addView(ui.sub(t("Arraste e solte para aplicar (12 a 24).", "Drag and release to apply (12 to 24).")))
        ui.add(r, size, 12)

        val lang = ui.card()
        lang.addView(ui.text(t("Idioma", "Language"), ui.fs + 1, ui.p.text, true))
        val lr = ui.row()
        ui.addW(lr, ui.btn((if (Cfg.lang == "pt") "✔ " else "") + "Português (BR)", Cfg.lang == "pt") {
            Cfg.lang = "pt"
            a.render()
        }, 1f, 8)
        ui.addW(lr, ui.btn((if (Cfg.lang == "en") "✔ " else "") + "English", Cfg.lang == "en") {
            Cfg.lang = "en"
            a.render()
        }, 1f, 0)
        ui.add(lang, lr, 0)
        ui.add(r, lang, 12)

        // ---------- Linguagens ----------
        val langs = ui.card()
        langs.addView(ui.text(t("Linguagens de programação", "Programming languages"), ui.fs + 1, ui.p.text, true))
        langs.addView(ui.sub(t("No celular = roda offline. GitHub = opcional, roda na nuvem.", "On phone = runs offline. GitHub = optional, runs in the cloud.")))
        Langs.all.forEach { pl ->
            val where = if (pl.mode == "remote") "GitHub" else t("no celular", "on phone")
            ui.add(langs, ui.check("${pl.label}  ·  $where", Cfg.langOn(pl.id)) { Cfg.setLangOn(pl.id, it) }, 0)
        }
        ui.add(r, langs, 12)

        // ---------- GitHub (opcional) ----------
        val gh = ui.card()
        gh.addView(ui.text("GitHub (" + t("opcional", "optional") + ")", ui.fs + 1, ui.p.text, true))
        gh.addView(ui.sub(t("O app funciona sem conta. O GitHub só serve para compilar o APK e rodar linguagens extras.", "The app works without an account. GitHub is only for building the APK and running extra languages.")))
        val st = ui.sub(ghStatus)

        if (GitHubSvc.connected()) {
            ui.add(gh, ui.text("✔ " + t("Conectado como @", "Connected as @") + Cfg.ghLogin, ui.fs, ui.p.accent, true), 6)
            gh.addView(ui.sub(t("Repositório dos builds (criado automaticamente se não existir):", "Builds repository (created automatically if missing):")))
            val rf = ui.edit("usuario/repositorio", GitHubSvc.repoName())
            ui.add(gh, rf, 6)
            ui.add(gh, ui.check(t("Repositório privado ao criar", "Private repository when creating"), Cfg.ghPrivate) { Cfg.ghPrivate = it }, 6)
            ui.add(gh, ui.btn(t("Salvar repositório", "Save repository")) {
                val v = rf.text.toString().trim()
                if (Regex("[\\w.-]+/[\\w.-]+").matches(v)) {
                    Cfg.ghRepo = v
                    a.toast(t("Salvo.", "Saved."))
                } else {
                    a.toast(t("Use o formato usuario/repositorio", "Use the format user/repository"))
                }
            }, 6)
            ui.add(gh, ui.btn(t("Sair do GitHub", "Sign out of GitHub")) {
                Cfg.ghToken = ""
                Cfg.ghLogin = ""
                a.render()
            }, 0)
        } else {
            gh.addView(ui.sub(t("Entrar pelo navegador (precisa de um Client ID com Device Flow ativo em github.com/settings/developers):", "Sign in via browser (needs a Client ID with Device Flow enabled at github.com/settings/developers):")))
            val cid = ui.edit("Client ID", Cfg.ghClientId)
            ui.add(gh, cid, 6)
            ui.add(gh, ui.btn("🔐 " + t("Entrar com GitHub", "Sign in with GitHub"), true) {
                GitHubSvc.deviceLogin(a, cid.text.toString().trim(), { m ->
                    ghStatus = m
                    st.text = m
                }, {
                    ghStatus = ""
                    a.render()
                })
            }, 10)
            gh.addView(ui.sub(t("Ou cole um token de acesso (permissões repo e workflow):", "Or paste an access token (repo and workflow scopes):")))
            val tok = ui.edit("ghp_...")
            tok.transformationMethod = android.text.method.PasswordTransformationMethod.getInstance()
            ui.add(gh, tok, 6)
            ui.add(gh, ui.btn(t("Entrar com token", "Sign in with token")) {
                val v = tok.text.toString().trim()
                if (v.isEmpty()) return@btn
                st.text = t("Verificando...", "Checking...")
                thread {
                    try {
                        GitHubSvc.loginWithToken(v)
                        a.runOnUiThread { a.render() }
                    } catch (e: Exception) {
                        a.runOnUiThread { st.text = t("Erro: ", "Error: ") + e.message }
                    }
                }
            }, 6)
        }
        gh.addView(st)
        ui.add(r, gh, 12)

        // ---------- Sobre ----------
        val about = ui.card()
        about.addView(ui.text("ANDROIDSDK", ui.fs + 1, ui.p.text, true))
        val ver = try {
            a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "?"
        } catch (e: Exception) {
            "?"
        }
        about.addView(ui.sub(t("Versão ", "Version ") + ver))
        ui.add(r, about, 8)
    }
}
