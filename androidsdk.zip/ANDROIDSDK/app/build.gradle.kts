import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath("com.android.tools:r8:8.5.35")
    }
}

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ---- peças do motor local, preparadas no BUILD (não no celular) ----
val engineAssets = layout.buildDirectory.get().asFile.resolve("generated/engine-assets")
val kotlinAssets = layout.buildDirectory.get().asFile.resolve("generated/kotlin-assets")
val androidHome: String = System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT") ?: ""
val androidJarFile = File(androidHome, "platforms/android-34/android.jar")

val kotlinc by configurations.creating

val copyAndroidJar = tasks.register<Copy>("copyAndroidJar") {
    from(androidJarFile)
    into(engineAssets)
}

// Converte o compilador oficial do Kotlin para DEX aqui no build. Se falhar, o app compila do mesmo jeito (sem Kotlin local).
val buildKotlinEngine = tasks.register("buildKotlinEngine") {
    doLast {
        try {
            if (!androidJarFile.exists()) throw RuntimeException("android.jar não encontrado em " + androidJarFile)
            kotlinAssets.deleteRecursively()
            kotlinAssets.mkdirs()
            val jars = kotlinc.resolve().toList()
            val dexZip = File(kotlinAssets, "kotlinc-dex.zip")
            val b = com.android.tools.r8.D8Command.builder()
            jars.forEach { b.addProgramFiles(it.toPath()) }
            b.addLibraryFiles(androidJarFile.toPath())
            b.setOutput(dexZip.toPath(), com.android.tools.r8.OutputMode.DexIndexed)
            b.setMinApiLevel(26)
            b.setMode(com.android.tools.r8.CompilationMode.DEBUG)
            com.android.tools.r8.D8.run(b.build())

            val finalJar = File(kotlinAssets, "kotlinc.jar")
            ZipOutputStream(finalJar.outputStream().buffered()).use { zo ->
                val seen = HashSet<String>()
                ZipFile(dexZip).use { z ->
                    for (e in z.entries()) {
                        if (e.isDirectory || !seen.add(e.name)) continue
                        zo.putNextEntry(ZipEntry(e.name))
                        z.getInputStream(e).use { it.copyTo(zo) }
                        zo.closeEntry()
                    }
                }
                for (jar in jars) {
                    ZipFile(jar).use { z ->
                        for (e in z.entries()) {
                            val n = e.name
                            val skip = e.isDirectory || n.endsWith(".class") || n == "META-INF/MANIFEST.MF" ||
                                (n.startsWith("META-INF/") && (n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC")))
                            if (skip || !seen.add(n)) continue
                            zo.putNextEntry(ZipEntry(n))
                            z.getInputStream(e).use { it.copyTo(zo) }
                            zo.closeEntry()
                        }
                    }
                }
            }
            val stdlib = jars.first { it.name.startsWith("kotlin-stdlib-") && !it.name.contains("jdk") && !it.name.contains("common") }
            stdlib.copyTo(File(kotlinAssets, "kotlin-stdlib.jar"), true)
            dexZip.delete()
            logger.lifecycle("Motor Kotlin embutido: " + finalJar.length() / 1024 + " KB")
        } catch (e: Throwable) {
            logger.warn("AVISO: o motor Kotlin NÃO foi embutido neste build: " + e)
            kotlinAssets.deleteRecursively()
        }
    }
}

android {
    namespace = "com.androidsdk.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.androidsdk.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 8
        versionName = "2.5"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    sourceSets {
        getByName("main") {
            assets.srcDirs(engineAssets, kotlinAssets)
        }
    }
    packaging {
        resources {
            excludes += setOf(
                "META-INF/*.SF", "META-INF/*.RSA", "META-INF/*.DSA",
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES",
                "META-INF/*.kotlin_module", "META-INF/AL2.0", "META-INF/LGPL2.1"
            )
            pickFirsts += setOf("**/about.html", "META-INF/eclipse.inf")
        }
    }
}

tasks.configureEach {
    if (name.startsWith("merge") && name.endsWith("Assets")) {
        dependsOn(copyAndroidJar, buildKotlinEngine)
    }
}

dependencies {
    kotlinc("org.jetbrains.kotlin:kotlin-compiler-embeddable:1.9.24")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("org.luaj:luaj-jse:3.0.1")
    // motor de compilação local
    implementation("org.eclipse.jdt:ecj:3.26.0")
    implementation("com.android.tools:r8:8.5.35")
    implementation("com.android.tools.build:apksig:8.5.2")
}
