plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// O motor local precisa do android.jar da plataforma; ele é copiado do SDK na hora do build.
val engineAssets = layout.buildDirectory.get().asFile.resolve("generated/engine-assets")
val androidHome: String = System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT") ?: ""
val copyAndroidJar = tasks.register<Copy>("copyAndroidJar") {
    from(File(androidHome, "platforms/android-34/android.jar"))
    into(engineAssets)
}

android {
    namespace = "com.androidsdk.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.androidsdk.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "2.2"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    sourceSets {
        getByName("main") {
            assets.srcDir(engineAssets)
        }
    }
    packaging {
        resources {
            excludes += setOf(
                "META-INF/*.SF", "META-INF/*.RSA", "META-INF/*.DSA",
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES",
                "META-INF/*.kotlin_module", "META-INF/AL2.0", "META-INF/LGPL2.1"
            )
            pickFirsts += setOf("**/about.html", "META-INF/eclipse.inf")
        }
    }
}

tasks.configureEach {
    if (name.startsWith("merge") && name.endsWith("Assets")) dependsOn(copyAndroidJar)
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("org.luaj:luaj-jse:3.0.1")
    // motor de compilação local
    implementation("org.eclipse.jdt:ecj:3.26.0")
    implementation("com.android.tools:r8:8.5.35")
    implementation("com.android.tools.build:apksig:8.5.2")
}
